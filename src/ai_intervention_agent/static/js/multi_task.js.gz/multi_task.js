if (typeof window.currentTasks === "undefined") {
  window.currentTasks = [];
}
if (typeof window.activeTaskId === "undefined") {
  window.activeTaskId = null;
}
if (typeof window.taskCountdowns === "undefined") {
  window.taskCountdowns = {};
}
if (typeof window.tasksCountdownTickerTimer === "undefined") {
  window.tasksCountdownTickerTimer = null;
}
if (typeof window.tasksPollingTimer === "undefined") {
  window.tasksPollingTimer = null;
}
if (typeof window.taskTextareaContents === "undefined") {
  window.taskTextareaContents = {};
}
if (typeof window.taskOptionsStates === "undefined") {
  window.taskOptionsStates = {};
}
if (typeof window.taskUserOptionInteracted === "undefined") {
  window.taskUserOptionInteracted = {};
}

if (typeof window.taskImages === "undefined") {
  window.taskImages = {};
}

if (typeof window.pendingNewTaskCount === "undefined") {
  window.pendingNewTaskCount = 0;
}
if (typeof window.newTaskHintTimer === "undefined") {
  window.newTaskHintTimer = null;
}

if (typeof window.tasksHealthCheckTimer === "undefined") {
  window.tasksHealthCheckTimer = null;
}
if (typeof window.hasLoadedTaskSnapshot === "undefined") {
  window.hasLoadedTaskSnapshot = false;
}

if (typeof window.lastLoadedDetailsTaskId === "undefined") {
  window.lastLoadedDetailsTaskId = null;
}

if (typeof window.serverTimeOffset === "undefined") {
  window.serverTimeOffset = 0;
}
function _t(key, params) {
  try {
    if (window.AIIA_I18N && typeof window.AIIA_I18N.t === "function") {
      return window.AIIA_I18N.t(key, params);
    }
  } catch (_e) {

  }
  return key;
}

function _debugLogEnabled() {
  return (
    !!window.AIIA_DEBUG &&
    typeof console !== "undefined" &&
    typeof console.debug === "function"
  );
}

function _debugLog() {
  if (!_debugLogEnabled()) {
    return;
  }
  try {
    console.debug.apply(console, arguments);
  } catch (_e) {

  }
}

function _debugSseTaskChanged(data) {
  if (!_debugLogEnabled()) return;
  try {
    var detail = JSON.parse(data || "{}");
    _debugLog(
      "SSE task_changed:",
      detail.task_id,
      detail.old_status,
      "→",
      detail.new_status,
    );
  } catch (_) {

  }
}

function _debugSseDetail(label, data) {
  if (!_debugLogEnabled()) return;
  try {
    _debugLog(label, JSON.parse(data || "{}"));
  } catch (_) {

  }
}

if (typeof window.taskDeadlines === "undefined") {
  window.taskDeadlines = {};
}

if (typeof window.feedbackPrompts === "undefined") {
  window.feedbackPrompts = {
    resubmit_prompt: "",
    prompt_suffix: "",
  };
}

if (typeof window.autoSubmitAttempted === "undefined") {
  window.autoSubmitAttempted = {};
}

if (typeof window.lastFeedbackTypingAtMs === "undefined") {
  window.lastFeedbackTypingAtMs = 0;
}
if (typeof window.__aiiaTypingAutoExtendInFlight === "undefined") {
  window.__aiiaTypingAutoExtendInFlight = false;
}
var TYPING_HOLD_IDLE_MS = 10 * 1000;
var TYPING_HOLD_TRIGGER_S = 15;

async function _writeToClipboard(text) {
  const s = String(text || "");
  if (!s) return false;
  try {
    if (
      typeof navigator !== "undefined" &&
      navigator.clipboard &&
      typeof navigator.clipboard.writeText === "function"
    ) {
      await navigator.clipboard.writeText(s);
      return true;
    }
  } catch (_e) {

  }
  try {
    const ta = document.createElement("textarea");
    ta.value = s;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "-1000px";
    ta.style.left = "-1000px";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch (_e2) {
    return false;
  }
}

function buildTaskDeepLink(taskId, base) {
  const id = String(taskId || "");
  if (!id) return "";
  try {
    const baseUrl =
      base && typeof base === "object" && typeof base.href === "string"
        ? base.href
        : typeof base === "string"
          ? base
          : typeof window !== "undefined" && window.location
            ? window.location.href
            : "http://localhost/";
    const u = new URL(baseUrl);
    u.searchParams.set("task_id", id);
    return u.toString();
  } catch (_e) {
    return "";
  }
}

async function copyTaskIdToClipboard(taskId) {
  const ok = await _writeToClipboard(taskId);
  _flashCopyOnSourceElement(taskId, ok);
  try {
    if (typeof showStatus === "function" && typeof t === "function") {
      showStatus(
        ok ? t("status.copied") : t("status.copyFailed"),
        ok ? "success" : "error",
      );
    }
  } catch (_e) {

  }
  return ok;
}

function _flashCopyOnSourceElement(taskId, ok) {
  try {
    const elements = document.querySelectorAll(
      `[data-copyable-task-id="${CSS.escape(String(taskId || ""))}"]`,
    );
    const elementCount = elements.length;
    for (let index = 0; index < elementCount; index += 1) {
      const el = elements[index];
      if (!el) continue;
      const cls = ok ? "copy-flash-ok" : "copy-flash-err";
      el.classList.remove("copy-flash-ok", "copy-flash-err");

      void el.offsetWidth;
      el.classList.add(cls);
      setTimeout(() => {
        try {
          el.classList.remove(cls);
        } catch (_e) {

        }
      }, 600);
    }
  } catch (_e) {

  }
}

async function copyTaskLinkToClipboard(taskId) {
  const url = buildTaskDeepLink(taskId);
  if (!url) {
    _flashCopyOnSourceElement(taskId, false);
    try {
      if (typeof showStatus === "function" && typeof t === "function") {
        showStatus(t("status.copyFailed"), "error");
      }
    } catch (_e) {

    }
    return false;
  }
  const ok = await _writeToClipboard(url);
  _flashCopyOnSourceElement(taskId, ok);
  try {
    if (typeof showStatus === "function" && typeof t === "function") {
      showStatus(
        ok ? t("status.copied") : t("status.copyFailed"),
        ok ? "success" : "error",
      );
    }
  } catch (_e) {

  }
  return ok;
}

if (typeof window !== "undefined") {
  window.copyTaskIdToClipboard = copyTaskIdToClipboard;
  window.copyTaskLinkToClipboard = copyTaskLinkToClipboard;
  window.buildTaskDeepLink = buildTaskDeepLink;
}

if (typeof window.__aiiaMarkedSecurityConfigured === "undefined") {
  window.__aiiaMarkedSecurityConfigured = false;
}

function configureMarkedSecurityOnce() {
  if (window.__aiiaMarkedSecurityConfigured) return;
  if (typeof marked === "undefined" || !marked) return;

  try {
    if (typeof marked.use === "function") {
      marked.use({
        renderer: {
          html() {
            return "";
          },
        },
      });
    }
    if (typeof marked.setOptions === "function") {
      marked.setOptions({ mangle: false, headerIds: false });
    }
    window.__aiiaMarkedSecurityConfigured = true;
  } catch (e) {

  }
}

configureMarkedSecurityOnce();

var currentTasks = window.currentTasks;
var activeTaskId = window.activeTaskId;
var taskCountdowns = window.taskCountdowns;
var tasksCountdownTickerTimer = window.tasksCountdownTickerTimer;
var tasksPollingTimer = window.tasksPollingTimer;
var taskTextareaContents = window.taskTextareaContents;
var taskOptionsStates = window.taskOptionsStates;
var taskUserOptionInteracted = window.taskUserOptionInteracted;
var taskImages = window.taskImages;
var pendingNewTaskCount = window.pendingNewTaskCount;
var newTaskHintTimer = window.newTaskHintTimer;
var hasLoadedTaskSnapshot = window.hasLoadedTaskSnapshot;
var feedbackPrompts = window.feedbackPrompts;
var autoSubmitAttempted = window.autoSubmitAttempted;
var pendingDeepLinkedTaskId = getDeepLinkedTaskIdFromUrl();
var realtimeTextareaAutosaveBinding = null;
var realtimeOptionsAutosaveBinding = null;

function normalizeTaskIdValue(taskId) {
  if (taskId === null || typeof taskId === "undefined") return null;
  const normalized = String(taskId);
  return normalized ? normalized : null;
}

function getTaskIdString(task) {
  if (!task) return "";
  return normalizeTaskIdValue(task.task_id) || "";
}

function findTaskById(tasks, taskId) {
  const taskCount = tasks && Number.isFinite(tasks.length) ? tasks.length : 0;
  for (let taskIndex = 0; taskIndex < taskCount; taskIndex += 1) {
    const task = tasks[taskIndex];
    if (task && task.task_id === taskId) {
      return task;
    }
  }
  return null;
}

function findOpenTaskById(tasks, taskId) {
  const taskCount = tasks && Number.isFinite(tasks.length) ? tasks.length : 0;
  for (let taskIndex = 0; taskIndex < taskCount; taskIndex += 1) {
    const task = tasks[taskIndex];
    if (task && task.task_id === taskId && task.status !== "completed") {
      return task;
    }
  }
  return null;
}

function findFirstOpenTask(tasks, excludedTaskId) {
  const taskCount = tasks && Number.isFinite(tasks.length) ? tasks.length : 0;
  for (let taskIndex = 0; taskIndex < taskCount; taskIndex += 1) {
    const task = tasks[taskIndex];
    if (!task || task.status === "completed") {
      continue;
    }
    if (
      typeof excludedTaskId !== "undefined" &&
      task.task_id === excludedTaskId
    ) {
      continue;
    }
    return task;
  }
  return null;
}

function setActiveTaskId(nextTaskId) {
  activeTaskId = normalizeTaskIdValue(nextTaskId);
  window.activeTaskId = activeTaskId;
  return activeTaskId;
}

function cloneTaskImagesForState(images) {
  const imageCount = images && Number.isFinite(images.length) ? images.length : 0;
  const clonedImages = new Array(imageCount);
  for (let imageIndex = 0; imageIndex < imageCount; imageIndex += 1) {
    if (!(imageIndex in images)) continue;
    clonedImages[imageIndex] = { ...images[imageIndex] };
  }
  return clonedImages;
}

function _buildTaskListDiff(previousTasks, nextTasks) {
  const oldTaskIds = [];
  const oldTaskIdSet = new Set();
  if (Array.isArray(previousTasks)) {
    for (const task of previousTasks) {
      const taskId = task && task.task_id;
      oldTaskIds.push(taskId);
      oldTaskIdSet.add(taskId);
    }
  }

  const newTaskIdSet = new Set();
  const addedTaskIds = [];
  const addedTasks = [];
  if (Array.isArray(nextTasks)) {
    for (const task of nextTasks) {
      const taskId = task && task.task_id;
      newTaskIdSet.add(taskId);
      if (!oldTaskIdSet.has(taskId)) {
        addedTaskIds.push(taskId);
        addedTasks.push(task);
      }
    }
  }

  const removedTaskIds = [];
  for (const taskId of oldTaskIds) {
    if (!newTaskIdSet.has(taskId)) {
      removedTaskIds.push(taskId);
    }
  }

  return {
    addedTaskIds,
    addedTasks,
    removedTaskIds,
  };
}

function _buildTaskRefreshState(tasks, preferredTaskId) {
  const preferredOpenTaskId = normalizeTaskIdValue(preferredTaskId);
  const completedTaskIds = [];
  let hasActiveTasks = false;
  let serverActiveTask = null;
  let preferredOpenTask = null;
  let firstOpenTask = null;

  if (Array.isArray(tasks)) {
    for (const task of tasks) {
      if (!task) continue;
      const taskId = getTaskIdString(task);
      if (task.status === "completed") {
        if (taskId) completedTaskIds.push(taskId);
        continue;
      }

      hasActiveTasks = true;
      if (!firstOpenTask && taskId) {
        firstOpenTask = task;
      }
      if (
        !preferredOpenTask &&
        preferredOpenTaskId &&
        taskId === preferredOpenTaskId
      ) {
        preferredOpenTask = task;
      }
      if (!serverActiveTask && task.status === "active") {
        serverActiveTask = task;
      }
    }
  }

  const fallbackOpenTask = preferredOpenTask || firstOpenTask;
  const nextActiveTaskId =
    (serverActiveTask && getTaskIdString(serverActiveTask)) ||
    (fallbackOpenTask && getTaskIdString(fallbackOpenTask)) ||
    null;
  let activeTaskForControls = null;
  if (nextActiveTaskId) {
    if (
      serverActiveTask &&
      getTaskIdString(serverActiveTask) === nextActiveTaskId
    ) {
      activeTaskForControls = serverActiveTask;
    } else if (
      preferredOpenTask &&
      getTaskIdString(preferredOpenTask) === nextActiveTaskId
    ) {
      activeTaskForControls = preferredOpenTask;
    } else if (
      firstOpenTask &&
      getTaskIdString(firstOpenTask) === nextActiveTaskId
    ) {
      activeTaskForControls = firstOpenTask;
    }
  }

  return {
    completedTaskIds,
    hasActiveTasks,
    serverActiveTask,
    nextActiveTaskId,
    activeTaskForControls,
  };
}

function clearTaskLocalState(taskId) {
  const normalizedTaskId = normalizeTaskIdValue(taskId);
  if (!normalizedTaskId) return;
  if (taskCountdowns[normalizedTaskId]) {
    _clearTaskCountdown(normalizedTaskId);
    _debugLog(`Cleared countdown for task ${normalizedTaskId}`);
  }
  if (window.taskDeadlines[normalizedTaskId] !== undefined) {
    delete window.taskDeadlines[normalizedTaskId];
  }
  if (taskTextareaContents[normalizedTaskId] !== undefined) {
    delete taskTextareaContents[normalizedTaskId];
  }
  if (taskOptionsStates[normalizedTaskId] !== undefined) {
    delete taskOptionsStates[normalizedTaskId];
  }
  if (taskUserOptionInteracted[normalizedTaskId] !== undefined) {
    delete taskUserOptionInteracted[normalizedTaskId];
  }
  if (taskImages[normalizedTaskId] !== undefined) {
    delete taskImages[normalizedTaskId];
  }
  if (
    autoSubmitAttempted &&
    autoSubmitAttempted[normalizedTaskId] !== undefined
  ) {
    delete autoSubmitAttempted[normalizedTaskId];
  }
}

function getDeepLinkedTaskIdFromUrl() {
  try {
    if (!window.location || !window.location.search) return "";
    const params = new URLSearchParams(window.location.search);

    const aiiaTest = (params.get("aiia_test") || "").trim().toLowerCase();
    if (aiiaTest === "1" || aiiaTest === "true" || aiiaTest === "yes") {
      try {
        if (typeof _showToast === "function") {
          _showToast("Bark test notification opened — UI is working.");
        }
      } catch (_) {

      }
      return "";
    }

    const raw =
      params.get("task_id") || params.get("taskId") || params.get("tid") || "";
    const taskId = String(raw).trim();

    return taskId.length <= 200 ? taskId : "";
  } catch (_e) {
    return "";
  }
}

function tryApplyDeepLinkedTask(tasks) {
  if (!pendingDeepLinkedTaskId || !Array.isArray(tasks) || tasks.length === 0) {
    return false;
  }

  const target = findOpenTaskById(tasks, pendingDeepLinkedTaskId);
  if (!target) {

    return false;
  }

  const targetTaskId = pendingDeepLinkedTaskId;
  pendingDeepLinkedTaskId = "";

  if (targetTaskId === activeTaskId) {
    loadTaskDetails(targetTaskId);
    return true;
  }

  _debugLog(`Deep link target task detected: ${targetTaskId}`);
  setTimeout(() => {
    switchTask(targetTaskId).catch((error) => {
      console.error("Deep link task switch failed:", error);
    });
  }, 0);
  return true;
}

async function fetchFeedbackPromptsFresh() {
  try {
    const resp = await fetchWithTimeout(
      "/api/get-feedback-prompts",
      { cache: "no-store" },
      10000,
    );
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    if (data && data.status === "success" && data.config) {
      window.feedbackPrompts = data.config;
      feedbackPrompts = window.feedbackPrompts;

      if (data.meta && data.meta.config_file) {
        const el = document.getElementById("config-file-path");
        if (el) {
          el.value = data.meta.config_file;
          el.removeAttribute("data-i18n-value");
        }
      }
      return window.feedbackPrompts;
    }
  } catch (e) {
    console.warn(
      "Failed to fetch feedback prompts; using in-memory defaults:",
      e,
    );
  }
  return window.feedbackPrompts;
}

if (typeof window.remainingSeconds === "undefined") {
  window.remainingSeconds = 0;
}

if (typeof window.updateCountdownDisplay !== "function") {
  window.updateCountdownDisplay = function (seconds) {
    const countdownContainer = document.getElementById("countdown-container");
    const countdownText = document.getElementById("countdown-text");

    if (!countdownContainer || !countdownText) return;

    const displaySeconds =
      typeof seconds === "number" ? seconds : window.remainingSeconds;

    if (displaySeconds > 0) {
      countdownText.textContent = _t("page.countdown", {
        seconds: displaySeconds,
      });
      countdownContainer.classList.remove("hidden");
    } else {
      countdownContainer.classList.add("hidden");
    }
  };
}
var updateCountdownDisplay = window.updateCountdownDisplay;

var TASKS_POLL_BASE_MS = 2000;
var TASKS_POLL_MAX_MS = 30000;
var TASKS_POLL_SSE_FALLBACK_MS = 30000;

var TASKS_POLL_TIMEOUT_MS = 6000;
var tasksPollBackoffMs = TASKS_POLL_BASE_MS;
var tasksPollAbortController = null;
var tasksPollVisibilityHandlerInstalled = false;

var _sseSource = null;
var _sseConnected = false;
var _sseReconnectTimer = null;
var _sseReconnectDelay = 1000;
var _sseDebounceTimer = null;

var SSE_SHARED_CHANNEL_NAME = "aiia:sse:v1";
var SSE_SHARED_ELECTION_DELAY_MS = 160;
var SSE_SHARED_LEADER_STALE_MS = 5000;
var SSE_SHARED_LEADER_HEARTBEAT_MS = 2000;
var _sseSharedChannel = null;
var _sseSharedClientId = "";
var _sseSharedLeaderId = null;
var _sseSharedLeaderSeenAtMs = 0;
var _sseSharedIsLeader = false;
var _sseSharedElectionTimer = null;
var _sseSharedWatchdogTimer = null;
var _sseSharedLeaderHeartbeatTimer = null;

var SSE_STATUS_CONNECTED = "connected";
var SSE_STATUS_RECONNECTING = "reconnecting";
var SSE_STATUS_DISCONNECTED = "disconnected";

var SSE_STATUS_DISCONNECTED_DELAY_MS = 30000;

function _resolveExtendCountdownLabel(state) {
  var key;
  var fallback;
  if (state === "ariaLabel") {
    key = "page.extendCountdown.ariaLabel";
    fallback = "Extend countdown by 60 seconds";
  } else if (state === "title") {
    key = "page.extendCountdown.title";
    fallback = "Extend countdown by 60 seconds (max 3 times per task)";
  } else if (state === "limitReached") {
    key = "page.extendCountdown.limitReached";
    fallback = "Extension limit reached";
  } else if (state === "label") {
    key = "page.extendCountdown.label";
    fallback = "+60s";
  } else {
    key = "page.extendCountdown.networkError";
    fallback = "Failed to extend countdown";
  }
  var v;
  if (key === "page.extendCountdown.ariaLabel") {
    v = _t("page.extendCountdown.ariaLabel");
  } else if (key === "page.extendCountdown.title") {
    v = _t("page.extendCountdown.title");
  } else if (key === "page.extendCountdown.limitReached") {
    v = _t("page.extendCountdown.limitReached");
  } else if (key === "page.extendCountdown.label") {
    v = _t("page.extendCountdown.label");
  } else {
    v = _t("page.extendCountdown.networkError");
  }
  return typeof v === "string" && v.length > 0 && v !== key ? v : fallback;
}

function updateCountdownExtendButton(task) {
  if (typeof document === "undefined") return;
  var btn = document.getElementById("countdown-extend-btn");
  if (!btn) return;
  if (
    !task ||
    typeof task.extends_used !== "number" ||
    typeof task.extends_max !== "number" ||
    task.status === "completed" ||
    (task.auto_resubmit_timeout || 0) <= 0
  ) {
    btn.classList.add("hidden");
    btn.disabled = true;
    return;
  }
  btn.classList.remove("hidden");
  var atLimit = task.extends_used >= task.extends_max;
  btn.disabled = atLimit;
  if (atLimit) {
    btn.setAttribute("title", _resolveExtendCountdownLabel("limitReached"));
    btn.setAttribute(
      "aria-label",
      _resolveExtendCountdownLabel("limitReached"),
    );
  } else {
    btn.setAttribute("title", _resolveExtendCountdownLabel("title"));
    btn.setAttribute("aria-label", _resolveExtendCountdownLabel("ariaLabel"));
  }
}

function handleExtendCountdownClick() {
  if (typeof document === "undefined" || typeof fetch === "undefined") return;
  var btn = document.getElementById("countdown-extend-btn");
  if (!btn || btn.disabled) return;
  var taskId = window.activeTaskId;
  if (!taskId) return;
  btn.disabled = true;
  try {
    fetch("/api/tasks/" + encodeURIComponent(taskId) + "/extend", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seconds: 60 }),
    })
      .then(function (resp) {
        return resp.json().then(function (data) {
          return { ok: resp.ok, data: data };
        });
      })
      .then(function (res) {
        if (!res.ok || !res.data || !res.data.success) {
          var code = (res.data && res.data.code) || "unknown";
          console.warn("Extend countdown failed:", code);
          if (typeof window.showInPageMessage === "function") {
            try {
              window.showInPageMessage(
                _resolveExtendCountdownLabel("networkError"),
                "error",
              );
            } catch (_e) {

            }
          }

          if (res.data && typeof res.data.extends_used === "number") {
            var task = findTaskById(window.currentTasks || [], taskId);
            if (task) {
              task.extends_used = res.data.extends_used;
              task.extends_max = res.data.extends_max || task.extends_max;
              updateCountdownExtendButton(task);
            }
          } else {
            btn.disabled = false;
          }
          return;
        }

        var data = res.data;
        var newRemaining = data.new_remaining_time;
        var newTimeout = data.new_auto_resubmit_timeout;

        var adjustedNow =
          Date.now() / 1000 + (window.serverTimeOffset || 0);
        if (typeof window.taskDeadlines === "object" && window.taskDeadlines) {
          window.taskDeadlines[taskId] = adjustedNow + newRemaining;
        }

        if (typeof window.taskCountdowns === "object" && window.taskCountdowns) {
          var cd = window.taskCountdowns[taskId];
          if (cd) {
            cd.remaining = newRemaining;
            cd.timeout = newTimeout;
          }
        }

        var task = findTaskById(window.currentTasks || [], taskId);
        if (task) {
          task.extends_used = data.extends_used;
          task.extends_max = data.extends_max;
          task.auto_resubmit_timeout = newTimeout;
          task.remaining_time = newRemaining;
          updateCountdownExtendButton(task);

          if (typeof updateFreezeCountdownButton === "function") {
            updateFreezeCountdownButton(task);
          }
        }

        if (typeof window.updateCountdownDisplay === "function") {
          window.updateCountdownDisplay(newRemaining);
        }
      })
      .catch(function (e) {
        console.warn("Extend countdown network error:", e);
        btn.disabled = false;
      });
  } catch (e) {
    console.warn("Extend countdown invocation failed:", e);
    btn.disabled = false;
  }
}

if (
  typeof document !== "undefined" &&
  !window.__aiiaExtendBtnBound
) {
  window.__aiiaExtendBtnBound = true;
  document.addEventListener("DOMContentLoaded", function () {
    var btn = document.getElementById("countdown-extend-btn");
    if (btn) {
      btn.addEventListener("click", handleExtendCountdownClick);
    }
  });

  if (
    document.readyState === "interactive" ||
    document.readyState === "complete"
  ) {
    var btnNow = document.getElementById("countdown-extend-btn");
    if (btnNow && !btnNow.__aiiaExtendBound) {
      btnNow.__aiiaExtendBound = true;
      btnNow.addEventListener("click", handleExtendCountdownClick);
    }
  }
}

function _resolveFreezeCountdownLabel(state) {
  var key;
  var fallback;
  if (state === "ariaLabel") {
    key = "page.freezeCountdown.ariaLabel";
    fallback = "Freeze auto-resubmit countdown (one-time)";
  } else if (state === "title") {
    key = "page.freezeCountdown.title";
    fallback = "Permanently disable auto-resubmit for this task";
  } else if (state === "label") {
    key = "page.freezeCountdown.label";
    fallback = "Freeze";
  } else if (state === "alreadyFrozen") {
    key = "page.freezeCountdown.alreadyFrozen";
    fallback = "Already frozen";
  } else {
    key = "page.freezeCountdown.networkError";
    fallback = "Failed to freeze countdown";
  }
  var v;
  if (key === "page.freezeCountdown.ariaLabel") {
    v = _t("page.freezeCountdown.ariaLabel");
  } else if (key === "page.freezeCountdown.title") {
    v = _t("page.freezeCountdown.title");
  } else if (key === "page.freezeCountdown.label") {
    v = _t("page.freezeCountdown.label");
  } else if (key === "page.freezeCountdown.alreadyFrozen") {
    v = _t("page.freezeCountdown.alreadyFrozen");
  } else {
    v = _t("page.freezeCountdown.networkError");
  }
  return typeof v === "string" && v.length > 0 && v !== key ? v : fallback;
}

function updateFreezeCountdownButton(task) {
  if (typeof document === "undefined") return;
  var btn = document.getElementById("countdown-freeze-btn");
  if (!btn) return;
  if (
    !task ||
    typeof task.auto_resubmit_timeout !== "number" ||
    task.status === "completed" ||
    task.auto_resubmit_timeout <= 0
  ) {
    btn.classList.add("hidden");
    btn.disabled = true;
    return;
  }
  btn.classList.remove("hidden");
  btn.disabled = false;
  btn.setAttribute("title", _resolveFreezeCountdownLabel("title"));
  btn.setAttribute("aria-label", _resolveFreezeCountdownLabel("ariaLabel"));
}

function handleFreezeCountdownClick() {
  if (typeof document === "undefined" || typeof fetch === "undefined") return;
  var btn = document.getElementById("countdown-freeze-btn");
  if (!btn || btn.disabled) return;
  var taskId = window.activeTaskId;
  if (!taskId) return;
  btn.disabled = true;
  try {
    fetch("/api/tasks/" + encodeURIComponent(taskId) + "/freeze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    })
      .then(function (resp) {
        return resp.json().then(function (data) {
          return { ok: resp.ok, data: data };
        });
      })
      .then(function (res) {
        if (!res.ok || !res.data || !res.data.success) {
          var code = (res.data && res.data.code) || "unknown";
          console.warn("Freeze countdown failed:", code);
          if (typeof window.showInPageMessage === "function") {
            try {
              window.showInPageMessage(
                code === "already_frozen"
                  ? _resolveFreezeCountdownLabel("alreadyFrozen")
                  : _resolveFreezeCountdownLabel("networkError"),
                "warning",
              );
            } catch (_e) {

            }
          }
          btn.disabled = false;
          return;
        }

        var task = findTaskById(window.currentTasks || [], taskId);
        if (task) {
          task.auto_resubmit_timeout = 0;
          task.remaining_time = 0;
          updateFreezeCountdownButton(task);

          if (typeof updateCountdownExtendButton === "function") {
            updateCountdownExtendButton(task);
          }
        }

        if (typeof window.taskDeadlines === "object" && window.taskDeadlines) {
          delete window.taskDeadlines[taskId];
        }

        _clearTaskCountdown(taskId);
        if (typeof window.updateCountdownDisplay === "function") {
          window.updateCountdownDisplay(0);
        }
      })
      .catch(function (e) {
        console.warn("Freeze countdown network error:", e);
        btn.disabled = false;
      });
  } catch (e) {
    console.warn("Freeze countdown invocation failed:", e);
    btn.disabled = false;
  }
}

if (
  typeof document !== "undefined" &&
  !window.__aiiaFreezeBtnBound
) {
  window.__aiiaFreezeBtnBound = true;
  document.addEventListener("DOMContentLoaded", function () {
    var btn = document.getElementById("countdown-freeze-btn");
    if (btn) {
      btn.addEventListener("click", handleFreezeCountdownClick);
    }
  });
  if (
    document.readyState === "interactive" ||
    document.readyState === "complete"
  ) {
    var btnFreezeNow = document.getElementById("countdown-freeze-btn");
    if (btnFreezeNow && !btnFreezeNow.__aiiaFreezeBound) {
      btnFreezeNow.__aiiaFreezeBound = true;
      btnFreezeNow.addEventListener("click", handleFreezeCountdownClick);
    }
  }
}

function _resolveSseStatusLabel(state) {
  var key;
  var fallback;
  if (state === SSE_STATUS_CONNECTED) {
    key = "page.sseStatus.connected";
    fallback = "Connected";
  } else if (state === SSE_STATUS_RECONNECTING) {
    key = "page.sseStatus.reconnecting";
    fallback = "Reconnecting…";
  } else {
    key = "page.sseStatus.disconnected";
    fallback = "Disconnected";
  }
  var v;
  if (key === "page.sseStatus.connected") {
    v = _t("page.sseStatus.connected");
  } else if (key === "page.sseStatus.reconnecting") {
    v = _t("page.sseStatus.reconnecting");
  } else {
    v = _t("page.sseStatus.disconnected");
  }
  return typeof v === "string" && v.length > 0 && v !== key ? v : fallback;
}

function _setSseStatus(state) {
  if (typeof document === "undefined") return;
  var el = document.getElementById("sse-status-indicator");
  if (!el) return;
  el.setAttribute("data-sse-state", state);

  var label = _resolveSseStatusLabel(state);
  el.setAttribute("title", label);
  el.setAttribute("aria-label", label);

  var stateKey =
    state === SSE_STATUS_CONNECTED
      ? "page.sseStatus.connected"
      : state === SSE_STATUS_RECONNECTING
        ? "page.sseStatus.reconnecting"
        : "page.sseStatus.disconnected";
  el.setAttribute("data-i18n-title", stateKey);
  el.setAttribute("data-i18n-aria-label", stateKey);
}

var _suppressConfigChangedToastUntilMs = 0;

function _isConfigChangedToastSuppressed() {
  if (
    !_suppressConfigChangedToastUntilMs ||
    typeof Date === "undefined" ||
    typeof Date.now !== "function"
  ) {
    return false;
  }
  return Date.now() < _suppressConfigChangedToastUntilMs;
}

if (typeof window !== "undefined") {
  window.suppressLocalConfigChangedEcho = function (ms) {
    if (typeof Date === "undefined" || typeof Date.now !== "function") return 0;
    var durationMs = typeof ms === "number" && ms > 0 ? ms : 5000;
    var until = Date.now() + durationMs;
    if (until > _suppressConfigChangedToastUntilMs) {
      _suppressConfigChangedToastUntilMs = until;
    }
    return _suppressConfigChangedToastUntilMs;
  };

  window.__aiiaResetConfigChangedSuppression = function () {
    _suppressConfigChangedToastUntilMs = 0;
  };
}

var _lastEventId = null;

function _connectDirectSSE(sharedLeaderMode) {
  if (typeof EventSource === "undefined") return;
  if (_sseSource) {
    try {
      _sseSource.close();
    } catch (_) {

    }
    _sseSource = null;
  }

  var sseUrl = "/api/events";
  if (_lastEventId) {
    var sep = sseUrl.indexOf("?") >= 0 ? "&" : "?";
    sseUrl += sep + "last_event_id=" + encodeURIComponent(_lastEventId);
  }
  var source = new EventSource(sseUrl);
  _sseSource = source;

  source.onopen = function () {
    if (_sseSource !== source) return;
    _sseConnected = true;
    _sseReconnectDelay = 1000;
    _debugLog("SSE connected; polling degraded to safety-net mode (30s)");
    tasksPollBackoffMs = TASKS_POLL_SSE_FALLBACK_MS;
    if (tasksPollingTimer) {
      clearTimeout(tasksPollingTimer);
      scheduleNextTasksPoll(TASKS_POLL_SSE_FALLBACK_MS);
    }

    _setSseStatus(SSE_STATUS_CONNECTED);
    if (sharedLeaderMode) {
      _postSseSharedMessage({ kind: "open", leaderId: _sseSharedClientId });
    }
  };

  source.addEventListener("task_changed", function (e) {
    if (_sseSource !== source) return;

    if (e && typeof e.lastEventId === "string" && e.lastEventId !== "") {
      _lastEventId = e.lastEventId;
    }
    _debugSseTaskChanged(e && typeof e.data === "string" ? e.data : "{}");

    _scheduleSharedSseFetch("sse", 80);
    if (sharedLeaderMode) {
      _postSseSharedMessage({
        kind: "event",
        eventType: "task_changed",
        data: e && typeof e.data === "string" ? e.data : "",
        eventLastEventId:
          e && typeof e.lastEventId === "string" ? e.lastEventId : "",
      });
    }
  });

  source.addEventListener("gap_warning", function (e) {
    if (_sseSource !== source) return;
    _debugLog("SSE gap_warning received, fetching tasks for full resync");
    _debugSseDetail(
      "SSE gap_warning detail:",
      e && typeof e.data === "string" ? e.data : "{}",
    );
    _scheduleSharedSseFetch("sse-gap", 0);
    if (sharedLeaderMode) {
      _postSseSharedMessage({
        kind: "event",
        eventType: "gap_warning",
        data: e && typeof e.data === "string" ? e.data : "",
      });
    }
  });

  source.addEventListener("config_changed", function (e) {
    if (_sseSource !== source) return;
    _debugLog("SSE config_changed received");

    var fallbackHint =
      "Configuration file changed. Reload the page to see the latest values.";
    var hint = _t("status.configChangedReload");
    if (!hint || hint === "status.configChangedReload") {
      hint = fallbackHint;
    }
    try {
      var detail = JSON.parse(e && e.data ? e.data : "{}");
      _debugLog("SSE config_changed detail:", detail);

      if (
        hint === fallbackHint &&
        detail &&
        typeof detail.hint === "string" &&
        detail.hint
      ) {
        hint = detail.hint;
      }
    } catch (_) {

    }
    if (_isConfigChangedToastSuppressed()) {
      _debugLog(
        "SSE config_changed toast suppressed (local-save echo window active)",
      );
      return;
    }

    if (typeof _showToast === "function") {
      try {
        _showToast(hint);
      } catch (_) {

      }
    } else if (typeof console !== "undefined" && console && console.info) {
      try {
        console.info("[aiia] config_changed:", hint);
      } catch (_) {

      }
    }
    if (sharedLeaderMode) {
      _postSseSharedMessage({
        kind: "event",
        eventType: "config_changed",
        data: e && typeof e.data === "string" ? e.data : "",
      });
    }
  });

  source.addEventListener("heartbeat", function (e) {
    if (_sseSource !== source) return;
    _debugSseDetail(
      "SSE heartbeat:",
      e && typeof e.data === "string" ? e.data : "{}",
    );
    if (sharedLeaderMode) {
      _postSseSharedMessage({
        kind: "event",
        eventType: "heartbeat",
        data: e && typeof e.data === "string" ? e.data : "",
      });
    }
  });

  source.onerror = function () {
    if (_sseSource !== source) return;
    _sseConnected = false;
    try {
      source.close();
    } catch (_) {

    }
    _sseSource = null;
    _debugLog(
      "SSE disconnected; falling back to short-interval polling, reconnecting in " +
        _sseReconnectDelay / 1000 +
        "s",
    );
    tasksPollBackoffMs = TASKS_POLL_BASE_MS;
    if (tasksPollingTimer) {
      clearTimeout(tasksPollingTimer);
      scheduleNextTasksPoll(0);
    }
    if (_sseReconnectTimer) clearTimeout(_sseReconnectTimer);
    _sseReconnectTimer = setTimeout(function () {
      if (typeof document !== "undefined" && document.hidden) return;
      if (sharedLeaderMode && !_sseSharedIsLeader) return;
      _connectDirectSSE(sharedLeaderMode);
    }, _sseReconnectDelay);
    if (sharedLeaderMode) {
      _postSseSharedMessage({
        kind: "error",
        reconnectInMs: _sseReconnectDelay,
      });
    }

    _setSseStatus(
      _sseReconnectDelay >= SSE_STATUS_DISCONNECTED_DELAY_MS
        ? SSE_STATUS_DISCONNECTED
        : SSE_STATUS_RECONNECTING,
    );
    _sseReconnectDelay = Math.min(30000, _sseReconnectDelay * 2);
  };
}

function _sseNowMs() {
  if (typeof Date !== "undefined" && typeof Date.now === "function") {
    return Date.now();
  }
  return new Date().getTime();
}

function _makeSseSharedClientId() {
  var randomPart = "fallback";
  try {
    randomPart = Math.random().toString(36).slice(2, 10);
  } catch (_) {

  }
  return "tab-" + _sseNowMs().toString(36) + "-" + randomPart;
}

function _getBroadcastChannelCtor() {
  try {
    if (
      typeof window !== "undefined" &&
      typeof window.BroadcastChannel === "function"
    ) {
      return window.BroadcastChannel;
    }
    if (typeof BroadcastChannel === "function") return BroadcastChannel;
  } catch (_) {

  }
  return null;
}

function _postSseSharedMessage(message) {
  try {
    if (!_sseSharedChannel || typeof _sseSharedChannel.postMessage !== "function") {
      return;
    }
    message.clientId = _sseSharedClientId;
    message.ts = _sseNowMs();
    if (_lastEventId) message.lastEventId = _lastEventId;
    _sseSharedChannel.postMessage(message);
  } catch (_) {

  }
}

function _closeSseSource() {
  if (_sseSource) {
    try {
      _sseSource.close();
    } catch (_) {

    }
    _sseSource = null;
  }
}

function _markSharedSseConnected() {
  _sseConnected = true;
  _sseReconnectDelay = 1000;
  tasksPollBackoffMs = TASKS_POLL_SSE_FALLBACK_MS;
  if (tasksPollingTimer) {
    clearTimeout(tasksPollingTimer);
    scheduleNextTasksPoll(TASKS_POLL_SSE_FALLBACK_MS);
  }
  _setSseStatus(SSE_STATUS_CONNECTED);
}

function _updateSharedLastEventId(lastEventId) {
  if (typeof lastEventId !== "string" || lastEventId === "") return;
  var nextNum = Number(lastEventId);
  var prevNum = _lastEventId ? Number(_lastEventId) : NaN;
  if (
    !Number.isFinite(nextNum) ||
    !Number.isFinite(prevNum) ||
    nextNum >= prevNum
  ) {
    _lastEventId = lastEventId;
  }
}

function _scheduleSharedSseFetch(reason, delayMs) {
  if (_sseDebounceTimer) clearTimeout(_sseDebounceTimer);

  if (typeof document !== "undefined" && document.hidden) {
    fetchAndApplyTasks(reason);
    return;
  }
  _sseDebounceTimer = setTimeout(function () {
    _sseDebounceTimer = null;
    fetchAndApplyTasks(reason);
  }, Math.max(0, delayMs || 0));
}

function _consumeSharedSseEvent(message) {
  if (!message || _sseSharedIsLeader) return;
  _sseSharedLeaderSeenAtMs = _sseNowMs();
  var eventType = String(message.eventType || "");
  var data = typeof message.data === "string" ? message.data : "";
  var lastEventId =
    typeof message.eventLastEventId === "string"
      ? message.eventLastEventId
      : typeof message.lastEventId === "string"
        ? message.lastEventId
        : "";

  if (eventType === "task_changed") {
    _updateSharedLastEventId(lastEventId);
    _debugSseTaskChanged(data);
    _scheduleSharedSseFetch("sse", 80);
  } else if (eventType === "gap_warning") {
    _debugLog("SSE gap_warning received, fetching tasks for full resync");
    _debugSseDetail("SSE gap_warning detail:", data);
    _scheduleSharedSseFetch("sse-gap", 0);
  } else if (eventType === "config_changed") {

    var fallbackHint =
      "Configuration file changed. Reload the page to see the latest values.";
    var hint = _t("status.configChangedReload");
    if (!hint || hint === "status.configChangedReload") hint = fallbackHint;
    try {
      var cfgDetail = JSON.parse(data || "{}");
      _debugLog("SSE config_changed detail:", cfgDetail);
      if (
        hint === fallbackHint &&
        cfgDetail &&
        typeof cfgDetail.hint === "string" &&
        cfgDetail.hint
      ) {
        hint = cfgDetail.hint;
      }
    } catch (_) {

    }
    if (!_isConfigChangedToastSuppressed()) {
      if (typeof _showToast === "function") {
        try {
          _showToast(hint);
        } catch (_) {

        }
      } else if (typeof console !== "undefined" && console && console.info) {
        try {
          console.info("[aiia] config_changed:", hint);
        } catch (_) {

        }
      }
    }
  } else if (eventType === "heartbeat") {
    _debugSseDetail("SSE heartbeat:", data);
  }
}

function _broadcastSseLeader() {
  _postSseSharedMessage({
    kind: "leader",
    leaderId: _sseSharedClientId,
  });
}

function _stepDownFromSseLeader(leaderId) {
  _sseSharedIsLeader = false;
  _sseSharedLeaderId = leaderId || _sseSharedLeaderId;
  _sseSharedLeaderSeenAtMs = _sseNowMs();
  if (_sseSharedLeaderHeartbeatTimer) {
    clearInterval(_sseSharedLeaderHeartbeatTimer);
    _sseSharedLeaderHeartbeatTimer = null;
  }
  _closeSseSource();
  _markSharedSseConnected();
}

function _becomeSseLeader() {
  if (!_sseSharedChannel) {
    _connectDirectSSE(false);
    return;
  }
  _sseSharedIsLeader = true;
  _sseSharedLeaderId = _sseSharedClientId;
  _sseSharedLeaderSeenAtMs = _sseNowMs();
  _broadcastSseLeader();
  if (_sseSharedLeaderHeartbeatTimer) {
    clearInterval(_sseSharedLeaderHeartbeatTimer);
  }
  _sseSharedLeaderHeartbeatTimer = setInterval(function () {
    if (_sseSharedIsLeader) _broadcastSseLeader();
  }, SSE_SHARED_LEADER_HEARTBEAT_MS);
  _connectDirectSSE(true);
}

function _scheduleSseLeaderElection(delayMs) {
  if (_sseSharedElectionTimer) clearTimeout(_sseSharedElectionTimer);
  _sseSharedElectionTimer = setTimeout(function () {
    _sseSharedElectionTimer = null;
    if (!_sseSharedChannel) return;
    if (
      _sseSharedLeaderId &&
      _sseNowMs() - _sseSharedLeaderSeenAtMs < SSE_SHARED_LEADER_STALE_MS
    ) {
      return;
    }
    _becomeSseLeader();
  }, Math.max(0, delayMs || SSE_SHARED_ELECTION_DELAY_MS));
}

function _handleSseLeaderMessage(message) {
  var leaderId =
    message && message.leaderId
      ? String(message.leaderId)
      : String((message && message.clientId) || "");
  if (!leaderId || leaderId === _sseSharedClientId) return;
  _updateSharedLastEventId(
    message && typeof message.lastEventId === "string"
      ? message.lastEventId
      : "",
  );

  if (_sseSharedIsLeader) {

    if (leaderId < _sseSharedClientId) {
      _stepDownFromSseLeader(leaderId);
    } else {
      _broadcastSseLeader();
    }
    return;
  }

  _sseSharedLeaderId = leaderId;
  _sseSharedLeaderSeenAtMs = _sseNowMs();
  _markSharedSseConnected();
}

function _onSseSharedMessage(event) {
  var message = event && event.data ? event.data : null;
  if (!message || typeof message !== "object") return;
  if (message.clientId && String(message.clientId) === _sseSharedClientId) {
    return;
  }
  var kind = String(message.kind || "");
  if (kind === "hello") {
    _updateSharedLastEventId(
      typeof message.lastEventId === "string" ? message.lastEventId : "",
    );
    if (_sseSharedIsLeader) _broadcastSseLeader();
  } else if (kind === "leader" || kind === "open") {
    _handleSseLeaderMessage(message);
  } else if (kind === "leader_gone") {
    var goneId = message.leaderId ? String(message.leaderId) : "";
    if (!goneId || goneId === _sseSharedLeaderId) {
      _sseSharedLeaderId = null;
      _sseSharedLeaderSeenAtMs = 0;
      _sseConnected = false;
      _setSseStatus(SSE_STATUS_RECONNECTING);
      _scheduleSseLeaderElection(50);
    }
  } else if (kind === "event") {
    _consumeSharedSseEvent(message);
  } else if (kind === "error" && !_sseSharedIsLeader) {
    _sseConnected = false;
    tasksPollBackoffMs = TASKS_POLL_BASE_MS;
    _setSseStatus(SSE_STATUS_RECONNECTING);
    if (tasksPollingTimer) {
      clearTimeout(tasksPollingTimer);
      scheduleNextTasksPoll(0);
    }
  }
}

function _startSseSharedWatchdog() {
  if (_sseSharedWatchdogTimer) clearInterval(_sseSharedWatchdogTimer);
  _sseSharedWatchdogTimer = setInterval(function () {
    if (!_sseSharedChannel || _sseSharedIsLeader) return;
    if (
      !_sseSharedLeaderId ||
      _sseNowMs() - _sseSharedLeaderSeenAtMs > SSE_SHARED_LEADER_STALE_MS
    ) {
      _sseSharedLeaderId = null;
      _sseSharedLeaderSeenAtMs = 0;
      _sseConnected = false;
      _setSseStatus(SSE_STATUS_RECONNECTING);
      _scheduleSseLeaderElection(0);
    }
  }, Math.max(1000, Math.floor(SSE_SHARED_LEADER_STALE_MS / 2)));
}

function _connectSharedSSE() {
  var BroadcastChannelCtor = _getBroadcastChannelCtor();
  if (!BroadcastChannelCtor) {
    _connectDirectSSE(false);
    return;
  }
  try {
    if (!_sseSharedClientId) _sseSharedClientId = _makeSseSharedClientId();
    if (_sseSharedChannel) {
      _postSseSharedMessage({ kind: "hello" });
      _scheduleSseLeaderElection(SSE_SHARED_ELECTION_DELAY_MS);
      _startSseSharedWatchdog();
      return;
    }
    _sseSharedChannel = new BroadcastChannelCtor(SSE_SHARED_CHANNEL_NAME);
    _sseSharedChannel.onmessage = _onSseSharedMessage;
    _postSseSharedMessage({ kind: "hello" });
    _scheduleSseLeaderElection(SSE_SHARED_ELECTION_DELAY_MS);
    _startSseSharedWatchdog();
  } catch (_) {
    _sseSharedChannel = null;
    _connectDirectSSE(false);
  }
}

function _connectSSE() {
  if (typeof EventSource === "undefined") return;
  if (_getBroadcastChannelCtor()) {
    _connectSharedSSE();
  } else {
    _connectDirectSSE(false);
  }
}

function _disconnectSSE() {
  if (_sseReconnectTimer) {
    clearTimeout(_sseReconnectTimer);
    _sseReconnectTimer = null;
  }
  if (_sseDebounceTimer) {
    clearTimeout(_sseDebounceTimer);
    _sseDebounceTimer = null;
  }
  if (_sseSharedElectionTimer) {
    clearTimeout(_sseSharedElectionTimer);
    _sseSharedElectionTimer = null;
  }
  if (_sseSharedWatchdogTimer) {
    clearInterval(_sseSharedWatchdogTimer);
    _sseSharedWatchdogTimer = null;
  }
  if (_sseSharedLeaderHeartbeatTimer) {
    clearInterval(_sseSharedLeaderHeartbeatTimer);
    _sseSharedLeaderHeartbeatTimer = null;
  }
  if (_sseSharedIsLeader) {
    _postSseSharedMessage({
      kind: "leader_gone",
      leaderId: _sseSharedClientId,
    });
  }
  _sseSharedIsLeader = false;
  _sseSharedLeaderId = null;
  _sseSharedLeaderSeenAtMs = 0;
  if (_sseSharedChannel) {
    try {
      _sseSharedChannel.close();
    } catch (_) {

    }
    _sseSharedChannel = null;
  }
  _closeSseSource();
  _sseConnected = false;

  _setSseStatus(SSE_STATUS_CONNECTED);
}

function getNextBackoffMs(currentMs) {
  var next = Math.min(TASKS_POLL_MAX_MS, Math.round(currentMs * 1.7));
  var jitter = Math.round(next * 0.1 * Math.random());
  return next + jitter;
}

async function fetchAndApplyTasks(reason) {

  var sseDriven = reason === "sse" || reason === "sse-gap";
  if (typeof document !== "undefined" && document.hidden && !sseDriven) {
    return false;
  }

  if (isManualSwitching) {
    return false;
  }

  try {
    if (
      tasksPollAbortController &&
      typeof tasksPollAbortController.abort === "function"
    ) {
      tasksPollAbortController.abort();
    }
  } catch (e) {

  }

  let currentTasksPollController = null;
  if (typeof AbortController !== "undefined") {
    tasksPollAbortController = new AbortController();
    currentTasksPollController = tasksPollAbortController;
  } else {
    tasksPollAbortController = null;
  }

  const fetchOptions = {
    cache: "no-store",
  };
  if (currentTasksPollController) {
    fetchOptions.signal = currentTasksPollController.signal;
  }

  let tasksTimeoutId = null;
  if (currentTasksPollController) {
    tasksTimeoutId = setTimeout(() => {
      try {
        if (currentTasksPollController) {
          currentTasksPollController.abort();
        }
      } catch (e) {

      }
    }, TASKS_POLL_TIMEOUT_MS);
  }

  try {
    const response = await fetch("/api/tasks", fetchOptions);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const data = await response.json();

    if (data.success) {

      if (data.server_time) {
        const localTime = Date.now() / 1000;
        window.serverTimeOffset = data.server_time - localTime;

        if (Math.abs(window.serverTimeOffset) > 1) {
          _debugLog(
            `Server time offset: ${window.serverTimeOffset.toFixed(2)}s`,
          );
        }
      }

      if (data.tasks) {
        const taskCount = data.tasks.length;
        for (let index = 0; index < taskCount; index += 1) {
          if (!(index in data.tasks)) continue;
          const task = data.tasks[index];
          if (task.deadline) {
            window.taskDeadlines[task.task_id] = task.deadline;
          }

          if (
            taskCountdowns &&
            taskCountdowns[task.task_id] &&
            task.status !== "completed"
          ) {
            if (typeof task.auto_resubmit_timeout === "number") {

              if (task.auto_resubmit_timeout <= 0) {
                _clearTaskCountdown(task.task_id);
                delete window.taskDeadlines[task.task_id];
              } else {
                taskCountdowns[task.task_id].timeout =
                  task.auto_resubmit_timeout;
              }
            }
            if (
              typeof task.remaining_time === "number" &&
              taskCountdowns[task.task_id]
            ) {
              taskCountdowns[task.task_id].remaining = task.remaining_time;
            }
          }
        }
      }

      updateTasksList(data.tasks);
      updateTasksStats(data.stats);
      if (reason) {
        console.debug(`Task list updated: ${reason}`);
      }
      return true;
    }

    return false;
  } catch (error) {

    if (error && (error.name === "AbortError" || error.code === 20)) {
      return false;
    }
    console.error("Failed to fetch task list:", error);
    return false;
  } finally {

    if (tasksTimeoutId !== null) {
      try {
        clearTimeout(tasksTimeoutId);
      } catch (e) {

      }
      tasksTimeoutId = null;
    }

    if (tasksPollAbortController === currentTasksPollController) {
      tasksPollAbortController = null;
    }
  }
}

function scheduleNextTasksPoll(delayMs) {
  if (tasksPollingTimer) {
    clearTimeout(tasksPollingTimer);
    tasksPollingTimer = null;
  }
  tasksPollingTimer = setTimeout(
    async () => {
      const ok = await fetchAndApplyTasks("poll");
      if (ok) {
        tasksPollBackoffMs = TASKS_POLL_BASE_MS;
      } else {
        tasksPollBackoffMs = getNextBackoffMs(tasksPollBackoffMs);
      }
      scheduleNextTasksPoll(tasksPollBackoffMs);
    },
    Math.max(0, delayMs),
  );
}

function startTasksPolling() {
  if (typeof document !== "undefined" && document.hidden) {
    _debugLog("Page hidden; skip starting task polling");
    return;
  }

  stopTasksPolling();

  _connectSSE();

  tasksPollBackoffMs = _sseConnected
    ? TASKS_POLL_SSE_FALLBACK_MS
    : TASKS_POLL_BASE_MS;
  scheduleNextTasksPoll(0);

  if (!tasksPollVisibilityHandlerInstalled && typeof document !== "undefined") {
    tasksPollVisibilityHandlerInstalled = true;
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) {

        stopTasksPolling({ keepSse: true });
        stopTasksHealthCheck();
      } else {
        startTasksPolling();
        startTasksHealthCheck();
      }
    });
    window.addEventListener("beforeunload", function () {
      stopTasksPolling();

      stopTasksHealthCheck();
    });

    try {
      if (typeof window !== "undefined" && window.addEventListener) {
        window.addEventListener("online", function () {
          if (typeof document !== "undefined" && document.hidden) return;
          _debugLog(
            "Browser back online; restarting polling + SSE for fast recovery",
          );
          startTasksPolling();
          startTasksHealthCheck();
        });
      }
    } catch (_e) {

    }

    try {
      if (typeof window !== "undefined" && window.addEventListener) {
        window.addEventListener("pageshow", function (e) {
          if (!e || !e.persisted) return;
          if (typeof document !== "undefined" && document.hidden) return;
          _debugLog(
            "Page restored from BFCache; restarting polling + SSE for fast recovery",
          );
          startTasksPolling();
          startTasksHealthCheck();
        });
      }
    } catch (_e) {

    }
  }

  _debugLog("Task polling started (SSE preferred + polling safety-net)");
}

function stopTasksPolling(options) {
  if (tasksPollingTimer) {
    clearTimeout(tasksPollingTimer);
    tasksPollingTimer = null;
  }

  try {
    if (
      tasksPollAbortController &&
      typeof tasksPollAbortController.abort === "function"
    ) {
      tasksPollAbortController.abort();
    }
  } catch (e) {

  } finally {
    tasksPollAbortController = null;
  }

  if (!(options && options.keepSse)) {
    _disconnectSSE();
  }
}

function startTasksHealthCheck() {

  if (window.tasksHealthCheckTimer) {
    return;
  }
  window.tasksHealthCheckTimer = setInterval(function () {

    if (typeof document !== "undefined" && document.hidden) return;
    if (!tasksPollingTimer) {
      console.warn("Task polling stopped; auto-restarting");
      startTasksPolling();
    }
    if (!_sseConnected && !_sseReconnectTimer) {
      _connectSSE();
    }
  }, 30000);
}

function stopTasksHealthCheck() {
  if (window.tasksHealthCheckTimer) {
    clearInterval(window.tasksHealthCheckTimer);
    window.tasksHealthCheckTimer = null;
  }
}

let isManualSwitching = false;
let manualSwitchingTimer = null;

Object.defineProperty(window, "isManualSwitching", {
  get: () => isManualSwitching,
  set: (val) => {
    isManualSwitching = val;
  },
  configurable: true,
});

function updateTasksList(tasks) {
  const taskDiff = _buildTaskListDiff(currentTasks, tasks);
  const isInitialTaskSnapshot = !hasLoadedTaskSnapshot;

  const addedTasks = taskDiff.addedTaskIds;
  if (addedTasks.length > 0) {
    _debugLog(`Detected ${addedTasks.length} new task(s)`);

    if (!isInitialTaskSnapshot) {

      const pageHidden =
        typeof document !== "undefined" && document.hidden === true;

      if (activeTaskId && !pageHidden) {
        pendingNewTaskCount += addedTasks.length;
        window.pendingNewTaskCount = pendingNewTaskCount;

        if (newTaskHintTimer) {
          clearTimeout(newTaskHintTimer);
        }

        newTaskHintTimer = setTimeout(() => {
          if (pendingNewTaskCount > 0) {
            showNewTaskNotification(pendingNewTaskCount);
            pendingNewTaskCount = 0;
            window.pendingNewTaskCount = 0;
          }
          newTaskHintTimer = null;
          window.newTaskHintTimer = null;
        }, 150);
        window.newTaskHintTimer = newTaskHintTimer;
      } else {
        showNewTaskNotification(addedTasks.length);
      }
    }

    const addedTaskCount = taskDiff.addedTasks.length;
    for (let index = 0; index < addedTaskCount; index += 1) {
      if (!(index in taskDiff.addedTasks)) continue;
      const task = taskDiff.addedTasks[index];

      const addedTimeoutDisabled =
        typeof task.auto_resubmit_timeout === "number" &&
        task.auto_resubmit_timeout <= 0;
      if (
        task.status !== "completed" &&
        !taskCountdowns[task.task_id] &&
        !addedTimeoutDisabled
      ) {

        const timeout = task.remaining_time ?? task.auto_resubmit_timeout ?? 240;
        startTaskCountdown(
          task.task_id,
          timeout,
          task.auto_resubmit_timeout || 240,
        );
        _debugLog(
          `Started countdown for new task: ${task.task_id}, remaining ${timeout}s`,
        );
      }
    }
  }

  const removedTasks = taskDiff.removedTaskIds;
  if (removedTasks.length > 0) {
    _debugLog(`Detected ${removedTasks.length} removed task(s)`);
    const removedTaskCount = removedTasks.length;
    for (let index = 0; index < removedTaskCount; index += 1) {
      if (!(index in removedTasks)) continue;
      const taskId = removedTasks[index];
      clearTaskLocalState(taskId);
    }
  }

  const taskRefreshState = _buildTaskRefreshState(tasks, activeTaskId);
  const completedTaskIds = taskRefreshState.completedTaskIds;
  const completedTaskCount = completedTaskIds.length;
  for (let index = 0; index < completedTaskCount; index += 1) {
    if (!(index in completedTaskIds)) continue;
    const taskId = completedTaskIds[index];
    clearTaskLocalState(taskId);
  }

  const hasActiveTasks = taskRefreshState.hasActiveTasks;

  currentTasks = tasks;
  window.currentTasks = tasks;
  hasLoadedTaskSnapshot = true;
  window.hasLoadedTaskSnapshot = true;

  const taskCount = tasks.length;
  for (let index = 0; index < taskCount; index += 1) {
    if (!(index in tasks)) continue;
    const task = tasks[index];
    if (task.status === "completed") continue;

    const total =
      typeof task.auto_resubmit_timeout === "number"
        ? task.auto_resubmit_timeout
        : 240;
    if (total <= 0) {

      if (taskCountdowns[task.task_id]) {
        _clearTaskCountdown(task.task_id);
      }
      continue;
    }
    const existingCountdown = taskCountdowns[task.task_id];

    const shouldEnsure =
      !existingCountdown ||
      (task.status === "active" && !existingCountdown.timer);
    if (shouldEnsure) {
      const remaining = task.remaining_time ?? total;

      if (
        task.status === "active" &&
        typeof remaining === "number" &&
        remaining <= 0
      ) {
        autoSubmitTask(task.task_id);
      } else {
        startTaskCountdown(task.task_id, remaining, total);
      }
    }
  }

  const activeTask = taskRefreshState.serverActiveTask;
  const oldActiveTaskId = activeTaskId;
  const nextActiveTaskId = taskRefreshState.nextActiveTaskId;
  const activeTaskChanged = nextActiveTaskId !== oldActiveTaskId;
  if (activeTaskChanged) {
    setActiveTaskId(nextActiveTaskId);
    if (activeTaskId) {
      _debugLog(`Sync activeTaskId: ${oldActiveTaskId} -> ${activeTaskId}`);
    } else if (oldActiveTaskId) {
      _debugLog(
        `No open tasks remain; reset activeTaskId: ${oldActiveTaskId} -> null`,
      );
    } else {
      _debugLog("All tasks completed; not setting activeTaskId");
    }

    updateCountdownRingColors(oldActiveTaskId, activeTaskId);
  }

  if (typeof updateCountdownExtendButton === "function") {
    var _activeTask = taskRefreshState.activeTaskForControls;
    updateCountdownExtendButton(_activeTask);
    if (typeof updateFreezeCountdownButton === "function") {
      updateFreezeCountdownButton(_activeTask);
    }
  }

  const contentContainer = document.getElementById("content-container");
  const noContentContainer = document.getElementById("no-content-container");
  const isShowingNoContent =
    noContentContainer && noContentContainer.style.display === "flex";

  if (hasActiveTasks && isShowingNoContent) {

    _debugLog(
      "Tasks present but showing no-content page; switching to content page",
    );
    if (typeof showContentPage === "function") {
      showContentPage();
    }
  } else if (
    !hasActiveTasks &&
    contentContainer &&
    contentContainer.style.display === "block"
  ) {

    _debugLog(
      "No tasks but showing content page; switching to no-content page",
    );
    if (typeof showNoContentPage === "function") {
      showNoContentPage();
    }
  }

  renderTaskTabs();

  if (isManualSwitching) {
    return;
  }

  if (tryApplyDeepLinkedTask(tasks)) {
    return;
  }

  if (
    activeTaskId &&
    (activeTaskChanged ||
      window.lastLoadedDetailsTaskId !== activeTaskId ||
      (activeTask && getTaskIdString(activeTask) === activeTaskId))
  ) {
    loadTaskDetails(activeTaskId);
  }
}

function updateTasksStats(_stats) {

  return;
}

function _buildTaskTabRenderState(tasks, tabsContainer) {
  const incompleteTasks = [];
  const incompleteTaskIds = [];
  const incompleteTaskIdSet = new Set();

  if (Array.isArray(tasks)) {
    for (const task of tasks) {
      if (!task || task.status === "completed") continue;
      const taskId = task.task_id;
      incompleteTasks.push(task);
      incompleteTaskIds.push(taskId);
      incompleteTaskIdSet.add(taskId);
    }
  }

  const existingTabs =
    incompleteTasks.length > 0 &&
    tabsContainer &&
    typeof tabsContainer.querySelectorAll === "function"
      ? tabsContainer.querySelectorAll(".task-tab:not(.task-tab-exit)")
      : [];
  const existingTaskIds = [];
  const existingTaskIdSet = new Set();
  const existingTabCount = existingTabs.length;
  for (let index = 0; index < existingTabCount; index += 1) {
    if (!(index in existingTabs)) continue;
    const tab = existingTabs[index];
    const taskId = tab && tab.dataset ? tab.dataset.taskId : undefined;
    existingTaskIds.push(taskId);
    existingTaskIdSet.add(taskId);
  }

  let needsRebuild = existingTaskIds.length !== incompleteTaskIds.length;
  if (!needsRebuild) {
    for (let i = 0; i < existingTaskIds.length; i += 1) {
      if (existingTaskIds[i] !== incompleteTaskIds[i]) {
        needsRebuild = true;
        break;
      }
    }
  }

  const removedIds = [];
  const addedTasks = [];
  if (needsRebuild) {
    for (const id of existingTaskIds) {
      if (!incompleteTaskIdSet.has(id)) {
        removedIds.push(id);
      }
    }
    for (const task of incompleteTasks) {
      if (!existingTaskIdSet.has(task.task_id)) {
        addedTasks.push(task);
      }
    }
  }

  return {
    incompleteTasks,
    incompleteTaskIds,
    existingTabs,
    existingTaskIds,
    needsRebuild,
    removedIds,
    addedTasks,
  };
}

function renderTaskTabs() {
  const tabsContainer = document.getElementById("task-tabs");
  const container = document.getElementById("task-tabs-container");

  if (!container || !tabsContainer) {
    console.warn(
      "Tab bar container not found; DOM may not be ready yet, retrying in 100ms",
    );
    setTimeout(() => {
      const retryContainer = document.getElementById("task-tabs-container");
      const retryTabsContainer = document.getElementById("task-tabs");
      if (retryContainer && retryTabsContainer) {
        _debugLog("Retry succeeded; rendering tab bar");
        renderTaskTabs();
      } else {
        console.error("Retry failed; tab bar container still missing");
      }
    }, 100);
    return;
  }

  const tabState = _buildTaskTabRenderState(currentTasks, tabsContainer);
  const incompleteTasks = tabState.incompleteTasks;

  if (incompleteTasks.length === 0) {
    container.classList.add("hidden");
    return;
  }

  container.classList.remove("hidden");

  if (tabState.needsRebuild) {
    const isIncremental =
      tabState.removedIds.length + tabState.addedTasks.length <= 2 &&
      tabState.existingTaskIds.length > 0;

    if (isIncremental) {
      const removedTabCount = tabState.removedIds.length;
      for (let index = 0; index < removedTabCount; index += 1) {
        if (!(index in tabState.removedIds)) continue;
        const id = tabState.removedIds[index];
        const el = tabsContainer.querySelector(`[data-task-id="${id}"]`);
        if (el) {
          el.classList.add("task-tab-exit");
          el.addEventListener("animationend", () => el.remove(), {
            once: true,
          });
          setTimeout(() => {
            if (el.parentNode) el.remove();
          }, 300);
        }
      }
      const addedTabCount = tabState.addedTasks.length;
      for (let index = 0; index < addedTabCount; index += 1) {
        if (!(index in tabState.addedTasks)) continue;
        const task = tabState.addedTasks[index];
        const tab = createTaskTab(task);
        tab.classList.add("task-tab-enter");
        tab.addEventListener(
          "animationend",
          () => tab.classList.remove("task-tab-enter"),
          {
            once: true,
          },
        );
        tabsContainer.appendChild(tab);
      }
    } else {
      tabsContainer.innerHTML = "";
      const incompleteTaskCount = incompleteTasks.length;
      for (let index = 0; index < incompleteTaskCount; index += 1) {
        if (!(index in incompleteTasks)) continue;
        const task = incompleteTasks[index];
        const tab = createTaskTab(task);
        tab.classList.add("task-tab-enter");
        tab.style.animationDelay = index * 60 + "ms";
        tab.addEventListener(
          "animationend",
          () => {
            tab.classList.remove("task-tab-enter");
            tab.style.animationDelay = "";
          },
          { once: true },
        );
        tabsContainer.appendChild(tab);
      }
    }
    const activeTabs = tabsContainer.querySelectorAll(
      ".task-tab:not(.task-tab-exit)",
    );
    const activeTabCount = activeTabs.length;
    for (let index = 0; index < activeTabCount; index += 1) {
      if (!(index in activeTabs)) continue;
      const tab = activeTabs[index];
      const taskId = tab.dataset.taskId;
      const isActive = taskId === activeTaskId;
      tab.classList.toggle("active", isActive);
      tab.setAttribute("aria-selected", isActive ? "true" : "false");
      tab.setAttribute("tabindex", isActive ? "0" : "-1");
    }
  } else {
    const syncedTabCount = tabState.existingTabs.length;
    for (let index = 0; index < syncedTabCount; index += 1) {
      if (!(index in tabState.existingTabs)) continue;
      const tab = tabState.existingTabs[index];
      const taskId = tab.dataset.taskId;
      const isActive = taskId === activeTaskId;
      tab.classList.toggle("active", isActive);
      tab.setAttribute("aria-selected", isActive ? "true" : "false");
      tab.setAttribute("tabindex", isActive ? "0" : "-1");
    }
  }

  _updateTabsOverflowHint();
}

function _updateTabsOverflowHint() {

  try {
    const tabs = document.getElementById("task-tabs");
    const container = document.getElementById("task-tabs-container");
    if (!tabs || !container || !container.dataset) return;
    _installTabsOverflowHintListeners(tabs);

    const scrollLeft = tabs.scrollLeft || 0;
    const clientWidth = tabs.clientWidth || 0;
    const scrollWidth = tabs.scrollWidth || 0;
    const overflowRight = scrollLeft + clientWidth < scrollWidth - 1;
    const overflowLeft = scrollLeft > 1;
    container.dataset.overflowRight = overflowRight ? "true" : "false";
    container.dataset.overflowLeft = overflowLeft ? "true" : "false";
  } catch (_e) {

  }
}

let _tabsOverflowListenersInstalled = false;

function _installTabsOverflowHintListeners(tabs) {
  if (_tabsOverflowListenersInstalled) return;
  _tabsOverflowListenersInstalled = true;
  try {
    tabs.addEventListener("scroll", _updateTabsOverflowHint, {
      passive: true,
    });
    window.addEventListener("resize", _updateTabsOverflowHint, {
      passive: true,
    });
  } catch (_e) {

  }
}

function createTaskTab(task) {
  const tab = document.createElement("div");
  tab.className = "task-tab";
  tab.setAttribute("role", "tab");
  tab.setAttribute(
    "aria-selected",
    task.status === "active" ? "true" : "false",
  );
  tab.setAttribute("tabindex", task.status === "active" ? "0" : "-1");
  if (task.status === "active") {
    tab.classList.add("active");
  }
  tab.dataset.taskId = task.task_id;

  const textSpan = document.createElement("span");
  textSpan.className = "task-tab-text";

  let displayName;
  if (
    typeof task.header_label === "string" &&
    task.header_label.trim() !== ""
  ) {
    displayName = task.header_label.trim().slice(0, 16);
  } else {

    const taskParts = task.task_id.split("-");
    const lastPart = taskParts[taskParts.length - 1];
    const prefixParts = taskParts.slice(0, -1).join("-");

    if (prefixParts.length > 12) {

      displayName = `${prefixParts.substring(0, 11)}... ${lastPart}`;
    } else {
      displayName = `${prefixParts} ${lastPart}`;
    }
  }

  textSpan.textContent = displayName;

  const tooltipSuffix =
    (typeof window !== "undefined" &&
      window.AIIA_I18N &&
      typeof window.AIIA_I18N.t === "function" &&
      window.AIIA_I18N.t("page.taskTabCopyHint")) ||
    "Double-click to copy ID · Shift+double-click to copy link";
  textSpan.title = `${task.task_id}\n${tooltipSuffix}`;
  textSpan.setAttribute("data-copy-hint-suffix", tooltipSuffix);

  textSpan.style.cursor = "pointer";
  textSpan.setAttribute("data-copyable-task-id", task.task_id);
  textSpan.addEventListener("dblclick", function (e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.shiftKey) {
      copyTaskLinkToClipboard(task.task_id);
    } else {
      copyTaskIdToClipboard(task.task_id);
    }
  });

  tab.appendChild(textSpan);

  if (
    typeof task.iteration_label === "string" &&
    task.iteration_label.trim() !== ""
  ) {
    const iterBadge = document.createElement("span");
    iterBadge.className = "task-tab-iter";
    iterBadge.textContent = task.iteration_label.trim();
    iterBadge.setAttribute("aria-hidden", "true");
    tab.appendChild(iterBadge);
  }

  if (task.status !== "completed") {
    const countdownRing = document.createElement("div");
    countdownRing.className = "countdown-ring";
    countdownRing.id = `countdown-${task.task_id}`;

    let remaining, total;
    if (taskCountdowns[task.task_id]) {
      remaining = taskCountdowns[task.task_id].remaining;

      total = taskCountdowns[task.task_id].timeout || 240;
    } else {

      remaining = task.remaining_time ?? task.auto_resubmit_timeout ?? 240;
      total = task.auto_resubmit_timeout || 240;
    }

    const radius = 9;
    const circumference = 2 * Math.PI * radius;
    const progress = remaining / total;
    const offset = circumference * (1 - progress);

    const isActive = task.task_id === activeTaskId;
    const strokeColor = isActive
      ? "rgba(255, 255, 255, 0.9)"
      : "rgba(217, 119, 87, 0.9)";

    countdownRing.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 22 22">
        <circle
          cx="11" cy="11" r="${radius}"
          stroke="${strokeColor}"
          stroke-width="3"
          fill="none"
          stroke-dasharray="${circumference}"
          stroke-dashoffset="${offset}"
          stroke-linecap="round"
        />
      </svg>
      <span class="countdown-number">${remaining}</span>
    `;
    countdownRing.title = _t("page.countdown", { seconds: remaining });

    tab.appendChild(countdownRing);
  }

  tab.onclick = () => switchTask(task.task_id);

  return tab;
}

async function switchTask(taskId) {

  if (activeTaskId) {
    const textarea = document.getElementById("feedback-text");
    if (textarea) {
      taskTextareaContents[activeTaskId] = textarea.value;
      _debugLog(`Saved textarea content for task ${activeTaskId}`);
    }

    const optionsContainer = document.getElementById("options-container");
    if (optionsContainer) {
      const checkboxes = optionsContainer.querySelectorAll(
        'input[type="checkbox"]',
      );
      const optionsStates = [];
      const optionCheckboxCount = checkboxes.length;
      for (let index = 0; index < optionCheckboxCount; index += 1) {
        if (!(index in checkboxes)) continue;
        const checkbox = checkboxes[index];
        optionsStates[index] = checkbox.checked;
      }
      taskOptionsStates[activeTaskId] = optionsStates;
      _debugLog(`Saved option selection state for task ${activeTaskId}`);
    }

    taskImages[activeTaskId] = cloneTaskImagesForState(selectedImages);
    _debugLog(
      `Saved image list for task ${activeTaskId} (${selectedImages.length} images)`,
    );
  }

  isManualSwitching = true;

  window.dispatchEvent(
    new CustomEvent("taskSwitchStart", { detail: { taskId } }),
  );

  const oldActiveTaskId = activeTaskId;
  setActiveTaskId(taskId);
  renderTaskTabs();

  updateCountdownRingColors(oldActiveTaskId, taskId);

  const cachedTask = findTaskById(currentTasks, taskId);
  if (cachedTask && cachedTask.prompt) {
    _debugLog(`Updating UI from cached task info immediately: ${taskId}`);

    const taskIdContainer = document.getElementById("task-id-container");
    const taskIdText = document.getElementById("task-id-text");
    if (taskIdContainer && taskIdText) {
      if (cachedTask.task_id && cachedTask.task_id.trim()) {
        taskIdText.textContent = cachedTask.task_id;
        taskIdContainer.classList.remove("hidden");
      } else {
        taskIdContainer.classList.add("hidden");
      }
    }

    updateDescriptionDisplay(cachedTask.prompt);
    if (cachedTask.predefined_options) {
      updateOptionsDisplay(
        cachedTask.predefined_options,
        cachedTask.predefined_options_defaults,
      );
    }

    updateFeedbackPlaceholder(cachedTask.feedback_placeholder);

    updateHeaderChip(cachedTask.header_label);

    updateLoopContext(cachedTask);
  }

  try {

    fetchWithTimeout(`/api/tasks/${taskId}/activate`, { method: "POST" }, 10000)
      .then((res) => res.json())
      .then((data) => {
        if (!data.success) {
          console.error("Activate task failed:", data.error);
        } else {
          _debugLog(`Task activated: ${taskId}`);
        }
      })
      .catch((err) => console.error("Activate task failed:", err));

    loadTaskDetails(taskId).catch((err) => {
      console.warn(
        "Load task details failed, but UI was updated from cache:",
        err,
      );
    });
  } catch (error) {
    console.error("Switch task failed:", error);
  } finally {

    if (manualSwitchingTimer) {
      clearTimeout(manualSwitchingTimer);
    }
    manualSwitchingTimer = setTimeout(() => {
      isManualSwitching = false;
      manualSwitchingTimer = null;

      window.dispatchEvent(
        new CustomEvent("taskSwitchComplete", { detail: { taskId } }),
      );
      _debugLog("Task switch lock released; polling resumed");
    }, 200);
  }
}

function updateCountdownRingColors(oldActiveTaskId, newActiveTaskId) {

  if (oldActiveTaskId) {
    const oldRing = document.getElementById(`countdown-${oldActiveTaskId}`);
    if (oldRing) {
      const oldCircle = oldRing.querySelector("circle");
      if (oldCircle) {
        oldCircle.setAttribute("stroke", "rgba(217, 119, 87, 0.9)");
      }
    }
  }

  if (newActiveTaskId) {
    const newRing = document.getElementById(`countdown-${newActiveTaskId}`);
    if (newRing) {
      const newCircle = newRing.querySelector("circle");
      if (newCircle) {
        newCircle.setAttribute("stroke", "rgba(255, 255, 255, 0.9)");
      }
    }
  }
}

async function loadTaskDetails(taskId) {
  try {
    const response = await fetchWithTimeout(
      `/api/tasks/${taskId}`,
      undefined,
      10000,
    );
    const data = await response.json();

    if (taskId !== activeTaskId) {
      _debugLog(
        `Skipping stale task details: ${taskId} (active: ${activeTaskId})`,
      );
      return;
    }

    if (data.success) {
      const task = data.task;

      const taskIdContainer = document.getElementById("task-id-container");
      const taskIdText = document.getElementById("task-id-text");
      if (taskIdContainer && taskIdText) {
        if (task.task_id && task.task_id.trim()) {
          taskIdText.textContent = task.task_id;
          taskIdContainer.classList.remove("hidden");
        } else {
          taskIdContainer.classList.add("hidden");
        }
      }

      updateDescriptionDisplay(task.prompt);
      updateOptionsDisplay(
        task.predefined_options,
        task.predefined_options_defaults,
      );

      window.lastLoadedDetailsTaskId = taskId;

      updateFeedbackPlaceholder(task.feedback_placeholder);

      updateHeaderChip(task.header_label);

      updateLoopContext(task);

      const textarea = document.getElementById("feedback-text");
      if (textarea && taskTextareaContents[taskId] !== undefined) {
        textarea.value = taskTextareaContents[taskId];
        _debugLog(`Restored textarea content for task ${taskId}`);
      }

      if (taskImages[taskId] && taskImages[taskId].length > 0) {

        selectedImages = cloneTaskImagesForState(taskImages[taskId]);

        const previewContainer = document.getElementById("image-previews");
        if (previewContainer) {
          previewContainer.innerHTML = "";
          const restoredImageCount = selectedImages.length;
          for (
            let imageIndex = 0;
            imageIndex < restoredImageCount;
            imageIndex += 1
          ) {
            if (!(imageIndex in selectedImages)) continue;
            const imageItem = selectedImages[imageIndex];
            renderImagePreview(imageItem, false);
          }
          updateImageCounter();
          updateImagePreviewVisibility();
        }
        _debugLog(
          `Restored image list for task ${taskId} (${selectedImages.length} images)`,
        );
      }

      const detailsTimeoutDisabled =
        typeof task.auto_resubmit_timeout === "number" &&
        task.auto_resubmit_timeout <= 0;
      if (!taskCountdowns[task.task_id] && !detailsTimeoutDisabled) {

        const remaining = task.remaining_time ?? task.auto_resubmit_timeout;
        const total = task.auto_resubmit_timeout;
        startTaskCountdown(task.task_id, remaining, total);
        _debugLog(
          `First-time countdown start: ${taskId}, remaining ${remaining}s / total ${total}s`,
        );
      } else {
        _debugLog(`Countdown already exists; not resetting: ${taskId}`);
      }

      maybeApplyPendingInputFocus();

      _debugLog(`Task details loaded: ${taskId}`);
    } else {
      console.error("Load task details failed:", data.error);
    }
  } catch (error) {
    console.error("Load task details failed:", error);
  }
}

async function updateDescriptionDisplay(prompt) {
  const descriptionElement = document.getElementById("description");
  if (!descriptionElement) return;

  const descriptionDataset = descriptionElement.dataset || null;
  if (
    descriptionDataset &&
    descriptionDataset.renderedPrompt === prompt &&
    descriptionElement.childNodes &&
    descriptionElement.childNodes.length > 0
  ) {
    _debugLog("Description unchanged; skipping re-render (R687)");
    return;
  }

  try {

    try {
      descriptionElement.removeAttribute("data-i18n");
    } catch (_e) {

    }

    let htmlContent = prompt;

    if (typeof marked !== "undefined") {
      try {

        const mathGuard = window.protectMathDelimiters
          ? window.protectMathDelimiters(prompt)
          : { text: prompt, segments: [] };
        htmlContent = marked.parse(mathGuard.text);
        if (window.restoreMathDelimiters) {
          htmlContent = window.restoreMathDelimiters(
            htmlContent,
            mathGuard.segments,
          );
        }
      } catch (e) {
        console.warn("marked.js parse failed:", e);
      }
    }

    descriptionElement.innerHTML = htmlContent;

    if (descriptionDataset) {
      descriptionDataset.renderedPrompt = prompt;
    }

    if (typeof Prism !== "undefined") {
      Prism.highlightAllUnder(descriptionElement);
    }

    if (typeof processCodeBlocks === "function") {
      processCodeBlocks(descriptionElement);
    }

    if (typeof processStrikethrough === "function") {
      processStrikethrough(descriptionElement);
    }

    _debugLog("Synchronous Markdown render complete");

    const textContent = descriptionElement.textContent || "";
    if (window.loadMathJaxIfNeeded) {
      window.loadMathJaxIfNeeded(descriptionElement, textContent);
    } else if (window.MathJax && window.MathJax.typesetPromise) {

      window.MathJax.typesetPromise([descriptionElement]).catch((err) => {
        console.warn("MathJax render failed:", err);
      });
    }
  } catch (error) {
    console.error("Update description failed:", error);
    descriptionElement.textContent = prompt;

    if (descriptionDataset) {
      descriptionDataset.renderedPrompt = prompt;
    }
  }
}

function updateHeaderChip(label) {
  var chip = document.getElementById("task-header-chip");
  if (!chip) return;
  if (typeof label === "string" && label.trim() !== "") {
    chip.textContent = label.trim().slice(0, 16);
    chip.style.display = "";
    chip.setAttribute("aria-label", label.trim().slice(0, 16));
  } else {
    chip.textContent = "";
    chip.style.display = "none";
    chip.removeAttribute("aria-label");
  }
}

function updateLoopContext(task) {
  var container = document.getElementById("task-loop-context");
  if (!container) return;

  function _clean(value) {
    return typeof value === "string" && value.trim() !== ""
      ? value.trim()
      : null;
  }
  var loopId = _clean(task && task.loop_id);
  var loopPhase = _clean(task && task.loop_phase);
  var iterLabel = _clean(task && task.iteration_label);
  var objective = _clean(task && task.loop_objective);
  var criteria = _clean(task && task.success_criteria);

  if (
    typeof window !== "undefined" &&
    typeof updateLoopHistoryToggle === "function"
  ) {
    if (window.__aiiaCurrentLoopId !== loopId) {
      window.__aiiaCurrentLoopId = loopId;
      collapseLoopHistory();
    }
    updateLoopHistoryToggle(loopId);
  }

  if (!loopId && !loopPhase && !iterLabel && !objective && !criteria) {
    container.style.display = "none";
    return;
  }

  function _setChip(elementId, value) {
    var el = document.getElementById(elementId);
    if (!el) return;
    if (value) {
      el.textContent = value;
      el.style.display = "";
    } else {
      el.textContent = "";
      el.style.display = "none";
    }
  }
  _setChip("loop-chip-id", loopId);
  _setChip("loop-chip-phase", loopPhase);
  _setChip("loop-chip-iter", iterLabel);

  function _setLine(lineId, valueId, value) {
    var line = document.getElementById(lineId);
    var valueEl = document.getElementById(valueId);
    if (!line || !valueEl) return;
    if (value) {
      valueEl.textContent = value;
      line.style.display = "";
    } else {
      valueEl.textContent = "";
      line.style.display = "none";
    }
  }
  _setLine("loop-objective-line", "loop-objective-value", objective);
  _setLine("loop-criteria-line", "loop-criteria-value", criteria);

  container.style.display = "";
}

function updateLoopHistoryToggle(loopId) {
  var toggle = document.getElementById("loop-history-toggle");
  if (!toggle) return;
  if (loopId) {
    toggle.style.display = "";
    if (!toggle.dataset.bound) {
      toggle.dataset.bound = "1";
      toggle.addEventListener("click", toggleLoopHistory);
    }
  } else {
    toggle.style.display = "none";
  }
}

function collapseLoopHistory() {
  var toggle = document.getElementById("loop-history-toggle");
  var list = document.getElementById("loop-history-list");
  var count = document.getElementById("loop-history-count");
  if (toggle) {
    toggle.setAttribute("aria-expanded", "false");
    toggle.classList.remove("expanded");
  }
  if (list) {
    list.style.display = "none";
    list.textContent = "";
  }
  if (count) count.textContent = "";
}

async function toggleLoopHistory() {
  var toggle = document.getElementById("loop-history-toggle");
  var list = document.getElementById("loop-history-list");
  if (!toggle || !list) return;

  if (toggle.getAttribute("aria-expanded") === "true") {
    collapseLoopHistory();
    return;
  }

  var loopId = window.__aiiaCurrentLoopId;
  if (!loopId) return;

  var t =
    typeof window !== "undefined" &&
    window.AIIA_I18N &&
    typeof window.AIIA_I18N.t === "function"
      ? window.AIIA_I18N.t.bind(window.AIIA_I18N)
      : function () {
          return null;
        };

  toggle.setAttribute("aria-expanded", "true");
  toggle.classList.add("expanded");
  list.textContent = "";
  list.style.display = "";

  var loop = null;
  try {
    var resp = await fetchWithTimeout("/api/loops", { cache: "no-store" }, 8000);
    if (resp && resp.ok) {
      var data = await resp.json();
      if (data && data.success && Array.isArray(data.loops)) {
        for (var i = 0; i < data.loops.length; i++) {
          if (data.loops[i] && data.loops[i].loop_id === loopId) {
            loop = data.loops[i];
            break;
          }
        }
      }
    } else {
      renderLoopHistoryMessage(
        list,
        t("page.loopHistoryError") || "Failed to load loop history",
      );
      return;
    }
  } catch (e) {
    renderLoopHistoryMessage(
      list,
      t("page.loopHistoryError") || "Failed to load loop history",
    );
    return;
  }

  if (window.__aiiaCurrentLoopId !== loopId) return;
  if (toggle.getAttribute("aria-expanded") !== "true") return;

  var rounds = loop && Array.isArray(loop.rounds) ? loop.rounds : [];
  var countEl = document.getElementById("loop-history-count");
  if (countEl) countEl.textContent = rounds.length ? String(rounds.length) : "";

  if (!rounds.length) {
    renderLoopHistoryMessage(
      list,
      t("page.loopHistoryEmpty") || "No completed rounds yet",
    );
    return;
  }

  for (var r = rounds.length - 1; r >= 0; r--) {
    var round = rounds[r];
    if (!round || typeof round !== "object") continue;
    list.appendChild(buildLoopHistoryRow(round));
  }
}

function renderLoopHistoryMessage(list, message) {
  var row = document.createElement("div");
  row.className = "loop-history-empty";
  row.textContent = message;
  list.appendChild(row);
}

function buildLoopHistoryRow(round) {
  var row = document.createElement("div");
  row.className = "loop-history-row";
  row.setAttribute("role", "listitem");

  var head = document.createElement("div");
  head.className = "loop-history-row-head";

  var iter = document.createElement("span");
  iter.className = "loop-history-iter";
  iter.textContent =
    (typeof round.iteration_label === "string" && round.iteration_label) ||
    (typeof round.task_id === "string" ? round.task_id.slice(0, 12) : "—");
  head.appendChild(iter);

  if (typeof round.loop_phase === "string" && round.loop_phase) {
    var phase = document.createElement("span");
    phase.className = "loop-history-phase";
    phase.textContent = round.loop_phase;
    head.appendChild(phase);
  }

  if (typeof round.completed_at === "string" && round.completed_at) {
    var time = document.createElement("span");
    time.className = "loop-history-time";
    var parsed = new Date(round.completed_at);
    time.textContent = isNaN(parsed.getTime())
      ? round.completed_at
      : parsed.toLocaleString();
    head.appendChild(time);
  }
  row.appendChild(head);

  var verdict = round.verdict && typeof round.verdict === "object"
    ? round.verdict
    : {};
  var parts = [];
  if (typeof verdict.user_input === "string" && verdict.user_input.trim()) {
    parts.push(verdict.user_input.trim());
  }
  if (Array.isArray(verdict.selected_options) && verdict.selected_options.length) {
    parts.push("[" + verdict.selected_options.join(", ") + "]");
  }
  if (typeof verdict.image_count === "number" && verdict.image_count > 0) {
    parts.push("(+" + verdict.image_count + " img)");
  }
  if (parts.length) {
    var body = document.createElement("div");
    body.className = "loop-history-verdict";
    body.textContent = parts.join(" ");
    row.appendChild(body);
  }
  return row;
}

function updateFeedbackPlaceholder(placeholder) {
  var textarea = document.getElementById("feedback-text");
  if (!textarea) return;
  if (typeof placeholder === "string" && placeholder.trim() !== "") {

    try {
      textarea.removeAttribute("data-i18n-placeholder");
    } catch (_e) {

    }
    textarea.setAttribute("placeholder", placeholder);
  } else if (typeof window !== "undefined" && window.AIIA_I18N && typeof window.AIIA_I18N.t === "function") {
    var defaultText = window.AIIA_I18N.t("page.feedbackPlaceholder");
    if (typeof defaultText === "string" && defaultText) {

      try {
        textarea.setAttribute(
          "data-i18n-placeholder",
          "page.feedbackPlaceholder",
        );
      } catch (_e) {

      }
      textarea.setAttribute("placeholder", defaultText);
    }
  }
}

function updateOptionsDisplay(options, optionDefaults) {
  const optionsContainer = document.getElementById("options-container");
  if (!optionsContainer) return;

  const optionsDataset = optionsContainer.dataset || null;
  const renderSignature =
    String(activeTaskId) +
    "\u0000" +
    JSON.stringify(options || []) +
    "\u0000" +
    JSON.stringify(optionDefaults || []);
  if (
    optionsDataset &&
    optionsDataset.renderedSignature === renderSignature &&
    ((optionsContainer.childNodes && optionsContainer.childNodes.length > 0) ||
      !(options && options.length > 0))
  ) {
    _debugLog("Options unchanged; skipping re-render (R687)");
    return;
  }
  if (optionsDataset) {
    optionsDataset.renderedSignature = renderSignature;
  }

  let selectedStates = {};
  let hasUserInteraction = false;
  if (activeTaskId && taskOptionsStates[activeTaskId]) {
    selectedStates = taskOptionsStates[activeTaskId];
    hasUserInteraction = true;
    _debugLog(`Restored option selection state for task ${activeTaskId}`);
  } else {

    const existingCheckboxes = optionsContainer.querySelectorAll(
      'input[type="checkbox"]',
    );
    const existingCheckboxCount = existingCheckboxes.length;
    for (let index = 0; index < existingCheckboxCount; index += 1) {
      if (!(index in existingCheckboxes)) continue;
      const checkbox = existingCheckboxes[index];
      selectedStates[checkbox.id] = checkbox.checked;
    }

    if (existingCheckboxes.length > 0) {
      hasUserInteraction = true;
    }
  }

  optionsContainer.innerHTML = "";

  if (options && options.length > 0) {
    const defaults = Array.isArray(optionDefaults) ? optionDefaults : [];
    const optionCount = options.length;
    for (let index = 0; index < optionCount; index += 1) {
      if (!(index in options)) continue;
      const option = options[index];
      const optionDiv = document.createElement("div");
      optionDiv.className = "option-item";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.id = `option-${index}`;
      checkbox.value = option;

      const checkboxId = `option-${index}`;
      if (hasUserInteraction) {
        if (selectedStates[checkboxId] || selectedStates[index]) {
          checkbox.checked = true;
        }
      } else if (defaults[index] === true) {
        checkbox.checked = true;
      }

      const label = document.createElement("label");
      label.htmlFor = `option-${index}`;
      label.textContent = option;

      optionDiv.appendChild(checkbox);
      optionDiv.appendChild(label);
      optionsContainer.appendChild(optionDiv);
    }

    optionsContainer.classList.remove("hidden");
    optionsContainer.classList.add("visible");

    const separator = document.getElementById("separator");
    if (separator) {
      separator.classList.remove("hidden");
      separator.classList.add("visible");
    }
  } else {
    optionsContainer.classList.add("hidden");
    optionsContainer.classList.remove("visible");
  }
}

function removeTaskFromCurrentTasks(tasks, taskId) {
  const taskCount = tasks && Number.isFinite(tasks.length) ? tasks.length : 0;
  let keptTasks = null;

  for (let taskIndex = 0; taskIndex < taskCount; taskIndex += 1) {
    if (!(taskIndex in tasks)) {
      continue;
    }
    const task = tasks[taskIndex];
    if (task.task_id === taskId) {
      if (keptTasks === null) {
        keptTasks = [];
        for (let copyIndex = 0; copyIndex < taskIndex; copyIndex += 1) {
          if (copyIndex in tasks) {
            keptTasks.push(tasks[copyIndex]);
          }
        }
      }
      continue;
    }
    if (keptTasks !== null) {
      keptTasks.push(task);
    }
  }

  return keptTasks === null ? tasks : keptTasks;
}

async function closeTask(taskId) {
  if (!confirm(_t("status.confirmCloseTask", { taskId }))) {
    return;
  }

  try {
    const response = await fetchWithTimeout(
      `/api/tasks/${taskId}/close`,
      { method: "POST" },
      10000,
    );
    const data = await response.json();

    if (!response.ok || !data.success) {
      console.error("Server-side close task failed:", data.error);
      if (typeof showStatus === "function") {

        const classifyHttp =
          typeof window._classifyHttpResponse === "function"
            ? window._classifyHttpResponse
            : null;
        const httpKey = classifyHttp ? classifyHttp(response) : null;
        if (httpKey) {
          showStatus(_t(httpKey), "error");
        } else {
          showStatus(data.error || _t("status.closeFailed"), "error");
        }
      }
      return;
    }

    if (taskCountdowns[taskId]) {
      _clearTaskCountdown(taskId);
    }
    if (window.taskDeadlines[taskId] !== undefined) {
      delete window.taskDeadlines[taskId];
    }
    delete taskTextareaContents[taskId];
    delete taskOptionsStates[taskId];
    delete taskImages[taskId];
    if (autoSubmitAttempted) {
      delete autoSubmitAttempted[taskId];
    }

    currentTasks = removeTaskFromCurrentTasks(currentTasks, taskId);
    window.currentTasks = currentTasks;
    renderTaskTabs();

    if (activeTaskId === taskId) {
      const nextTask = findFirstOpenTask(currentTasks);
      if (nextTask) {

        requestFeedbackInputFocus();
        switchTask(nextTask.task_id);
      } else {
        setActiveTaskId(null);
        if (typeof showNoContentPage === "function") {
          showNoContentPage();
        }
      }
    }

    _debugLog(`Closed task: ${taskId}`);
  } catch (error) {
    console.error("Close task failed:", error);
    if (typeof showStatus === "function") {

      const classify =
        typeof window._classifyFetchError === "function"
          ? window._classifyFetchError
          : null;
      const key = classify ? classify(error) : "status.networkError";
      showStatus(_t(key), "error");
    }
  }
}

function _getOrCacheCountdownDom(tid, entry) {
  if (!entry) return null;
  let cache = entry._domCache;
  if (cache && cache.ring && document.contains(cache.ring)) {
    return cache;
  }
  const ring = document.getElementById(`countdown-${tid}`);
  if (!ring) {
    if (cache) {
      entry._domCache = null;
    }
    return null;
  }
  cache = {
    ring: ring,
    circle: ring.querySelector("circle"),
    numberSpan: ring.querySelector(".countdown-number"),
  };
  entry._domCache = cache;
  return cache;
}

function forceUpdateAllTaskCountdowns() {
  if (typeof document === "undefined" || document.hidden) return;
  if (!taskCountdowns || typeof taskCountdowns !== "object") return;

  for (const tid in taskCountdowns) {
    if (!Object.prototype.hasOwnProperty.call(taskCountdowns, tid)) continue;
    const entry = taskCountdowns[tid];
    if (!entry || !entry.timer) continue;

    const remaining = Math.max(0, Math.floor(entry.remaining || 0));
    const total = entry.timeout || 240;
    const progress = total > 0 ? remaining / total : 0;
    const radius = 9;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference * (1 - progress);

    const cache = _getOrCacheCountdownDom(tid, entry);
    if (cache) {
      if (cache.circle) cache.circle.setAttribute("stroke-dashoffset", offset);
      if (cache.numberSpan) cache.numberSpan.textContent = remaining;
      cache.ring.title = _t("page.countdown", { seconds: remaining });
    }

    if (tid === activeTaskId) {
      try {
        updateCountdownDisplay(remaining);
      } catch (err) {

        console.debug("forceUpdateAllTaskCountdowns: skip main display", err);
      }
    }
  }
}

if (typeof window.tasksCountdownVisibilityHandlerInstalled === "undefined") {

  window.tasksCountdownVisibilityHandlerInstalled = false;
}

function installCountdownVisibilitySyncHandlerOnce() {
  if (typeof document === "undefined") return;
  if (window.tasksCountdownVisibilityHandlerInstalled) return;
  window.tasksCountdownVisibilityHandlerInstalled = true;
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) {
      forceUpdateAllTaskCountdowns();
    }
  });
}

const TASK_COUNTDOWN_SHARED_TIMER_SENTINEL = "shared-countdown-ticker";

function calculateTaskCountdownRemaining(taskId, entry) {
  const deadline = window.taskDeadlines[taskId];
  if (deadline) {

    const adjustedNow = Date.now() / 1000 + (window.serverTimeOffset || 0);
    return Math.max(0, Math.floor(deadline - adjustedNow));
  }

  return entry.remaining - 1;
}

function hasRunningTaskCountdowns() {
  for (const tid in taskCountdowns) {
    if (!Object.prototype.hasOwnProperty.call(taskCountdowns, tid)) continue;
    const entry = taskCountdowns[tid];
    if (entry && entry.timer === TASK_COUNTDOWN_SHARED_TIMER_SENTINEL) return true;
  }
  return false;
}

function stopSharedTaskCountdownTickerIfIdle() {
  if (hasRunningTaskCountdowns()) return;
  if (tasksCountdownTickerTimer) {
    clearInterval(tasksCountdownTickerTimer);
    tasksCountdownTickerTimer = null;
    window.tasksCountdownTickerTimer = null;
  }
}

function ensureSharedTaskCountdownTicker() {
  if (tasksCountdownTickerTimer) return;
  tasksCountdownTickerTimer = setInterval(tickAllTaskCountdowns, 1000);
  window.tasksCountdownTickerTimer = tasksCountdownTickerTimer;
}

function _clearTaskCountdown(taskId) {
  const normalizedTaskId = normalizeTaskIdValue(taskId);
  if (!normalizedTaskId || !taskCountdowns[normalizedTaskId]) return;
  const timer = taskCountdowns[normalizedTaskId].timer;
  if (timer && timer !== TASK_COUNTDOWN_SHARED_TIMER_SENTINEL) {
    clearInterval(timer);
  }
  taskCountdowns[normalizedTaskId].timer = null;
  delete taskCountdowns[normalizedTaskId];
  stopSharedTaskCountdownTickerIfIdle();
}

function isUserActivelyTyping() {
  return (
    typeof window.lastFeedbackTypingAtMs === "number" &&
    window.lastFeedbackTypingAtMs > 0 &&
    Date.now() - window.lastFeedbackTypingAtMs < TYPING_HOLD_IDLE_MS
  );
}

function maybeAutoExtendCountdownForTyping(taskId, remaining) {
  if (typeof fetch === "undefined") return;
  if (taskId !== activeTaskId) return;
  if (remaining <= 0 || remaining > TYPING_HOLD_TRIGGER_S) return;
  if (!isUserActivelyTyping()) return;
  if (window.__aiiaTypingAutoExtendInFlight) return;

  var task = findTaskById(window.currentTasks || [], taskId);
  if (!task) return;
  if ((task.auto_resubmit_timeout || 0) <= 0) return;
  if (
    typeof task.extends_used === "number" &&
    typeof task.extends_max === "number" &&
    task.extends_used >= task.extends_max
  ) {
    return;
  }

  window.__aiiaTypingAutoExtendInFlight = true;
  fetch("/api/tasks/" + encodeURIComponent(taskId) + "/extend", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ seconds: 60 }),
  })
    .then(function (resp) {
      return resp.json().then(function (data) {
        return { ok: resp.ok, data: data };
      });
    })
    .then(function (res) {
      if (!res.ok || !res.data || !res.data.success) {

        if (res.data && typeof res.data.extends_used === "number") {
          var failedTask = findTaskById(window.currentTasks || [], taskId);
          if (failedTask) {
            failedTask.extends_used = res.data.extends_used;
            failedTask.extends_max =
              res.data.extends_max || failedTask.extends_max;
            if (typeof updateCountdownExtendButton === "function") {
              updateCountdownExtendButton(failedTask);
            }
          }
        }
        _debugLog(
          "Typing auto-extend rejected for " +
            taskId +
            ": " +
            ((res.data && res.data.code) || "unknown"),
        );
        return;
      }
      var data = res.data;
      var newRemaining = data.new_remaining_time;
      var newTimeout = data.new_auto_resubmit_timeout;
      var adjustedNow = Date.now() / 1000 + (window.serverTimeOffset || 0);
      if (typeof window.taskDeadlines === "object" && window.taskDeadlines) {
        window.taskDeadlines[taskId] = adjustedNow + newRemaining;
      }
      var cd = taskCountdowns[taskId];
      if (cd) {
        cd.remaining = newRemaining;
        cd.timeout = newTimeout;
      }
      var okTask = findTaskById(window.currentTasks || [], taskId);
      if (okTask) {
        okTask.extends_used = data.extends_used;
        okTask.extends_max = data.extends_max;
        okTask.auto_resubmit_timeout = newTimeout;
        okTask.remaining_time = newRemaining;
        if (typeof updateCountdownExtendButton === "function") {
          updateCountdownExtendButton(okTask);
        }
      }
      _debugLog(
        "Typing auto-extend applied for " +
          taskId +
          ": +60s (remaining " +
          newRemaining +
          "s)",
      );
    })
    .catch(function (e) {
      console.warn("Typing auto-extend network error:", e);
    })
    .finally(function () {
      window.__aiiaTypingAutoExtendInFlight = false;
    });
}

function tickTaskCountdown(taskId) {
  const entry = taskCountdowns[taskId];
  if (!entry || entry.timer !== TASK_COUNTDOWN_SHARED_TIMER_SENTINEL) return;

  const newRemaining = calculateTaskCountdownRemaining(taskId, entry);
  entry.remaining = newRemaining;

  const documentHidden = typeof document !== "undefined" && document.hidden;

  if (!documentHidden) {
    const cache = _getOrCacheCountdownDom(taskId, entry);
    if (cache) {
      const remaining = entry.remaining;

      const total = entry.timeout || 240;
      const progress = remaining / total;

      const radius = 9;
      const circumference = 2 * Math.PI * radius;
      const offset = circumference * (1 - progress);

      if (cache.circle) {
        cache.circle.setAttribute("stroke-dashoffset", offset);
      }
      if (cache.numberSpan) {
        cache.numberSpan.textContent = remaining;
      }

      cache.ring.title = _t("page.countdown", { seconds: remaining });
    }

    if (taskId === activeTaskId) {
      updateCountdownDisplay(entry.remaining);
    }
  }

  maybeAutoExtendCountdownForTyping(taskId, entry.remaining);

  if (entry.remaining <= 0) {

    if (taskId === activeTaskId && isUserActivelyTyping()) {
      return;
    }

    entry.timer = null;
    stopSharedTaskCountdownTickerIfIdle();

    if (taskId === activeTaskId) {

      autoSubmitTask(taskId);
    } else {

      if (!activeTaskId) {
        _debugLog(
          `Non-active task ${taskId} timed out with no active task; auto-submitting`,
        );
        autoSubmitTask(taskId);
      } else {
        _debugLog(
          `Task ${taskId} timed out but user is working on ${activeTaskId}; deferring auto-submit`,
        );
      }
    }
  }
}

function tickAllTaskCountdowns() {
  for (const taskId in taskCountdowns) {
    if (!Object.prototype.hasOwnProperty.call(taskCountdowns, taskId)) continue;
    tickTaskCountdown(taskId);
  }
  stopSharedTaskCountdownTickerIfIdle();
}

function startTaskCountdown(taskId, remaining, total = null) {

  const timeout = total || remaining;

  _clearTaskCountdown(taskId);

  installCountdownVisibilitySyncHandlerOnce();

  taskCountdowns[taskId] = {
    remaining: remaining,
    timeout: timeout,
    timer: TASK_COUNTDOWN_SHARED_TIMER_SENTINEL,
  };

  if (taskId === activeTaskId) {
    updateCountdownDisplay(remaining);
  }

  ensureSharedTaskCountdownTicker();

  _debugLog(
    `Started task countdown: ${taskId}, remaining ${remaining}s / total ${timeout}s`,
  );
}

function formatCountdown(seconds) {
  if (seconds > 60) {
    return `${Math.floor(seconds / 60)}m`;
  }
  return `${seconds}s`;
}

async function autoSubmitTask(taskId) {

  try {
    const now = Date.now();
    const last = autoSubmitAttempted && autoSubmitAttempted[taskId];
    const RETRY_INTERVAL_MS = 30 * 1000;
    if (
      typeof last === "number" &&
      last > 0 &&
      now - last < RETRY_INTERVAL_MS
    ) {
      return;
    }
    if (autoSubmitAttempted) {
      autoSubmitAttempted[taskId] = now;
    }
  } catch (e) {

  }
  _debugLog(`Task ${taskId} countdown ended; auto-submitting`);

  const typedText = collectTypedFeedbackForTask(taskId);
  let combinedText = typedText || "";

  const userDidInteractOptions =
    taskUserOptionInteracted[taskId] === true;
  const selectedOpts = userDidInteractOptions
    ? collectSelectedOptionsForTask(taskId)
    : [];

  if ((combinedText && combinedText.trim()) || selectedOpts.length > 0) {
    _debugLog(
      `Auto-submitting user-typed content for ${taskId} ` +
        `(${(combinedText || "").length} chars, ${selectedOpts.length} options, interacted=${userDidInteractOptions})`,
    );
    await submitTaskFeedback(taskId, combinedText || "", selectedOpts);
    return;
  }

  const prompts = await fetchFeedbackPromptsFresh();
  const defaultMessage =
    prompts && prompts.resubmit_prompt ? String(prompts.resubmit_prompt) : "";
  if (!defaultMessage) {
    console.warn(
      `Skip auto-submit for ${taskId}: resubmit_prompt not configured or unavailable`,
    );
    return;
  }
  await submitTaskFeedback(taskId, defaultMessage, []);
}

function collectTypedFeedbackForTask(taskId) {
  try {
    if (taskId === activeTaskId && typeof document !== "undefined") {
      const liveTextarea = document.getElementById("feedback-text");
      if (
        liveTextarea &&
        typeof liveTextarea.value === "string" &&
        liveTextarea.value.trim()
      ) {
        return liveTextarea.value;
      }
    }
    const saved = taskTextareaContents && taskTextareaContents[taskId];
    if (typeof saved === "string") {
      return saved;
    }
  } catch (e) {
    _debugLog(`collectTypedFeedbackForTask failed for ${taskId}: ${e}`);
  }
  return "";
}

function collectSelectedOptionsForTask(taskId) {
  const labels = [];
  try {
    if (taskId === activeTaskId && typeof document !== "undefined") {
      const container = document.getElementById("options-container");
      if (container && typeof container.querySelectorAll === "function") {
        const boxes = container.querySelectorAll('input[type="checkbox"]');
        const boxCount = boxes.length;
        for (let index = 0; index < boxCount; index += 1) {
          if (!(index in boxes)) continue;
          const box = boxes[index];
          if (box.checked) labels.push(box.value);
        }
        if (labels.length > 0) return labels;
      }
    }
    const states = taskOptionsStates && taskOptionsStates[taskId];
    const task = findTaskById(window.currentTasks || [], taskId);
    const options = task && task.predefined_options;
    if (states && options && options.length) {
      const optionCount = options.length;
      for (let index = 0; index < optionCount; index += 1) {
        if (!(index in options)) continue;
        if (states["option-" + index] || states[index]) {
          labels.push(options[index]);
        }
      }
    }
  } catch (e) {
    _debugLog(`collectSelectedOptionsForTask failed for ${taskId}: ${e}`);
  }
  return labels;
}

async function submitTaskFeedback(taskId, feedbackText, selectedOptions) {
  try {
    const formData = new FormData();
    formData.append("feedback_text", feedbackText);
    formData.append("selected_options", JSON.stringify(selectedOptions));

    const selectedImageCount =
      selectedImages && Number.isFinite(selectedImages.length)
        ? selectedImages.length
        : 0;
    for (let imageIndex = 0; imageIndex < selectedImageCount; imageIndex += 1) {
      if (!(imageIndex in selectedImages)) continue;
      const img = selectedImages[imageIndex];
      if (img.file) {
        formData.append(`image_${imageIndex}`, img.file);
      }
    }

    const response = await fetchWithTimeout(
      `/api/tasks/${taskId}/submit`,
      {
        method: "POST",
        body: formData,
      },
      30000,
    );

    const data = await response.json();

    if (data.success) {
      _debugLog(`Task ${taskId} submitted successfully`);

      requestFeedbackInputFocus();

      if (taskCountdowns[taskId]) {
        _clearTaskCountdown(taskId);
      }

      if (taskTextareaContents[taskId] !== undefined) {
        delete taskTextareaContents[taskId];
        _debugLog(`Cleared saved textarea content for task ${taskId}`);
      }
      if (taskOptionsStates[taskId] !== undefined) {
        delete taskOptionsStates[taskId];
        _debugLog(`Cleared saved option selection state for task ${taskId}`);
      }
      if (taskUserOptionInteracted[taskId] !== undefined) {
        delete taskUserOptionInteracted[taskId];
      }
      if (taskImages[taskId] !== undefined) {
        delete taskImages[taskId];
        _debugLog(`Cleared saved image list for task ${taskId}`);
      }

      if (!_sseConnected) {
        setTimeout(async () => {
          await refreshTasksList();
          const nextTask = findFirstOpenTask(currentTasks, taskId);
          if (nextTask) {
            _debugLog(`Auto-switching to next task: ${nextTask.task_id}`);
            switchTask(nextTask.task_id);
          } else {
            _debugLog("All tasks completed");
          }
        }, 200);
      }
    } else {
      console.error("Submit task failed:", data.error);
    }
  } catch (error) {
    console.error("Submit task feedback failed:", error);
  }
}

function showNewTaskVisualHint(count) {
  const container = document.getElementById("task-tabs-container");
  if (!container) return;

  const html = document.documentElement;
  const currentTheme = html.getAttribute("data-theme");
  const isLightTheme = currentTheme === "light";

  const createSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 20 20" fill="none" style="flex-shrink: 0; margin-right: 10px;"><path d="M15.5117 1.99707C15.9213 2.0091 16.3438 2.13396 16.6768 2.46679C17.0278 2.81814 17.1209 3.26428 17.0801 3.68261C17.0404 4.08745 16.8765 4.49344 16.6787 4.85058C16.3934 5.36546 15.9941 5.85569 15.6348 6.20898C15.7682 6.41421 15.8912 6.66414 15.9551 6.9453C16.0804 7.4977 15.9714 8.13389 15.4043 8.70116C14.8566 9.24884 13.974 9.54823 13.1943 9.71679C12.7628 9.81003 12.3303 9.86698 11.9473 9.90233C12.0596 10.2558 12.0902 10.7051 11.8779 11.2012L11.8223 11.3203C11.5396 11.8854 11.0275 12.2035 10.4785 12.3965C9.93492 12.5875 9.29028 12.6792 8.65332 12.75C7.99579 12.8231 7.34376 12.8744 6.70117 12.9775C6.14371 13.067 5.63021 13.1903 5.18652 13.3818L5.00585 13.4658C4.53515 14.2245 4.13745 14.9658 3.80957 15.6465C4.43885 15.2764 5.1935 15 5.99999 15C6.27614 15 6.49999 15.2238 6.49999 15.5C6.49999 15.7761 6.27613 16 5.99999 16C5.35538 16 4.71132 16.2477 4.15039 16.6103C3.58861 16.9736 3.14957 17.427 2.91601 17.7773C2.91191 17.7835 2.90568 17.788 2.90136 17.7939C2.88821 17.8119 2.8746 17.8289 2.85937 17.8447C2.85117 17.8533 2.84268 17.8612 2.83398 17.8691C2.81803 17.8835 2.80174 17.897 2.78417 17.9092C2.774 17.9162 2.76353 17.9225 2.75292 17.9287C2.73854 17.9372 2.72412 17.9451 2.70898 17.9521C2.69079 17.9605 2.6723 17.9675 2.65332 17.9736C2.6417 17.9774 2.63005 17.9805 2.61816 17.9834C2.60263 17.9872 2.5871 17.9899 2.57128 17.9922C2.55312 17.9948 2.53511 17.9974 2.5166 17.998C2.50387 17.9985 2.49127 17.9976 2.47851 17.9971C2.45899 17.9962 2.43952 17.9954 2.41992 17.9922C2.40511 17.9898 2.39062 17.9862 2.37597 17.9824C2.36477 17.9795 2.35294 17.9783 2.34179 17.9746C2.33697 17.973 2.33286 17.9695 2.32812 17.9678C2.31042 17.9612 2.29351 17.953 2.27636 17.9443C2.26332 17.9378 2.25053 17.9314 2.23828 17.9238C2.23339 17.9208 2.22747 17.9192 2.22265 17.916C2.21414 17.9103 2.20726 17.9026 2.19921 17.8965C2.18396 17.8849 2.16896 17.8735 2.15527 17.8603C2.14518 17.8507 2.13609 17.8404 2.12695 17.8301C2.11463 17.8161 2.10244 17.8023 2.09179 17.7871C2.08368 17.7756 2.07736 17.7631 2.07031 17.751C2.06168 17.7362 2.05297 17.7216 2.04589 17.706C2.03868 17.6901 2.03283 17.6738 2.02734 17.6572C2.0228 17.6436 2.01801 17.6302 2.01464 17.6162C2.01117 17.6017 2.009 17.587 2.00683 17.5722C2.00411 17.5538 2.00161 17.5354 2.00097 17.5166C2.00054 17.5039 2.00141 17.4912 2.00195 17.4785C2.00279 17.459 2.00364 17.4395 2.00683 17.4199C2.00902 17.4064 2.01327 17.3933 2.0166 17.3799C2.01973 17.3673 2.02123 17.3543 2.02539 17.3418C2.41772 16.1648 3.18163 14.466 4.30468 12.7012C4.31908 12.5557 4.34007 12.3582 4.36914 12.1201C4.43379 11.5907 4.53836 10.8564 4.69921 10.0381C5.0174 8.41955 5.56814 6.39783 6.50585 4.9912L6.73242 4.66894C7.27701 3.93277 7.93079 3.30953 8.61035 2.85156C9.3797 2.33311 10.2221 2 11.001 2C11.7951 2.00025 12.3531 2.35795 12.7012 2.70605C12.7723 2.77723 12.8348 2.84998 12.8896 2.91796C13.2829 2.66884 13.7917 2.39502 14.3174 2.21191C14.6946 2.08056 15.1094 1.98537 15.5117 1.99707ZM17.04 15.5537C17.1486 15.3 17.4425 15.1818 17.6963 15.29C17.95 15.3986 18.0683 15.6925 17.96 15.9463C17.4827 17.0612 16.692 18 15.5 18C14.6309 17.9999 13.9764 17.5003 13.5 16.7978C13.0236 17.5003 12.3691 18 11.5 18C10.6309 17.9999 9.97639 17.5003 9.49999 16.7978C9.02359 17.5003 8.36911 18 7.49999 18C7.22391 17.9999 7 17.7761 6.99999 17.5C6.99999 17.2239 7.22391 17 7.49999 17C8.07039 17 8.6095 16.5593 9.04003 15.5537L9.07421 15.4873C9.16428 15.3412 9.32494 15.25 9.49999 15.25C9.70008 15.25 9.88121 15.3698 9.95996 15.5537L10.042 15.7353C10.4581 16.6125 10.9652 16.9999 11.5 17C12.0704 17 12.6095 16.5593 13.04 15.5537L13.0742 15.4873C13.1643 15.3412 13.3249 15.25 13.5 15.25C13.7001 15.25 13.8812 15.3698 13.96 15.5537L14.042 15.7353C14.4581 16.6125 14.9652 16.9999 15.5 17C16.0704 17 16.6095 16.5593 17.04 15.5537ZM15.4824 2.99707C15.247 2.99022 14.9608 3.04682 14.6465 3.15624C14.0173 3.37541 13.389 3.76516 13.0498 4.01953C12.9277 4.11112 12.7697 4.14131 12.6221 4.10253C12.4745 4.06357 12.3522 3.9591 12.291 3.81933V3.81835C12.2892 3.81468 12.2861 3.80833 12.2822 3.80078C12.272 3.78092 12.2541 3.7485 12.2295 3.70898C12.1794 3.62874 12.1011 3.52019 11.9941 3.41308C11.7831 3.2021 11.4662 3.00024 11.001 2.99999C10.4904 2.99999 9.84173 3.22729 9.16894 3.68066C8.58685 4.07297 8.01568 4.61599 7.5371 5.26269L7.33789 5.54589C6.51634 6.77827 5.99475 8.63369 5.68066 10.2314C5.63363 10.4707 5.5913 10.7025 5.55371 10.9238C7.03031 9.01824 8.94157 7.19047 11.2812 6.05077C11.5295 5.92989 11.8283 6.03301 11.9492 6.28124C12.0701 6.52949 11.967 6.82829 11.7187 6.94921C9.33153 8.11208 7.38648 10.0746 5.91406 12.1103C6.12313 12.0632 6.33385 12.0238 6.54296 11.9902C7.21709 11.8821 7.92723 11.8243 8.54296 11.7558C9.17886 11.6852 9.72123 11.6025 10.1465 11.4531C10.5662 11.3056 10.8063 11.1158 10.9277 10.873L10.9795 10.7549C11.0776 10.487 11.0316 10.2723 10.9609 10.1123C10.918 10.0155 10.8636 9.93595 10.8203 9.88183C10.7996 9.85598 10.7822 9.83638 10.7715 9.82518L10.7607 9.81542L10.7627 9.8164L10.7646 9.81835C10.6114 9.67972 10.5597 9.46044 10.6338 9.26757C10.7082 9.07475 10.8939 8.94726 11.1006 8.94726C11.5282 8.94719 12.26 8.8956 12.9834 8.73925C13.7297 8.5779 14.3654 8.32602 14.6973 7.99413C15.0087 7.68254 15.0327 7.40213 14.9795 7.16698C14.9332 6.96327 14.8204 6.77099 14.707 6.62792L14.5957 6.50195C14.4933 6.39957 14.4401 6.25769 14.4502 6.11327C14.4605 5.96888 14.5327 5.83599 14.6484 5.74902C14.9558 5.51849 15.4742 4.96086 15.8037 4.3662C15.9675 4.07048 16.0637 3.80137 16.085 3.58593C16.1047 3.38427 16.0578 3.26213 15.9697 3.17382C15.8631 3.06726 15.7102 3.00377 15.4824 2.99707Z" fill="#d97757"/></svg>`;

  const themeStyles = isLightTheme
    ? {

        background: "linear-gradient(135deg, #faf9f5 0%, #f2f1ec 100%)",
        color: "#131314",
        border: "1px solid rgba(217, 119, 87, 0.4)",
        boxShadow:
          "0 8px 24px rgba(0, 0, 0, 0.12), 0 0 0 1px rgba(217, 119, 87, 0.15)",
      }
    : {

        background: "rgba(45, 45, 60, 0.95)",
        color: "rgba(245, 245, 247, 0.95)",
        border: "1px solid rgba(255, 255, 255, 0.08)",
        boxShadow: "0 8px 24px rgba(0, 0, 0, 0.35)",
      };

  const existingHint = document.getElementById("new-task-hint");
  if (existingHint && existingHint.parentNode) {
    if (existingHint.__aiiaRemoveTimer) {
      clearTimeout(existingHint.__aiiaRemoveTimer);
    }
    existingHint.parentNode.removeChild(existingHint);
  }

  const hint = document.createElement("div");
  hint.id = "new-task-hint";
  hint.setAttribute("role", "status");
  hint.setAttribute("aria-atomic", "true");
  hint.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    display: flex;
    align-items: center;
    background: ${themeStyles.background};
    color: ${themeStyles.color};
    padding: 14px 20px;
    border-radius: 12px;
    border: ${themeStyles.border};
    box-shadow: ${themeStyles.boxShadow};
    font-size: 14px;
    font-weight: 500;
    letter-spacing: 0.02em;
    z-index: 10000;
    animation: slideInRight 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), fadeOutUp 0.3s ease-in 2.7s forwards;
    pointer-events: none;
  `;
  // AIIA-XSS-SAFE: createSvg 是开发者手写 SVG 字面量，不包含运行时数据。
  const iconWrapper = document.createElement("span");
  iconWrapper.setAttribute("aria-hidden", "true");
  iconWrapper.innerHTML = createSvg;
  hint.appendChild(iconWrapper);

  const label = document.createElement("span");
  label.textContent =
    _t("page.noContent.newTasks", { count: count }) ||
    "Received " + count + " new feedback requests";
  hint.appendChild(label);

  document.body.appendChild(hint);

  hint.__aiiaRemoveTimer = setTimeout(() => {
    hint.__aiiaRemoveTimer = null;
    if (hint.parentNode) {
      hint.parentNode.removeChild(hint);
    }
  }, 3000);

  _debugLog(`显示新任务视觉提示: ${count} 个新任务`);
}

function showNewTaskNotification(count, taskIds) {
  try {
    if (
      typeof notificationManager !== "undefined" &&
      notificationManager &&
      typeof notificationManager.dispatchEvent === "function"
    ) {
      notificationManager.dispatchEvent({
        type: "new_tasks",
        count: typeof count === "number" ? count : Number(count),
        taskIds: Array.isArray(taskIds) ? taskIds : [],
      });
      return;
    }
  } catch (e) {

  }

  try {
    showNewTaskVisualHint(count);
  } catch (e) {

  }
}

async function initMultiTaskSupport() {
  _debugLog("Initializing multi-task support…");

  try {
    await Promise.allSettled([fetchFeedbackPromptsFresh(), refreshTasksList()]);
  } catch (e) {
    console.warn(
      "Initial parallel fetch failed (will still start polling + health check):",
      e,
    );
  }

  startTasksPolling();

  startTasksHealthCheck();

  const autosaveBindings = setupRealtimeAutosaveListeners();
  if (autosaveBindings.textarea) {
    _debugLog("Enabled real-time textarea autosave");
  }
  if (autosaveBindings.optionsContainer) {
    _debugLog("Enabled real-time option-state autosave");
  }

  _debugLog(
    "Multi-task support initialized (with polling health-check and real-time autosave)",
  );
}

async function refreshTasksList() {
  const ok = await fetchAndApplyTasks("manual");
  if (ok) {
    tasksPollBackoffMs = TASKS_POLL_BASE_MS;
    _debugLog("Task list refreshed manually");
  }

  if (
    !tasksPollingTimer &&
    !(typeof document !== "undefined" && document.hidden)
  ) {
    startTasksPolling();
  }
}

if (typeof window.__aiiaFocusInputRequestAtMs === "undefined") {
  window.__aiiaFocusInputRequestAtMs = 0;
}
var FOCUS_REQUEST_FRESH_MS = 8 * 1000;

function requestFeedbackInputFocus() {
  window.__aiiaFocusInputRequestAtMs = Date.now();
}

function maybeApplyPendingInputFocus() {
  const requestedAt = window.__aiiaFocusInputRequestAtMs;
  if (!requestedAt || Date.now() - requestedAt > FOCUS_REQUEST_FRESH_MS) {
    return;
  }
  if (typeof document === "undefined" || document.hidden) return;
  const textarea = document.getElementById("feedback-text");
  if (!textarea || typeof textarea.focus !== "function") return;

  if (textarea.style && textarea.style.display === "none") {
    window.__aiiaFocusInputRequestAtMs = 0;
    return;
  }
  window.__aiiaFocusInputRequestAtMs = 0;
  try {
    textarea.focus();
    _debugLog("Focused feedback textarea for next task (R692)");
  } catch (e) {

  }
}

function handleRealtimeTextareaAutosave(event) {

  window.lastFeedbackTypingAtMs = Date.now();
  if (!activeTaskId) return;
  const textarea =
    event && event.currentTarget
      ? event.currentTarget
      : document.getElementById("feedback-text");
  if (!textarea) return;
  taskTextareaContents[activeTaskId] = textarea.value;
}

function handleRealtimeOptionsAutosave(event) {
  if (!activeTaskId) return;
  if (!event || !event.target || event.target.type !== "checkbox") return;
  taskUserOptionInteracted[activeTaskId] = true;
  const optionsContainer =
    event && event.currentTarget
      ? event.currentTarget
      : document.getElementById("options-container");
  if (
    !optionsContainer ||
    typeof optionsContainer.querySelectorAll !== "function"
  ) {
    return;
  }
  const checkboxes = optionsContainer.querySelectorAll(
    'input[type="checkbox"]',
  );
  const states = {};
  const checkboxCount = checkboxes.length;
  for (let index = 0; index < checkboxCount; index += 1) {
    if (!(index in checkboxes)) continue;
    const checkbox = checkboxes[index];
    states[checkbox.id] = checkbox.checked;
  }
  taskOptionsStates[activeTaskId] = states;
}

function bindRealtimeTextareaAutosave(textarea) {
  if (realtimeTextareaAutosaveBinding !== null) {
    if (realtimeTextareaAutosaveBinding.textarea === textarea) {
      return realtimeTextareaAutosaveBinding;
    }
    if (
      realtimeTextareaAutosaveBinding.textarea &&
      typeof realtimeTextareaAutosaveBinding.textarea.removeEventListener ===
        "function"
    ) {
      realtimeTextareaAutosaveBinding.textarea.removeEventListener(
        "input",
        handleRealtimeTextareaAutosave,
      );
    }
    realtimeTextareaAutosaveBinding = null;
  }
  if (!textarea || typeof textarea.addEventListener !== "function") {
    return null;
  }
  textarea.addEventListener("input", handleRealtimeTextareaAutosave);
  realtimeTextareaAutosaveBinding = { textarea: textarea };
  return realtimeTextareaAutosaveBinding;
}

function bindRealtimeOptionsAutosave(optionsContainer) {
  if (realtimeOptionsAutosaveBinding !== null) {
    if (realtimeOptionsAutosaveBinding.optionsContainer === optionsContainer) {
      return realtimeOptionsAutosaveBinding;
    }
    const oldOptionsContainer =
      realtimeOptionsAutosaveBinding.optionsContainer;
    if (
      oldOptionsContainer &&
      typeof oldOptionsContainer.removeEventListener === "function"
    ) {
      oldOptionsContainer.removeEventListener(
        "change",
        handleRealtimeOptionsAutosave,
      );
    }
    realtimeOptionsAutosaveBinding = null;
  }
  if (
    !optionsContainer ||
    typeof optionsContainer.addEventListener !== "function"
  ) {
    return null;
  }
  optionsContainer.addEventListener("change", handleRealtimeOptionsAutosave);
  realtimeOptionsAutosaveBinding = {
    optionsContainer: optionsContainer,
  };
  return realtimeOptionsAutosaveBinding;
}

function setupRealtimeAutosaveListeners() {
  const textarea = document.getElementById("feedback-text");
  const optionsContainer = document.getElementById("options-container");
  return {
    textarea: bindRealtimeTextareaAutosave(textarea),
    optionsContainer: bindRealtimeOptionsAutosave(optionsContainer),
  };
}

if (typeof window !== "undefined") {
  window.multiTaskModule = {
    startTasksPolling,
    stopTasksPolling,
    switchTask,
    closeTask,
    initMultiTaskSupport,
    refreshTasksList,

    startTasksHealthCheck,
    stopTasksHealthCheck,

    forceUpdateAllTaskCountdowns,
    installCountdownVisibilitySyncHandlerOnce,
    get sseConnected() {
      return _sseConnected;
    },
    get sseSharedMode() {
      if (!_sseSharedChannel) return "direct";
      return _sseSharedIsLeader ? "leader" : "follower";
    },
  };

  window.refreshTasksList = refreshTasksList;
}

if (
  typeof document !== "undefined" &&
  typeof document.addEventListener === "function"
) {
  document.addEventListener("DOMContentLoaded", () => {

    fetchFeedbackPromptsFresh();
  });
}
