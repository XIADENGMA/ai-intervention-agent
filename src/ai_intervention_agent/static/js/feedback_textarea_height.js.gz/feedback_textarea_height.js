(function () {
  "use strict";

  const STORAGE_KEY = "aiia.feedbackTextareaHeight.v1";
  const SCHEMA_VERSION = 1;
  const MIN_HEIGHT_PX = 100;
  const MAX_HEIGHT_PX = 800;
  const DEBOUNCE_MS = 150;
  const TARGET_ID = "feedback-text";
  let activeResizeBinding = null;

  function _clamp(value) {
    return Math.max(MIN_HEIGHT_PX, Math.min(MAX_HEIGHT_PX, value));
  }

  function readPersistedHeight() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      if (parsed.schema_version !== SCHEMA_VERSION) return null;
      const height = parsed.height_px;
      if (typeof height !== "number" || !Number.isFinite(height)) return null;
      return _clamp(height);
    } catch (_e) {
      return null;
    }
  }

  function persistHeight(height) {
    if (typeof height !== "number" || !Number.isFinite(height)) {
      return false;
    }
    try {
      const clamped = _clamp(height);
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          schema_version: SCHEMA_VERSION,
          height_px: clamped,
          saved_at: Date.now(),
        }),
      );
      return true;
    } catch (_e) {
      return false;
    }
  }

  function applyPersistedHeight(textarea) {
    if (!textarea) return false;
    const persisted = readPersistedHeight();
    if (persisted === null) return false;
    textarea.style.height = persisted + "px";
    return true;
  }

  function disconnectActiveResizeBinding() {
    if (!activeResizeBinding) return;
    if (activeResizeBinding.timeoutId) clearTimeout(activeResizeBinding.timeoutId);
    if (
      activeResizeBinding.observer &&
      typeof activeResizeBinding.observer.disconnect === "function"
    ) {
      activeResizeBinding.observer.disconnect();
    }
    if (activeResizeBinding.mode === "mouseup_fallback") {
      const textarea = activeResizeBinding.textarea;
      if (textarea && typeof textarea.removeEventListener === "function") {
        textarea.removeEventListener("mouseup", activeResizeBinding.handler);
        textarea.removeEventListener("touchend", activeResizeBinding.handler);
      }
    }
    activeResizeBinding = null;
  }

  function setupResizeObserver(textarea) {
    if (!textarea) return null;
    if (activeResizeBinding && activeResizeBinding.textarea === textarea) {
      return activeResizeBinding;
    }
    disconnectActiveResizeBinding();

    const binding = {
      textarea: textarea,
      observer: null,
      handler: null,
      timeoutId: null,
    };
    const handler = function () {
      if (binding.timeoutId) {
        clearTimeout(binding.timeoutId);
      }
      binding.timeoutId = setTimeout(function () {
        const h = textarea.offsetHeight;
        if (h >= MIN_HEIGHT_PX && h <= MAX_HEIGHT_PX) {
          persistHeight(h);
        }
        binding.timeoutId = null;
      }, DEBOUNCE_MS);
    };
    binding.handler = handler;

    if (typeof ResizeObserver !== "undefined") {
      const ro = new ResizeObserver(handler);
      ro.observe(textarea);
      binding.observer = ro;
      binding.mode = "resize_observer";
      activeResizeBinding = binding;
      return binding;
    }
    textarea.addEventListener("mouseup", handler);
    textarea.addEventListener("touchend", handler);
    binding.mode = "mouseup_fallback";
    activeResizeBinding = binding;
    return binding;
  }

  function init() {
    const textarea = document.getElementById(TARGET_ID);
    if (!textarea) return null;
    applyPersistedHeight(textarea);
    return setupResizeObserver(textarea);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.AIIA_FEEDBACK_TEXTAREA_HEIGHT = {
    STORAGE_KEY: STORAGE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    MIN_HEIGHT_PX: MIN_HEIGHT_PX,
    MAX_HEIGHT_PX: MAX_HEIGHT_PX,
    DEBOUNCE_MS: DEBOUNCE_MS,
    TARGET_ID: TARGET_ID,
    readPersistedHeight: readPersistedHeight,
    persistHeight: persistHeight,
    applyPersistedHeight: applyPersistedHeight,
    setupResizeObserver: setupResizeObserver,
    init: init,
  };
})();
