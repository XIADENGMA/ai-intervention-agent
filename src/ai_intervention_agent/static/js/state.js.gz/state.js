;(function (global) {
  'use strict'

  var ConnectionStatus = Object.freeze({
    IDLE: 'idle',
    CONNECTING: 'connecting',
    CONNECTED: 'connected',
    DISCONNECTED: 'disconnected',
    RETRYING: 'retrying',
    CLOSED: 'closed'
  })

  var ContentStatus = Object.freeze({
    SKELETON: 'skeleton',
    LOADING: 'loading',
    READY: 'ready',
    EMPTY: 'empty',
    ERROR: 'error'
  })

  var InteractionPhase = Object.freeze({
    VIEWING: 'viewing',
    COMPOSING: 'composing',
    SUBMITTING: 'submitting',
    COOLDOWN: 'cooldown'
  })

  var TRANSITIONS = Object.freeze({
    connection: Object.freeze({
      idle: ['connecting', 'closed'],
      connecting: ['connected', 'disconnected', 'closed'],
      connected: ['disconnected', 'closed'],
      disconnected: ['retrying', 'closed'],
      retrying: ['connecting', 'closed'],
      closed: ['idle']
    }),
    content: Object.freeze({
      skeleton: ['loading', 'ready'],
      loading: ['ready', 'empty', 'error'],
      ready: ['loading', 'empty', 'error'],
      empty: ['loading', 'ready'],
      error: ['loading', 'skeleton']
    }),
    interaction: Object.freeze({
      viewing: ['composing'],
      composing: ['viewing', 'submitting'],
      submitting: ['cooldown', 'composing'],
      cooldown: ['viewing', 'composing']
    })
  })

  function InvalidTransition(msg) {
    this.name = 'InvalidTransition'
    this.message = msg || 'invalid state transition'
  }
  InvalidTransition.prototype = Object.create(Error.prototype)
  InvalidTransition.prototype.constructor = InvalidTransition

  function createMachine(kind, initial) {
    var rules = TRANSITIONS[kind]
    if (!rules) throw new Error('AIIAState: unknown state machine ' + kind)
    if (!Object.prototype.hasOwnProperty.call(rules, initial)) {
      throw new Error('AIIAState: ' + kind + ' initial state ' + initial + ' is invalid')
    }

    var status = initial
    var listeners = []

    function canTransition(target) {
      if (target === status) return true
      var allowed = rules[status] || []
      return allowed.indexOf(target) !== -1
    }

    function transition(target) {
      if (target === status) return
      if (!canTransition(target)) {
        throw new InvalidTransition(
          kind + ': ' + status + ' -> ' + target +
          ' is not allowed; allowed: ' + JSON.stringify(rules[status] || [])
        )
      }
      var previous = status
      status = target
      for (var i = 0; i < listeners.length; i++) {
        try { listeners[i](previous, status) } catch (_) { }
      }
    }

    function onChange(cb) {
      if (typeof cb !== 'function') return function () {}
      listeners.push(cb)
      return function unsubscribe() {
        var idx = listeners.indexOf(cb)
        if (idx >= 0) listeners.splice(idx, 1)
      }
    }

    function is(target) {
      return status === target
    }

    function reset(to) {
      if (!Object.prototype.hasOwnProperty.call(rules, to)) {
        throw new Error('AIIAState: ' + kind + ' reset target ' + to + ' is invalid')
      }
      status = to
    }

    return Object.freeze({
      kind: kind,
      get status() { return status },
      is: is,
      canTransition: canTransition,
      transition: transition,
      onChange: onChange,
      reset: reset
    })
  }

  var api = Object.freeze({
    ConnectionStatus: ConnectionStatus,
    ContentStatus: ContentStatus,
    InteractionPhase: InteractionPhase,
    TRANSITIONS: TRANSITIONS,
    InvalidTransition: InvalidTransition,
    createMachine: createMachine
  })

  if (typeof global !== 'undefined') {
    global.AIIAState = api
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api
  }
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this))
