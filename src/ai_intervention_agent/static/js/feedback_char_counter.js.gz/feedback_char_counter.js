(function () {
  "use strict";

  const TARGET_ID = "feedback-text";
  const COUNTER_ID = "feedback-char-counter";

  const WARN_THRESHOLD = 800_000;
  const DANGER_THRESHOLD = 1_000_000;
  const WARN_CLASS = "warn";
  const DANGER_CLASS = "danger";
  const I18N_KEY = "feedback.charCounter";
  let activeBinding = null;

  function _formatCount(count) {

    if (typeof Intl !== "undefined" && Intl.NumberFormat) {
      try {
        return new Intl.NumberFormat().format(count);
      } catch (_e) {
        return String(count);
      }
    }
    return String(count);
  }

  const FALLBACK_TEXT = {
    "feedback.charCounter": "{{count}} chars",
  };

  function _t(key, params) {
    try {
      if (
        typeof window !== "undefined" &&
        window.AIIA_I18N &&
        typeof window.AIIA_I18N.t === "function"
      ) {
        const v = window.AIIA_I18N.t(key, params);
        if (typeof v === "string" && v && v !== key) return v;
      }
    } catch (_e) {

    }
    const fb = FALLBACK_TEXT[key];
    if (typeof fb !== "string") return key;
    if (!params) return fb;
    return fb.replace(/\{\{(\w+)\}\}/g, function (_m, k) {
      return params[k] != null ? String(params[k]) : "";
    });
  }

  function _resolveLabel(count) {
    const formatted = _formatCount(count);
    return _t("feedback.charCounter", { count: formatted });
  }

  function _applyThresholdClass(node, count) {
    if (!node || !node.classList) return;
    node.classList.remove(WARN_CLASS, DANGER_CLASS);
    if (count >= DANGER_THRESHOLD) {
      node.classList.add(DANGER_CLASS);
    } else if (count >= WARN_THRESHOLD) {
      node.classList.add(WARN_CLASS);
    }
  }

  function updateCounter(textarea, counter) {
    if (!textarea || !counter) return 0;
    const value = textarea.value || "";
    const count = value.length;
    if (count === 0) {
      counter.hidden = true;
      counter.textContent = "";
      _applyThresholdClass(counter, 0);
      return 0;
    }
    counter.hidden = false;
    counter.textContent = _resolveLabel(count);
    _applyThresholdClass(counter, count);
    return count;
  }

  function handleInput() {
    if (!activeBinding) return;
    updateCounter(activeBinding.textarea, activeBinding.counter);
  }

  function init() {
    const textarea = document.getElementById(TARGET_ID);
    const counter = document.getElementById(COUNTER_ID);
    if (!textarea || !counter) return null;
    if (activeBinding) {
      if (activeBinding.textarea === textarea && activeBinding.counter === counter) {
        updateCounter(textarea, counter);
        return activeBinding;
      }
      if (activeBinding.textarea.removeEventListener) {
        activeBinding.textarea.removeEventListener("input", handleInput);
      }
    }
    textarea.addEventListener("input", handleInput);
    activeBinding = { textarea: textarea, counter: counter, handler: handleInput };

    updateCounter(textarea, counter);
    return activeBinding;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.AIIA_FEEDBACK_CHAR_COUNTER = {
    TARGET_ID: TARGET_ID,
    COUNTER_ID: COUNTER_ID,
    WARN_THRESHOLD: WARN_THRESHOLD,
    DANGER_THRESHOLD: DANGER_THRESHOLD,
    WARN_CLASS: WARN_CLASS,
    DANGER_CLASS: DANGER_CLASS,
    I18N_KEY: I18N_KEY,
    _formatCount: _formatCount,
    _resolveLabel: _resolveLabel,
    _applyThresholdClass: _applyThresholdClass,
    updateCounter: updateCounter,
    init: init,
  };
})();
