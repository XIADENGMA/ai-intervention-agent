const ThemeManager = (function () {
  'use strict';

  const STORAGE_KEY = 'theme-preference';
  const THEMES = {
    DARK: 'dark',
    LIGHT: 'light',
    AUTO: 'auto'
  };

  let currentTheme = THEMES.AUTO;
  let systemPreference = null;
  let mediaQuery = null;
  let systemPreferenceListenerInstalled = false;
  let storageSyncListenerInstalled = false;

  function detectSystemPreference() {
    const query = getSystemPreferenceMediaQuery();
    if (query && query.matches) {
      return THEMES.LIGHT;
    }
    return THEMES.DARK;
  }

  function getSystemPreferenceMediaQuery() {
    if (!window.matchMedia) return null;
    if (!mediaQuery) {
      mediaQuery = window.matchMedia('(prefers-color-scheme: light)');
    }
    return mediaQuery;
  }

  function handleSystemPreferenceChange(e) {
    systemPreference = e.matches ? THEMES.LIGHT : THEMES.DARK;
    console.debug('System theme preference changed:', systemPreference);

    if (currentTheme === THEMES.AUTO) {
      applyTheme(systemPreference);
    }
    updateToggleButton();
  }

  function listenSystemPreference() {
    systemPreference = detectSystemPreference();

    const query = getSystemPreferenceMediaQuery();
    if (!query || systemPreferenceListenerInstalled) return;

    if (query.addEventListener) {
      query.addEventListener('change', handleSystemPreferenceChange);
      systemPreferenceListenerInstalled = true;
    } else if (query.addListener) {

      query.addListener(handleSystemPreferenceChange);
      systemPreferenceListenerInstalled = true;
    }
  }

  function applyTheme(theme) {
    const html = document.documentElement;
    const effectiveTheme = theme === THEMES.AUTO ? systemPreference : theme;

    if (effectiveTheme === THEMES.DARK || effectiveTheme === THEMES.LIGHT) {
      html.setAttribute('data-theme', effectiveTheme);
    } else {
      html.removeAttribute('data-theme');
    }

    updateMetaThemeColor(effectiveTheme);

    window.dispatchEvent(new CustomEvent('theme-changed', {
      detail: { theme: effectiveTheme, mode: theme }
    }));

    console.debug('Theme applied:', effectiveTheme, '(mode:', theme + ')');
  }

  function updateMetaThemeColor(theme) {
    let metaThemeColor = document.querySelector('meta[name="theme-color"]');

    if (!metaThemeColor) {
      metaThemeColor = document.createElement('meta');
      metaThemeColor.name = 'theme-color';
      document.head.appendChild(metaThemeColor);
    }

    metaThemeColor.content = theme === THEMES.LIGHT ? '#f8fafc' : '#1a1a1f';
  }

  function savePreference(theme) {
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {
      console.warn('Cannot save theme preference to localStorage:', e);
    }
  }

  function loadPreference() {
    try {
      return localStorage.getItem(STORAGE_KEY);
    } catch (e) {
      console.warn('Cannot load theme preference from localStorage:', e);
      return null;
    }
  }

  function createToggleButton() {
    const button = document.createElement('button');
    button.className = 'theme-toggle-btn';

    button.innerHTML = `
      <svg class="theme-icon theme-icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="5"/>
        <line x1="12" y1="1" x2="12" y2="3"/>
        <line x1="12" y1="21" x2="12" y2="23"/>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
        <line x1="1" y1="12" x2="3" y2="12"/>
        <line x1="21" y1="12" x2="23" y2="12"/>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
      </svg>
      <svg class="theme-icon theme-icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
      </svg>
    `;

    button.addEventListener('click', toggleThemeInternal);

    return button;
  }

  function toggleThemeInternal() {

    const effective =
      currentTheme === THEMES.AUTO ? systemPreference : currentTheme;
    currentTheme = effective === THEMES.LIGHT ? THEMES.DARK : THEMES.LIGHT;
    savePreference(currentTheme);
    applyTheme(currentTheme);
    updateToggleButton();
  }

  function updateToggleButton() {
    const effectiveTheme = currentTheme === THEMES.AUTO ? systemPreference : currentTheme;
    const buttons = document.querySelectorAll('.theme-toggle-btn');
    const t = (key) => window.AIIA_I18N ? window.AIIA_I18N.t(key) : key;
    const labels = {
      [THEMES.AUTO]: t('theme.auto'),
      [THEMES.LIGHT]: t('theme.light'),
      [THEMES.DARK]: t('theme.dark')
    };
    const label = labels[currentTheme] || labels[THEMES.AUTO];

    const buttonCount = buttons.length;
    for (let index = 0; index < buttonCount; index += 1) {
      const button = buttons[index];
      if (!button) continue;
      button.classList.toggle('is-light', effectiveTheme === THEMES.LIGHT);
      button.classList.toggle('is-auto', currentTheme === THEMES.AUTO);
      button.setAttribute('aria-label', label);
      button.setAttribute('title', label);
    }
  }

  function bindExistingButtons() {
    const buttons = document.querySelectorAll('.theme-toggle-btn');
    const buttonCount = buttons.length;
    for (let index = 0; index < buttonCount; index += 1) {
      const button = buttons[index];
      if (!button) continue;
      if (!button.hasAttribute('data-theme-bound')) {
        button.addEventListener('click', toggleThemeInternal);
        button.setAttribute('data-theme-bound', 'true');
      }
    }
  }

  function handleStorageChange(event) {
    if (event.key !== STORAGE_KEY) return;
    const newTheme = event.newValue;
    if (!newTheme || !Object.values(THEMES).includes(newTheme)) return;
    if (newTheme === currentTheme) return;
    currentTheme = newTheme;
    applyTheme(newTheme);
    updateToggleButton();
  }

  function setupStorageSync() {
    if (storageSyncListenerInstalled) return;

    try {
      window.addEventListener('storage', handleStorageChange);
      storageSyncListenerInstalled = true;
    } catch (e) {

    }
  }

  return {

    init: function (options = {}) {
      const { defaultTheme = THEMES.AUTO } = options;

      listenSystemPreference();

      const savedTheme = loadPreference();
      currentTheme = savedTheme || defaultTheme;

      applyTheme(currentTheme);
      updateToggleButton();

      bindExistingButtons();

      setupStorageSync();

      console.debug('Theme manager initialized:', currentTheme);
    },

    setTheme: function (theme) {
      if (!Object.values(THEMES).includes(theme)) {
        console.warn('Invalid theme:', theme);
        return;
      }

      currentTheme = theme;
      savePreference(theme);
      applyTheme(theme);
      updateToggleButton();
    },

    toggle: function () {
      const effective =
        currentTheme === THEMES.AUTO ? systemPreference : currentTheme;
      this.setTheme(
        effective === THEMES.LIGHT ? THEMES.DARK : THEMES.LIGHT
      );
    },

    getTheme: function () {
      return currentTheme;
    },

    getEffectiveTheme: function () {
      return currentTheme === THEMES.AUTO ? systemPreference : currentTheme;
    },

    insertToggleButton: function (container) {
      const target = typeof container === 'string'
        ? document.querySelector(container)
        : container;

      if (target) {
        const button = createToggleButton();
        target.appendChild(button);
        updateToggleButton();
      }
    },

    THEMES: THEMES
  };
})();

document.addEventListener('DOMContentLoaded', () => {
  ThemeManager.init();
});

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ThemeManager;
}
