window.MathJax = {

  tex: {

    inlineMath: [
      ['$', '$'],
      ['\\(', '\\)']
    ],

    displayMath: [
      ['$$', '$$'],
      ['\\[', '\\]']
    ],

    processEscapes: true,

    processEnvironments: true,

    packages: { '[+]': ['ams', 'newcommand', 'configmacros'] },

    tags: 'ams'
  },

  chtml: {

    fontURL: null,

  },

  options: {

    skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code'],

    ignoreHtmlClass: 'tex2jax_ignore',

    processHtmlClass: 'tex2jax_process'
  },

  startup: {

    ready: () => {

      console.debug('MathJax loaded')

      MathJax.startup.defaultReady()
    }
  }
}
