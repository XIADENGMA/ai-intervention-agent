function t(key, params) {
  try {
    if (window.AIIA_I18N && typeof window.AIIA_I18N.t === 'function') {
      return window.AIIA_I18N.t(key, params)
    }
  } catch (_e) { }
  return key
}

function isMobileDevice() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent
  )
}

const DEFAULT_NOTIFICATION_SOUND_URL = '/sounds/deng.wav'
const AUTO_PERMISSION_REQUEST_LISTENER_OPTIONS = {
  once: true,
  passive: true
}

const CUSTOM_SOUND_LS_KEY = 'aiia.notif.customSound.v1'
const CUSTOM_SOUND_MAX_BYTES = 700 * 1024

const CUSTOM_SOUND_MAX_DURATION_S = 30
const CUSTOM_SOUND_ALLOWED_MIMES = [
  'audio/mpeg',
  'audio/wav',
  'audio/wave',
  'audio/x-wav',
  'audio/ogg',
  'audio/webm',
  'audio/aac',
  'audio/mp4',
  'audio/flac'
]

class NotificationManager {
  constructor() {
    this.isSupported = 'Notification' in window
    this.permission = this.isSupported ? Notification.permission : 'denied'
    this.audioContext = null
    this.audioBuffers = new Map()
    this.serviceWorkerRegistration = null
    this.initPromise = null
    this.permissionRequestPromise = null
    this.autoPermissionListenersBound = false
    this.boundPermissionRequestHandler = null
    this._titleFlashInterval = null
    this._titleFlashOriginalTitle = null
    this.config = {
      enabled: true,
      webEnabled: true,
      soundEnabled: true,
      soundVolume: 0.8,
      soundMute: false,
      autoRequestPermission: true,
      timeout: 5000,

      icon: '/icons/icon-192.png',
      mobileOptimized: true,
      mobileVibrate: true
    }
  }

  async init() {
    if (this.initPromise) {
      return this.initPromise
    }

    this.initPromise = (async () => {
      console.debug('Initializing notification manager…')
      try {
        const hostname =
          window.location && typeof window.location.hostname === 'string'
            ? window.location.hostname
            : ''
        const origin =
          window.location && typeof window.location.origin === 'string'
            ? window.location.origin
            : ''
        const secureContext =
          typeof window.isSecureContext === 'boolean' ? window.isSecureContext : null
        console.debug(
          '[notification env] hostname:',
          hostname,
          'isSecureContext:',
          secureContext,
          'origin:',
          origin
        )
      } catch (e) {

      }
      this.syncPermissionState()

      if (!this.isSupported) {
        console.warn('Browser does not support Web Notification API')
      } else {
        this.bindAutoPermissionRequest()
      }

      await this.registerServiceWorker()

      await this.initAudio()
      console.debug('Notification manager initialized')
    })()

    return this.initPromise
  }

  syncPermissionState() {
    this.permission = this.isSupported ? Notification.permission : 'denied'
    return this.permission
  }

  supportsServiceWorkerNotifications() {
    return (
      typeof navigator !== 'undefined' &&
      'serviceWorker' in navigator &&
      Boolean(window.isSecureContext)
    )
  }

  async registerServiceWorker() {
    if (!this.supportsServiceWorkerNotifications()) {
      if (typeof window.isSecureContext === 'boolean' && window.isSecureContext === false) {
        console.warn('Not in a secure context; cannot register notification service worker')
      }
      return null
    }

    if (this.serviceWorkerRegistration) {
      return this.serviceWorkerRegistration
    }

    try {
      await navigator.serviceWorker.register('/notification-service-worker.js')
      this.serviceWorkerRegistration = await navigator.serviceWorker.ready
      console.debug('Notification service worker registered')
      return this.serviceWorkerRegistration
    } catch (error) {
      console.warn('Notification service worker registration failed:', error)
      return null
    }
  }

  bindAutoPermissionRequest() {
    if (!this.isSupported) return

    if (typeof window.isSecureContext === 'boolean' && window.isSecureContext === false) {
      this.removeAutoPermissionRequestListeners()
      return
    }

    if (!this.config.autoRequestPermission || this.syncPermissionState() !== 'default') {
      this.removeAutoPermissionRequestListeners()
      return
    }

    if (this.autoPermissionListenersBound) {
      return
    }

    this.boundPermissionRequestHandler = () => {
      if (!this.config.autoRequestPermission) {
        this.removeAutoPermissionRequestListeners()
        return
      }

      if (this.syncPermissionState() !== 'default') {
        this.removeAutoPermissionRequestListeners()
        return
      }

      this.removeAutoPermissionRequestListeners()
      this.requestPermission({ requireUserGesture: false }).finally(() => {
        if (!this.config.autoRequestPermission || this.syncPermissionState() !== 'default') {
          this.removeAutoPermissionRequestListeners()
          return
        }
        this.bindAutoPermissionRequest()
      })
    }
    this.addAutoPermissionRequestListeners()

    this.autoPermissionListenersBound = true
  }

  addAutoPermissionRequestListeners() {
    const handler = this.boundPermissionRequestHandler
    document.addEventListener('click', handler, AUTO_PERMISSION_REQUEST_LISTENER_OPTIONS)
    document.addEventListener('keydown', handler, AUTO_PERMISSION_REQUEST_LISTENER_OPTIONS)
    document.addEventListener('touchstart', handler, AUTO_PERMISSION_REQUEST_LISTENER_OPTIONS)
  }

  removeAutoPermissionRequestListeners() {
    if (!this.autoPermissionListenersBound || !this.boundPermissionRequestHandler) {
      return
    }

    this.removeBoundAutoPermissionRequestListeners()

    this.autoPermissionListenersBound = false
    this.boundPermissionRequestHandler = null
  }

  removeBoundAutoPermissionRequestListeners() {
    const handler = this.boundPermissionRequestHandler
    document.removeEventListener('click', handler)
    document.removeEventListener('keydown', handler)
    document.removeEventListener('touchstart', handler)
  }

  async requestPermission({ requireUserGesture = true } = {}) {
    if (!this.isSupported) {
      console.warn('Browser does not support Web Notification API')
      return false
    }

    this.syncPermissionState()
    if (this.permission === 'granted') {
      return true
    }

    if (this.permission === 'denied') {
      return false
    }

    if (typeof window.isSecureContext === 'boolean' && window.isSecureContext === false) {
      console.warn('Not in a secure context; browser will not prompt for notification permission')
      return false
    }

    if (
      requireUserGesture &&
      navigator.userActivation &&
      navigator.userActivation.isActive === false
    ) {
      console.warn('Notification permission request requires user gesture; deferred to next interaction')
      this.bindAutoPermissionRequest()
      return false
    }

    if (this.permissionRequestPromise) {
      return this.permissionRequestPromise
    }

    try {
      this.permissionRequestPromise = (async () => {
        if (Notification.requestPermission.length === 0) {
          this.permission = await Notification.requestPermission()
        } else {
          this.permission = await new Promise(resolve => {
            Notification.requestPermission(resolve)
          })
        }

        console.debug(`Notification permission state: ${this.permission}`)
        window.dispatchEvent(
          new CustomEvent('notification-permission-changed', {
            detail: { permission: this.permission }
          })
        )
        return this.permission === 'granted'
      })()

      return await this.permissionRequestPromise
    } catch (error) {
      console.error('Request notification permission failed:', error)
      return false
    } finally {
      this.permissionRequestPromise = null
      if (this.permission !== 'default') {
        this.removeAutoPermissionRequestListeners()
      }
    }
  }

  async initAudio() {
    try {

      const AudioContextClass =
        window.AudioContext || window.webkitAudioContext || window.mozAudioContext
      if (!AudioContextClass) {
        console.warn('Browser does not support Web Audio API')
        return
      }

      this.audioContext = new AudioContextClass()

      await this.loadAudioFile('default', DEFAULT_NOTIFICATION_SOUND_URL)
      if (!this.audioBuffers.has('default')) {
        this._synthBuffer = this._createSynthNotificationBuffer()
      }

      await this.loadCustomSoundFromStorage()

      console.debug('Audio system initialized')
    } catch (error) {
      console.warn('Audio system initialization failed:', error)

      this.config.soundEnabled = false
    }
  }

  hasCustomSound() {
    try {
      const raw = localStorage.getItem(CUSTOM_SOUND_LS_KEY)
      return Boolean(raw)
    } catch (e) {
      return false
    }
  }

  getCustomSoundMeta() {
    try {
      const raw = localStorage.getItem(CUSTOM_SOUND_LS_KEY)
      if (!raw) return null
      const obj = JSON.parse(raw)
      if (!obj || typeof obj !== 'object') return null
      return {
        name: String(obj.name || 'custom'),
        mime: String(obj.mime || ''),
        size: Number(obj.size || 0)
      }
    } catch (e) {
      return null
    }
  }

  async loadCustomSoundFromStorage() {
    if (!this.audioContext) return false
    let raw
    try {
      raw = localStorage.getItem(CUSTOM_SOUND_LS_KEY)
    } catch (e) {

      return false
    }
    if (!raw) {

      this.audioBuffers.delete('custom')
      return false
    }
    let obj
    try {
      obj = JSON.parse(raw)
    } catch (e) {
      console.warn('Custom sound localStorage entry not valid JSON; clearing')
      this.clearCustomSound()
      return false
    }
    if (!obj || typeof obj.dataUri !== 'string') {
      this.clearCustomSound()
      return false
    }
    try {
      const response = await fetch(obj.dataUri)
      const arrayBuffer = await response.arrayBuffer()
      const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer)
      this.audioBuffers.set('custom', audioBuffer)
      console.debug(`Custom sound loaded: ${obj.name || '(unnamed)'}`)
      return true
    } catch (error) {

      console.warn('Custom sound decode failed:', error)
      this.audioBuffers.delete('custom')
      return false
    }
  }

  async saveCustomSoundFromFile(file) {
    if (!file || typeof file !== 'object') {
      return { success: false, error: 'no_file' }
    }
    const mime = String(file.type || '').toLowerCase()
    if (!CUSTOM_SOUND_ALLOWED_MIMES.includes(mime)) {
      return { success: false, error: 'invalid_mime', mime }
    }
    if (typeof file.size !== 'number' || file.size > CUSTOM_SOUND_MAX_BYTES) {
      return {
        success: false,
        error: 'too_large',
        size: file.size,
        maxBytes: CUSTOM_SOUND_MAX_BYTES
      }
    }

    const dataUri = await new Promise((resolve, reject) => {
      try {
        const fr = new FileReader()
        fr.onload = () => resolve(String(fr.result || ''))
        fr.onerror = () => reject(fr.error || new Error('FileReader error'))
        fr.readAsDataURL(file)
      } catch (e) {
        reject(e)
      }
    }).catch(() => null)
    if (!dataUri || !dataUri.startsWith('data:')) {
      return { success: false, error: 'read_failed' }
    }

    if (this.audioContext) {
      let preflightBuffer = null
      try {
        const r = await fetch(dataUri)
        const ab = await r.arrayBuffer()
        preflightBuffer = await this.audioContext.decodeAudioData(ab)
      } catch (e) {
        return { success: false, error: 'decode_failed', detail: String(e && e.message ? e.message : e) }
      }
      if (preflightBuffer.duration > CUSTOM_SOUND_MAX_DURATION_S) {
        return {
          success: false,
          error: 'duration_too_long',
          duration: preflightBuffer.duration,
          maxDuration: CUSTOM_SOUND_MAX_DURATION_S
        }
      }
    }
    const meta = {
      name: String(file.name || 'custom'),
      mime,
      size: Number(file.size || 0),
      uploadedAt: Date.now()
    }
    try {
      localStorage.setItem(
        CUSTOM_SOUND_LS_KEY,
        JSON.stringify({ ...meta, dataUri })
      )
    } catch (e) {
      return { success: false, error: 'storage_failed', detail: e.message }
    }
    const decoded = await this.loadCustomSoundFromStorage()
    if (!decoded) {

      this.clearCustomSound()
      return { success: false, error: 'decode_failed', meta }
    }
    return { success: true, meta }
  }

  clearCustomSound() {
    try {
      localStorage.removeItem(CUSTOM_SOUND_LS_KEY)
    } catch (e) {

    }
    this.audioBuffers.delete('custom')
  }

  async loadAudioFile(name, url) {
    if (!this.audioContext) return false

    try {
      const response = await fetch(url)
      const arrayBuffer = await response.arrayBuffer()
      const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer)
      this.audioBuffers.set(name, audioBuffer)
      console.debug(`Audio file loaded: ${name}`)
      return true
    } catch (error) {
      console.warn(`Audio file load failed ${name}:`, error)
      return false
    }
  }

  async showNotification(title, message, options = {}) {
    if (!this.config.enabled || !this.config.webEnabled) {
      console.debug('Web notifications disabled')
      return null
    }

    if (!this.isSupported) {
      console.warn('Browser does not support notifications; using fallback')
      this.showFallbackNotification(title, message, { ...options, reason: 'unsupported' })
      return null
    }

    if (typeof window.isSecureContext === 'boolean' && window.isSecureContext === false) {
      const origin =
        window.location && typeof window.location.origin === 'string' ? window.location.origin : ''
      const host =
        window.location && typeof window.location.host === 'string' ? window.location.host : ''
      const where = origin || host || 'current page'
      this.showFallbackNotification(
        'Browser native notifications unavailable',
        `Current origin (${where}) is not a secure context. Please access over HTTPS or localhost/127.0.0.1 and retry.`,
        { ...options, reason: 'insecure_context' }
      )
      return null
    }

    this.syncPermissionState()
    if (this.permission !== 'granted') {
      console.warn('No system notification permission granted')
      if (this.config.autoRequestPermission) {
        const granted = await this.requestPermission({
          requireUserGesture: !(navigator.userActivation && navigator.userActivation.isActive)
        })
        if (!granted) {
          this.showFallbackNotification(title, message, {
            ...options,
            reason: this.permission === 'denied' ? 'permission_denied' : 'permission_default'
          })
          return null
        }
      } else {
        this.showFallbackNotification(title, message, {
          ...options,
          reason: 'permission_disabled'
        })
        return null
      }
    }

    try {
      const {
        onClick,
        url,
        data: extraData,
        icon,
        badge,
        tag,
        requireInteraction,
        silent,
        ...restOptions
      } = options

      const notificationOptions = {
        body: message,
        icon: icon || this.config.icon,
        tag: tag || 'ai-intervention-agent',
        requireInteraction: requireInteraction || false,
        silent: silent || false,
        data: {
          url: url || window.location.href,
          ...extraData
        },
        ...restOptions
      }
      if (typeof badge === 'string' && badge) {

        notificationOptions.badge = badge
      }

      const notification = await this.showSystemNotification(title, notificationOptions, {
        ...restOptions,
        onClick
      })

      if (!notification) {
        this.showFallbackNotification(title, message, {
          ...options,
          reason: 'system_notification_failed'
        })
        return null
      }

      console.debug('System notification shown:', title)
      return notification
    } catch (error) {
      console.error('Show notification failed:', error)
      this.showFallbackNotification(title, message, {
        ...options,
        reason: 'show_notification_exception'
      })
      return null
    }
  }

  isElectronHost() {
    try {
      return /\bElectron\//i.test(navigator.userAgent)
    } catch (_e) {
      return false
    }
  }

  async showSystemNotification(title, notificationOptions, options = {}) {

    const skipServiceWorkerPath = this.isElectronHost()
    const registration = skipServiceWorkerPath
      ? null
      : await this.registerServiceWorker()
    if (registration && typeof registration.showNotification === 'function') {
      try {
        await registration.showNotification(title, notificationOptions)

        let displayed = true
        try {
          if (typeof registration.getNotifications === 'function') {
            const shown = await registration.getNotifications({
              tag: notificationOptions.tag
            })
            displayed = !!(shown && shown.length > 0)
          }
        } catch (_e) {
          displayed = true
        }
        if (displayed) {
          return {
            close() {}
          }
        }
        console.warn(
          'Service worker notification was silently dropped (likely an embedded webview host); falling back to page Notification'
        )
      } catch (error) {
        console.warn('Failed to show notification via service worker; falling back to page Notification:', error)
      }
    }

    try {
      const notification = new Notification(title, notificationOptions)

      if (this.config.timeout > 0) {
        setTimeout(() => {
          notification.close()
        }, this.config.timeout)
      }

      notification.onclick = () => {
        window.focus()
        notification.close()
        if (options.onClick) {
          options.onClick()
        }
      }

      if (this.config.mobileVibrate && 'vibrate' in navigator) {
        navigator.vibrate([200, 100, 200])
      }

      return notification
    } catch (error) {
      console.error('Page Notification creation failed:', error)
      return null
    }
  }

  async playSound(soundName = null, volume = null, retryCount = 0) {
    if (!this.config.enabled || !this.config.soundEnabled || this.config.soundMute) {
      console.debug('Sound notifications disabled')
      return false
    }

    if (soundName === null || soundName === undefined) {
      soundName = this.audioBuffers.has('custom') ? 'custom' : 'default'
    }

    if (!this.audioContext) {
      console.warn('Audio context not initialized; trying fallback')
      this.recordFallbackEvent('audio', { reason: 'no_audio_context', soundName })
      return this.playSoundFallback(soundName)
    }

    if (this.audioContext.state === 'suspended') {
      try {
        await this.audioContext.resume()
        console.debug('Audio context resumed')
      } catch (error) {
        console.warn('Resume audio context failed:', error)
        this.recordFallbackEvent('audio', {
          reason: 'resume_failed',
          error: error.message,
          soundName
        })
        return this.playSoundFallback(soundName)
      }
    }

    const audioBuffer = this.audioBuffers.get(soundName)
    if (!audioBuffer) {
      console.warn(`Audio file not found: ${soundName}`)

      if (soundName !== 'default') {
        console.debug('Trying default audio file')
        return this.playSound('default', volume, retryCount)
      }
      this.recordFallbackEvent('audio', { reason: 'buffer_not_found', soundName })
      return this.playSoundFallback(soundName)
    }

    try {
      const source = this.audioContext.createBufferSource()
      const gainNode = this.audioContext.createGain()

      source.buffer = audioBuffer
      source.connect(gainNode)
      gainNode.connect(this.audioContext.destination)

      const finalVolume = volume !== null ? volume : this.config.soundVolume
      gainNode.gain.value = Math.max(0, Math.min(1, finalVolume))

      source.addEventListener('ended', () => {
        console.debug(`Sound playback finished: ${soundName}`)
      })

      source.addEventListener('error', error => {
        console.error('Audio playback error:', error)
        this.recordFallbackEvent('audio', {
          reason: 'playback_error',
          error: error.message,
          soundName
        })
      })

      source.start(0)
      console.debug(`Playing sound: ${soundName}`)
      return true
    } catch (error) {
      console.error('Play sound failed:', error)
      this.recordFallbackEvent('audio', {
        reason: 'playback_failed',
        error: error.message,
        soundName
      })

      if (retryCount < 2) {
        console.debug(`Retry play sound (${retryCount + 1}/2): ${soundName}`)
        await new Promise(resolve => setTimeout(resolve, 500))
        return this.playSound(soundName, volume, retryCount + 1)
      }

      return this.playSoundFallback(soundName)
    }
  }

  _createSynthNotificationBuffer() {
    if (!this.audioContext) return null
    try {
      const sr = this.audioContext.sampleRate
      const dur = 0.22
      const len = Math.ceil(sr * dur)
      const buf = this.audioContext.createBuffer(1, len, sr)
      const ch = buf.getChannelData(0)
      const f1 = 523.25, f2 = 659.25
      for (let i = 0; i < len; i++) {
        const t = i / sr
        const env = Math.exp(-t * 12)
        ch[i] = env * 0.35 * (Math.sin(2 * Math.PI * f1 * t) + 0.6 * Math.sin(2 * Math.PI * f2 * t))
      }
      return buf
    } catch (e) {
      return null
    }
  }

  playSoundFallback(soundName) {
    console.debug(`Using audio fallback: ${soundName}`)

    if (this.audioContext && this._synthBuffer) {
      try {
        if (this.audioContext.state === 'suspended') this.audioContext.resume()
        const src = this.audioContext.createBufferSource()
        const gain = this.audioContext.createGain()
        src.buffer = this._synthBuffer
        src.connect(gain)
        gain.connect(this.audioContext.destination)
        gain.gain.value = Math.max(0, Math.min(1, this.config.soundVolume))
        src.start(0)
        console.debug('Synth notification sound played successfully')
        return true
      } catch (e) {
        console.warn('Synth notification sound failed:', e)
      }
    }

    try {
      const audio = new Audio(
        soundName === 'default' ? DEFAULT_NOTIFICATION_SOUND_URL : `/sounds/${soundName}.mp3`
      )
      audio.volume = Math.max(0, Math.min(1, this.config.soundVolume))
      const playPromise = audio.play()
      if (playPromise !== undefined) {
        playPromise.catch(() => this.vibrateFallback())
      }
      return true
    } catch (error) {
      return this.vibrateFallback()
    }
  }

  vibrateFallback() {

    if (this.config.mobileVibrate && 'vibrate' in navigator) {
      try {
        navigator.vibrate([200, 100, 200])
        console.debug('Using vibration alert')
        return true
      } catch (error) {
        console.warn('Vibration alert failed:', error)
      }
    }

    console.debug('All audio fallbacks failed')
    return false
  }

  async sendNotification(title, message, options = {}) {
    const results = []

    const promises = []

    if (this.config.webEnabled) {
      promises.push(
        this.showNotification(title, message, options).then(notification => ({
          type: 'web',
          success: notification !== null
        }))
      )
    }

    if (this.config.soundEnabled) {
      promises.push(
        this.playSound(options.sound).then(soundSuccess => ({
          type: 'sound',
          success: soundSuccess
        }))
      )
    }

    if (promises.length > 0) {
      try {
        const promiseResults = await Promise.all(promises)
        results.push(...promiseResults)
      } catch (error) {
        console.warn('Notification execution error:', error)
      }
    }

    return results
  }

  async dispatchEvent(event) {
    try {
      const evt = event && typeof event === 'object' ? event : {}
      const type = String(evt.type || evt.kind || '').trim()

      if (type === 'new_tasks' || type === 'newTasks') {
        return await this.notifyNewTasks(evt)
      }

      if (typeof evt.title === 'string' && typeof evt.message === 'string') {
        return await this.sendNotification(evt.title, evt.message, evt.options || {})
      }

      return null
    } catch (error) {
      console.warn('dispatchEvent failed (falling back):', error)
      return null
    }
  }

  async notifyNewTasks(event = {}) {
    const countRaw = event && typeof event === 'object' ? event.count : null
    const taskIdsRaw = event && typeof event === 'object' ? event.taskIds : null

    let taskIds = null
    let taskIdCount = 0
    if (Array.isArray(taskIdsRaw)) {
      for (let i = 0; i < taskIdsRaw.length; i += 1) {
        if (!(i in taskIdsRaw)) continue
        const taskId = taskIdsRaw[i]
        if (taskId) {
          if (taskIds === null) taskIds = []
          taskIds.push(taskId)
          taskIdCount += 1
        }
      }
    }
    const count =
      typeof countRaw === 'number' && Number.isFinite(countRaw)
        ? Math.max(0, Math.floor(countRaw))
        : taskIdCount

    if (!count || count <= 0) return null
    if (this.config && this.config.enabled === false) return null
    if (taskIds === null) taskIds = []

    const title =
      typeof event.title === 'string' && event.title ? event.title : 'AI Intervention Agent'
    const message =
      count === 1 && taskIdCount === 1 ? `New task added: ${taskIds[0]}` : `Received ${count} new task(s)`

    let pageAway = false
    try {
      if (typeof document !== 'undefined') {
        const hidden = document.hidden === true
        const unfocused = typeof document.hasFocus === 'function' && !document.hasFocus()
        pageAway = hidden || unfocused
      }
    } catch (e) {
      pageAway = false
    }

    if (pageAway) {

      try {
        await this.showNotification(title, message, {
          tag: 'aiia-new-tasks',
          requireInteraction: false
        })
      } catch (e) {

      }
    } else {

      try {
        if (typeof window.showNewTaskVisualHint === 'function') {
          window.showNewTaskVisualHint(count)
        } else {

          this.showInPageNotification(title, message, { timeout: 3000 })
        }
      } catch (e) {

      }
    }

    try {
      await this.playSound('default')
    } catch (e) {

    }

    return { title, message, count, taskIds }
  }

  showFallbackNotification(title, message, options = {}) {

    console.debug(`Fallback notification: ${title} - ${message}`)
    const reason = options && typeof options === 'object' ? options.reason || 'unknown' : 'unknown'

    const reasonHintMap = {
      permission_denied: () => t('status.notifFallbackPermDenied'),
      permission_default: () => t('status.notifFallbackPermDefault'),
      permission_disabled: () => t('status.notifFallbackPermDisabled'),
      unsupported: () => t('status.notifFallbackUnsupported'),
      insecure_context: () => t('status.notifFallbackInsecure')
    }
    let toastMessage = `${title}: ${message}`
    const hintFn = reasonHintMap[reason]
    if (typeof hintFn === 'function') {
      const hint = hintFn()

      if (hint && !hint.startsWith('status.notifFallback')) {
        toastMessage = `${title}: ${message} — ${hint}`
      }
    }

    if (typeof showStatus === 'function') {
      showStatus(toastMessage, 'warning')
    }

    this.flashTitle(title)

    if (!this.isSupported || this.permission === 'denied' || reason === 'insecure_context') {
      this.showInPageNotification(title, message, options)
    }

    console.debug(`%c[notification] ${title}`, 'color: #0084ff; font-weight: bold; font-size: 14px;')
    console.debug(`%c${message}`, 'color: #666; font-size: 12px;')

    this.recordFallbackEvent('notification', {
      title,
      message,
      reason
    })
  }

  clearTitleFlash() {
    if (this._titleFlashInterval !== null) {
      clearInterval(this._titleFlashInterval)
      this._titleFlashInterval = null
    }

    if (this._titleFlashOriginalTitle !== null) {
      document.title = this._titleFlashOriginalTitle
      this._titleFlashOriginalTitle = null
    }
  }

  flashTitle(message) {

    this.clearTitleFlash()
    this._titleFlashOriginalTitle = document.title
    let flashCount = 0
    const maxFlashes = 6

    this._titleFlashInterval = setInterval(() => {
      const originalTitle =
        this._titleFlashOriginalTitle !== null ? this._titleFlashOriginalTitle : document.title
      document.title = flashCount % 2 === 0 ? t('notify.titleFlash', { message: message }) : originalTitle
      flashCount++

      if (flashCount >= maxFlashes) {
        this.clearTitleFlash()
      }
    }, 1000)
  }

  updateConfig(newConfig) {
    this.config = { ...this.config, ...newConfig }
    this.syncPermissionState()
    this.bindAutoPermissionRequest()
    console.debug('Notification config updated:', this.config)
  }

  getStatus() {
    return {
      supported: this.isSupported,
      permission: this.permission,
      serviceWorkerRegistered: Boolean(this.serviceWorkerRegistration),
      audioContext: this.audioContext ? this.audioContext.state : 'unavailable',
      config: this.config
    }
  }

  _getInPageNotificationTimeoutMs(options = {}) {
    const rawTimeout = Object.prototype.hasOwnProperty.call(options, 'timeout')
      ? options.timeout
      : this.config.timeout
    const timeout = Number(rawTimeout)
    if (!Number.isFinite(timeout)) {
      return 5000
    }
    return Math.max(0, Math.floor(timeout))
  }

  showInPageNotification(title, message, options = {}) {

    const notification = DOMSecurity.createNotification(title, message)

    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(30, 30, 40, 0.95);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 12px;
      padding: 1rem;
      max-width: 300px;
      z-index: 10000;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(10px);
      color: #f5f5f7;
      font-family: inherit;
    `

    const titleEl = notification.querySelector('.in-page-notification-title')
    const messageEl = notification.querySelector('.in-page-notification-message')
    const closeEl = notification.querySelector('.in-page-notification-close')

    titleEl.style.cssText = 'font-weight: 600; margin-bottom: 0.5rem; font-size: 1rem;'
    messageEl.style.cssText =
      'font-size: 0.9rem; line-height: 1.4; color: rgba(245, 245, 247, 0.8);'
    closeEl.style.cssText = `
      position: absolute;
      top: 0.5rem;
      right: 0.5rem;
      background: none;
      border: none;
      color: rgba(245, 245, 247, 0.6);
      cursor: pointer;
      font-size: 1.2rem;
      padding: 0.25rem;
      border-radius: 4px;
      transition: all 0.2s ease;
    `

    document.body.appendChild(notification)

    let closeStarted = false
    let autoCloseTimerId = null

    const closeNotification = () => {
      if (closeStarted) return
      closeStarted = true
      if (autoCloseTimerId !== null) {
        clearTimeout(autoCloseTimerId)
        autoCloseTimerId = null
      }
      notification.style.transform = 'translateX(100%)'
      notification.style.opacity = '0'
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification)
        }
      }, 300)
    }

    closeEl.addEventListener('click', closeNotification)

    closeEl.addEventListener('mouseenter', () => {
      closeEl.style.background = 'rgba(255, 255, 255, 0.1)'
      closeEl.style.color = '#f5f5f7'
    })

    closeEl.addEventListener('mouseleave', () => {
      closeEl.style.background = 'none'
      closeEl.style.color = 'rgba(245, 245, 247, 0.6)'
    })

    notification.style.transform = 'translateX(100%)'
    notification.style.transition = 'all 0.3s ease-out'
    setTimeout(() => {
      notification.style.transform = 'translateX(0)'
    }, 10)

    const timeoutMs = this._getInPageNotificationTimeoutMs(options)
    if (timeoutMs > 0) {
      autoCloseTimerId = setTimeout(closeNotification, timeoutMs)
    }

    return notification
  }

  _collectRecentFallbackEvents(events, cutoffTimestamp, maxEvents) {
    if (!Array.isArray(events)) {
      throw new TypeError('fallback events payload is not an array')
    }

    const kept = []
    for (let i = events.length - 1; i >= 0; i -= 1) {
      if (!(i in events)) continue
      const event = events[i]
      if (event.timestamp > cutoffTimestamp && kept.length < maxEvents) {
        kept.push(event)
      }
    }
    kept.reverse()
    return kept
  }

  recordFallbackEvent(type, data) {

    const event = {
      type,
      data,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href
    }

    try {
      const storageKey = 'ai-intervention-fallback-events'
      const events = JSON.parse(localStorage.getItem(storageKey) || '[]')

      const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000
      const validEvents = this._collectRecentFallbackEvents(events, sevenDaysAgo, 49)

      validEvents.push(event)

      localStorage.setItem(storageKey, JSON.stringify(validEvents))

      this.monitorLocalStorageUsage(storageKey)
    } catch (error) {
      console.warn('Cannot record fallback event:', error)

      this.cleanupLocalStorage()
    }

    if (this.config.debug) {
      console.debug('Fallback event recorded:', event)
    }
  }

  monitorLocalStorageUsage(key) {
    try {
      const data = localStorage.getItem(key)
      if (data) {
        const sizeInBytes = new Blob([data]).size
        const sizeInKB = (sizeInBytes / 1024).toFixed(2)

        if (sizeInBytes > 100 * 1024) {

          console.warn(`localStorage event records are large: ${sizeInKB}KB; consider pruning`)
        }

        if (this.config.debug) {
          console.debug(`localStorage event records size: ${sizeInKB}KB`)
        }
      }
    } catch (error) {
      console.warn('Cannot monitor localStorage usage:', error)
    }
  }

  cleanupLocalStorage() {
    try {
      const storageKey = 'ai-intervention-fallback-events'
      const events = JSON.parse(localStorage.getItem(storageKey) || '[]')

      const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000
      const recentEvents = this._collectRecentFallbackEvents(events, oneDayAgo, 20)

      localStorage.setItem(storageKey, JSON.stringify(recentEvents))
      console.debug(`localStorage pruning complete; kept ${recentEvents.length} events`)
    } catch (error) {
      console.error('localStorage pruning failed:', error)

      try {
        localStorage.removeItem('ai-intervention-fallback-events')
        console.debug('localStorage event records cleared')
      } catch (clearError) {
        console.error('Cannot clear localStorage:', clearError)
      }
    }
  }
}

const notificationManager = new NotificationManager()
