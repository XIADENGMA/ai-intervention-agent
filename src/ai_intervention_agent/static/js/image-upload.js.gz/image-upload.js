let selectedImages = [];

function isImageItemActive(imageItem) {
  if (!imageItem) return false;
  return selectedImages.some(
    (img) => img === imageItem && img.id === imageItem.id,
  );
}

function dataTransferHasFiles(event) {
  const types =
    event && event.dataTransfer && event.dataTransfer.types
      ? event.dataTransfer.types
      : null;
  if (!types) return false;
  if (typeof types.includes === "function") return types.includes("Files");
  if (typeof types.contains === "function") return types.contains("Files");
  return Array.prototype.indexOf.call(types, "Files") !== -1;
}

function forEachClipboardEntry(collection, callback) {
  if (!collection) return;

  const iterator =
    typeof Symbol !== "undefined" ? collection[Symbol.iterator] : null;
  if (typeof iterator === "function") {
    for (const entry of collection) {
      callback(entry);
    }
    return;
  }

  const length = Number(collection.length);
  if (!Number.isFinite(length) || length <= 0) return;
  for (let i = 0; i < length; i += 1) {
    callback(collection[i]);
  }
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function throttle(func, limit) {
  let inThrottle;
  return function (...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

function rafUpdate(callback) {
  if (window.requestAnimationFrame) {
    requestAnimationFrame(callback);
  } else {
    setTimeout(callback, 16);
  }
}

const SUPPORTED_IMAGE_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/gif",
  "image/webp",
  "image/bmp",
];
const MAX_IMAGE_SIZE = 10 * 1024 * 1024;
const MAX_IMAGE_COUNT = 10;
const MAX_IMAGE_DIMENSION = 1920;
const COMPRESS_QUALITY = 0.8;

function validateImageFile(file) {

  if (typeof ValidationUtils !== "undefined") {
    const result = ValidationUtils.validateImageFile(file);
    return result.errors;
  }

  const errors = [];
  if (!file || !file.type) {
    errors.push(t("validation.invalidFile"));
    return errors;
  }
  if (!SUPPORTED_IMAGE_TYPES.includes(file.type)) {
    errors.push(t("validation.unsupportedFormat", { type: file.type }));
  }
  if (file.size > MAX_IMAGE_SIZE) {
    const sizeMB = (file.size / 1024 / 1024).toFixed(2);
    const limitMB = (MAX_IMAGE_SIZE / 1024 / 1024).toFixed(0);
    errors.push(
      t("validation.fileSizeExceeded", { actual: sizeMB, limit: limitMB }),
    );
  }
  if (file.name && file.name.length > 255) {
    errors.push(t("validation.fileNameTooLong"));
  }
  return errors;
}

function sanitizeFileName(fileName) {

  if (typeof ValidationUtils !== "undefined") {
    return ValidationUtils.sanitizeFilename(fileName, 100);
  }

  return fileName
    .replace(/[<>:"/\\|?*]/g, "")
    .replace(/\s+/g, "_")
    .trim()
    .substring(0, 100);
}

const OBJECT_URL_MAX_AGE_MS = 20 * 60 * 1000;
const OBJECT_URL_CLEANUP_INTERVAL_MS = 5 * 60 * 1000;

let objectURLs = new Set();
let urlToFileMap = new WeakMap();
let urlCreationTime = new Map();
let objectURLCleanupIntervalId = null;
let objectURLLifecycleListenersInstalled = false;

function shouldRunObjectURLCleanupInterval() {
  if (typeof setInterval !== "function") return false;
  if (objectURLs.size === 0) return false;
  if (typeof document !== "undefined" && document.hidden === true) {
    return false;
  }
  return true;
}

function stopPeriodicCleanup() {
  if (objectURLCleanupIntervalId === null) return false;
  if (typeof clearInterval === "function") {
    clearInterval(objectURLCleanupIntervalId);
  }
  objectURLCleanupIntervalId = null;
  return true;
}

function stopPeriodicCleanupIfIdle() {
  if (objectURLs.size === 0) {
    stopPeriodicCleanup();
  }
}

function createObjectURL(file) {
  try {
    const url = URL.createObjectURL(file);
    objectURLs.add(url);
    urlToFileMap.set(file, url);
    urlCreationTime.set(url, Date.now());
    startPeriodicCleanup();

    return url;
  } catch (error) {
    console.error("createObjectURL failed:", error);
    return null;
  }
}

function revokeObjectURL(url) {
  if (!url) return;

  try {
    if (objectURLs.has(url)) {
      URL.revokeObjectURL(url);
      objectURLs.delete(url);
      urlCreationTime.delete(url);
      stopPeriodicCleanupIfIdle();
      console.debug(`Revoked object URL: ${url}`);
    }
  } catch (error) {
    console.error("Revoke object URL failed:", error);
  }
}

function cleanupAllObjectURLs() {
  console.debug(`Cleaning up ${objectURLs.size} object URLs`);
  const startTime = performance.now();

  for (const url of objectURLs) {
    try {
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(`Revoke URL failed: ${url}`, error);
    }
  }

  objectURLs.clear();
  urlCreationTime.clear();
  stopPeriodicCleanup();

  const endTime = performance.now();
  console.debug(
    `Object URL cleanup done in ${(endTime - startTime).toFixed(2)}ms`,
  );
}

function cleanupExpiredObjectURLs(now = Date.now()) {
  const expiredUrls = [];

  for (const [url, creationTime] of urlCreationTime) {
    if (now - creationTime > OBJECT_URL_MAX_AGE_MS) {
      expiredUrls.push(url);
    }
  }

  if (expiredUrls.length > 0) {
    console.debug(`Periodic cleanup: ${expiredUrls.length} expired object URLs`);
    const expiredUrlCount = expiredUrls.length;
    for (let index = 0; index < expiredUrlCount; index += 1) {
      revokeObjectURL(expiredUrls[index]);
    }
  }

  stopPeriodicCleanupIfIdle();
  return expiredUrls.length;
}

function startPeriodicCleanup() {
  if (objectURLCleanupIntervalId !== null) return objectURLCleanupIntervalId;
  if (!shouldRunObjectURLCleanupInterval()) return null;

  objectURLCleanupIntervalId = setInterval(() => {
    cleanupExpiredObjectURLs();
  }, OBJECT_URL_CLEANUP_INTERVAL_MS);
  return objectURLCleanupIntervalId;
}

function syncObjectURLCleanupWithVisibility() {
  if (typeof document !== "undefined" && document.hidden === true) {
    stopPeriodicCleanup();
    return;
  }
  cleanupExpiredObjectURLs();
  startPeriodicCleanup();
}

function setupObjectURLCleanupLifecycle() {
  if (objectURLLifecycleListenersInstalled) return false;
  objectURLLifecycleListenersInstalled = true;

  if (
    typeof document !== "undefined" &&
    typeof document.addEventListener === "function"
  ) {
    document.addEventListener(
      "visibilitychange",
      syncObjectURLCleanupWithVisibility,
    );
  }

  if (
    typeof window !== "undefined" &&
    typeof window.addEventListener === "function"
  ) {
    window.addEventListener("pageshow", syncObjectURLCleanupWithVisibility);
  }

  return true;
}

function _loadImageViaObjectURL(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = createObjectURL(file);
    if (!url) {
      reject(new Error("createObjectURL failed"));
      return;
    }
    img.onload = () => {
      resolve({
        kind: "img",
        image: img,
        width: img.naturalWidth || img.width || 0,
        height: img.naturalHeight || img.height || 0,
        cleanup: () => revokeObjectURL(url),
      });
    };
    img.onerror = () => {
      revokeObjectURL(url);
      reject(new Error("image decode failed"));
    };
    img.src = url;
  });
}

async function decodeImageSource(file) {

  if (typeof createImageBitmap === "function") {
    try {
      const bmp = await createImageBitmap(file);
      return {
        kind: "bitmap",
        image: bmp,
        width: bmp.width,
        height: bmp.height,
        cleanup: () => {
          try {
            bmp.close();
          } catch (_) {

          }
        },
      };
    } catch (_) {

    }
  }
  return _loadImageViaObjectURL(file);
}

async function compressImage(file) {

  if (file.type === "image/svg+xml" || file.type === "image/gif") {
    return file;
  }

  const MAX_RETURN_BYTES = 2 * 1024 * 1024;
  const forceCompress = file.size > MAX_RETURN_BYTES;

  const isLargeFile = file.size > 5 * 1024 * 1024;

  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d", {
    alpha: file.type === "image/png",
    willReadFrequently: false,
  });
  if (!ctx) {
    return file;
  }

  let decoded;
  try {
    decoded = await decodeImageSource(file);
  } catch (_) {

    return file;
  }

  return new Promise((resolve) => {

    let cleaned = false;
    const safeResolve = (val) => {
      if (!cleaned) {
        cleaned = true;
        try {
          decoded.cleanup();
        } catch (_) {

        }
      }
      resolve(val);
    };

    let width = decoded.width || 0;
    let height = decoded.height || 0;
    if (!width || !height) {

      safeResolve(file);
      return;
    }

    const originalArea = width * height;

    let maxDimension = MAX_IMAGE_DIMENSION;
    if (forceCompress || isLargeFile || originalArea > 4000000) {

      maxDimension = Math.min(MAX_IMAGE_DIMENSION, 1200);
    }

    if (width > maxDimension || height > maxDimension) {
      const ratio = Math.min(maxDimension / width, maxDimension / height);
      width = Math.floor(width * ratio);
      height = Math.floor(height * ratio);
    }

    let currentWidth = width;
    let currentHeight = height;

    canvas.width = currentWidth;
    canvas.height = currentHeight;

    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    let quality = COMPRESS_QUALITY;
    if (isLargeFile) {
      quality = Math.max(0.6, COMPRESS_QUALITY - 0.2);
    }
    if (forceCompress) {
      quality = Math.min(quality, 0.75);
    }

    const mimeCandidates = [];
    if (file.type === "image/png") {
      if (forceCompress || isLargeFile || originalArea > 4000000) {
        mimeCandidates.push("image/webp", "image/jpeg");
      } else {
        mimeCandidates.push("image/png");
      }
    } else if (file.type === "image/webp") {
      mimeCandidates.push("image/webp", "image/jpeg");
    } else {
      if (forceCompress) {
        mimeCandidates.push("image/webp", "image/jpeg");
      } else {
        mimeCandidates.push("image/jpeg");
      }
    }

    const getExtensionForMime = (mimeType) => {
      if (mimeType === "image/png") return ".png";
      if (mimeType === "image/webp") return ".webp";
      if (mimeType === "image/jpeg") return ".jpg";
      return null;
    };

    const replaceExtension = (filename, newExt) => {
      if (!filename || !newExt) return filename;
      const safeName = sanitizeFileName(filename);
      const withoutExt = safeName.replace(/\.[^/.]+$/, "");
      return `${withoutExt}${newExt}`;
    };

    const logCompression = (blob, finalName) => {
      try {
        const ratio = ((1 - blob.size / file.size) * 100).toFixed(1);
        console.debug(
          `Image compression: ${file.name} ${(file.size / 1024).toFixed(2)}KB → ${(
            blob.size / 1024
          ).toFixed(2)}KB (ratio: ${ratio}%) out: ${finalName}`,
        );
      } catch (_) {

      }
    };

    let attempt = 0;
    const MAX_ATTEMPTS = 8;

    const tryToBlob = (mimeIndex) => {
      const outType = mimeCandidates[mimeIndex];
      if (!outType) {
        safeResolve(file);
        return;
      }

      canvas.toBlob(
        (blob) => {
          if (!blob) return tryToBlob(mimeIndex + 1);

          if (!blob.type) return tryToBlob(mimeIndex + 1);

          const finalMimeType = blob.type || outType;
          const ext = getExtensionForMime(finalMimeType);
          const finalName = ext ? replaceExtension(file.name, ext) : file.name;

          const compressedFile = new File([blob], finalName, {
            type: finalMimeType,
            lastModified: file.lastModified,
          });

          if (!forceCompress) {
            if (blob.size < file.size) {
              logCompression(blob, finalName);
              safeResolve(compressedFile);
            } else {
              safeResolve(file);
            }
            return;
          }

          if (blob.size <= MAX_RETURN_BYTES) {
            logCompression(blob, finalName);
            safeResolve(compressedFile);
            return;
          }

          attempt++;
          if (attempt >= MAX_ATTEMPTS) {
            console.warn(
              `Image compression: max attempts reached but still above ${(
                MAX_RETURN_BYTES /
                1024 /
                1024
              ).toFixed(1)}MB; returning current compressed version`,
            );
            logCompression(blob, finalName);
            safeResolve(compressedFile);
            return;
          }

          if (quality > 0.55) {
            quality = Math.max(0.55, quality - 0.1);
            return tryToBlob(0);
          }

          const nextWidth = Math.max(320, Math.floor(currentWidth * 0.85));
          const nextHeight = Math.max(320, Math.floor(currentHeight * 0.85));
          if (nextWidth === currentWidth && nextHeight === currentHeight) {
            logCompression(blob, finalName);
            safeResolve(compressedFile);
            return;
          }

          currentWidth = nextWidth;
          currentHeight = nextHeight;
          canvas.width = currentWidth;
          canvas.height = currentHeight;
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "high";

          rafUpdate(() => {
            ctx.drawImage(decoded.image, 0, 0, currentWidth, currentHeight);
            tryToBlob(0);
          });
        },
        outType,
        quality,
      );
    };

    rafUpdate(() => {
      ctx.drawImage(decoded.image, 0, 0, currentWidth, currentHeight);
      tryToBlob(0);
    });
  });
}

async function addImageToList(file) {

  if (selectedImages.length >= MAX_IMAGE_COUNT) {
    showStatus(t("status.maxImages", { count: MAX_IMAGE_COUNT }), "error");
    return false;
  }

  const errors = validateImageFile(file);
  if (errors.length > 0) {
    showStatus(errors.join("; "), "error");
    return false;
  }

  const isDuplicate = selectedImages.some(
    (img) =>
      img.name === file.name &&
      img.size === file.size &&
      img.lastModified === file.lastModified,
  );
  if (isDuplicate) {
    showStatus(t("status.imageDuplicate"), "error");
    return false;
  }

  const imageId = Date.now() + Math.random();
  let imageItem = null;

  try {

    const timestamp = Date.now();
    imageItem = {
      id: imageId,
      file: file,
      name: file.name,
      size: file.size,
      base64: null,
      timestamp: timestamp,
      lastModified: file.lastModified,
    };

    selectedImages.push(imageItem);
    renderImagePreview(imageItem, true);
    updateImageCounter();

    const processedFile = await compressImage(file);
    if (!isImageItemActive(imageItem)) {
      return false;
    }

    imageItem.file = processedFile;
    imageItem.size = processedFile.size;

    const previewUrl = createObjectURL(processedFile);
    if (previewUrl) {
      imageItem.previewUrl = previewUrl;
    } else {
      throw new Error("createObjectURL failed for preview");
    }

    renderImagePreview(imageItem, false);

    console.debug(
      "Image added:",
      file.name,
      `(${(imageItem.size / 1024).toFixed(2)}KB)`,
    );
    return true;
  } catch (error) {
    if (!isImageItemActive(imageItem)) {
      return false;
    }

    console.error("Image processing failed:", error);
    showStatus(t("status.imageError", { reason: error.message }), "error");

    let failureRemoval = null;
    try {
      failureRemoval = prepareImageRemoval(imageId, true);
      const failed = failureRemoval ? failureRemoval.imageToRemove : null;
      if (
        failed &&
        failed.previewUrl &&
        failed.previewUrl.startsWith("blob:")
      ) {
        revokeObjectURL(failed.previewUrl);
      }
    } catch (_) {

    }

    if (failureRemoval) selectedImages = failureRemoval.nextImages;
    const previewElement = document.getElementById(`preview-${imageId}`);
    if (previewElement) {
      previewElement.remove();
    }
    updateImageCounter();
    updateImagePreviewVisibility();
    return false;
  }
}

function renderImagePreview(imageItem, isLoading = false) {
  rafUpdate(() => {
    if (!isImageItemActive(imageItem)) {
      return;
    }

    const previewContainer = document.getElementById("image-previews");
    if (!previewContainer) {
      console.error(
        "Image preview container #image-previews not found; cannot render",
      );
      return;
    }
    let previewElement = document.getElementById(`preview-${imageItem.id}`);

    if (!previewElement) {
      previewElement = document.createElement("div");
      previewElement.id = `preview-${imageItem.id}`;
      previewElement.className = "image-preview-item";
      previewContainer.appendChild(previewElement);
    }

    const replacePreviewChildren = (container, built) => {
      const fragment = document.createDocumentFragment();
      while (built.firstChild) {
        fragment.appendChild(built.firstChild);
      }
      DOMSecurity.replaceContent(container, fragment);
    };

    const newPreviewElement = DOMSecurity.createImagePreview(
      imageItem,
      isLoading,
    );
    replacePreviewChildren(previewElement, newPreviewElement);

    if (!isLoading && imageItem.previewUrl) {

      const img = new Image();
      img.onload = () => {
        rafUpdate(() => {
          if (!isImageItemActive(imageItem)) {
            return;
          }
          const currentPreviewElement = document.getElementById(
            `preview-${imageItem.id}`,
          );
          if (!currentPreviewElement) {
            return;
          }
          const updatedPreviewElement = DOMSecurity.createImagePreview(
            imageItem,
            false,
          );
          replacePreviewChildren(currentPreviewElement, updatedPreviewElement);
        });
      };
      img.src = imageItem.previewUrl;
    }
  });
}

function sanitizeText(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function prepareImageRemoval(imageId, strictId = false) {
  let nextImages = null;
  let imageToRemove = null;
  for (let i = 0; i < selectedImages.length; i += 1) {
    const image = selectedImages[i];
    const matches = strictId ? image.id === imageId : image.id == imageId;
    if (matches) {
      if (imageToRemove === null) imageToRemove = image;
      if (nextImages === null) nextImages = selectedImages.slice(0, i);
    } else if (nextImages !== null) {
      nextImages.push(image);
    }
  }
  if (nextImages === null) return null;
  return { imageToRemove, nextImages };
}

function removeImage(imageId) {

  const removal = prepareImageRemoval(imageId);
  const imageToRemove = removal ? removal.imageToRemove : null;
  if (
    imageToRemove &&
    imageToRemove.previewUrl &&
    imageToRemove.previewUrl.startsWith("blob:")
  ) {
    revokeObjectURL(imageToRemove.previewUrl);
  }

  if (removal) selectedImages = removal.nextImages;
  const previewElement = document.getElementById(`preview-${imageId}`);
  if (previewElement) {
    previewElement.remove();
  }
  updateImageCounter();
  updateImagePreviewVisibility();
}

function clearAllImages() {

  const selectedImageCount = selectedImages.length;
  for (let index = 0; index < selectedImageCount; index += 1) {
    if (!(index in selectedImages)) continue;
    const img = selectedImages[index];
    if (img.previewUrl && img.previewUrl.startsWith("blob:")) {
      revokeObjectURL(img.previewUrl);
    }
  }

  selectedImages = [];
  const previewContainer = document.getElementById("image-previews");

  DOMSecurity.clearContent(previewContainer);
  updateImageCounter();
  updateImagePreviewVisibility();

  if (window.gc && typeof window.gc === "function") {
    setTimeout(() => window.gc(), 1000);
  }

  console.debug("All images cleared; memory released");
}

function cleanupOnPageExit(event) {
  if (event && event.persisted === true) {
    stopPeriodicCleanup();
    return;
  }

  try {
    if (hourglassAnimation) {
      hourglassAnimation.destroy();
      hourglassAnimation = null;
    }
  } catch (e) {

  }
  try {
    const container = document.getElementById("hourglass-lottie");
    if (container) container.textContent = "";
  } catch (e) {

  }

  cleanupAllObjectURLs();
  clearAllImages();
}

setupObjectURLCleanupLifecycle();

window.addEventListener("pagehide", cleanupOnPageExit);

function updateImageCounter() {
  const countElement = document.getElementById("image-count");
  if (countElement) {
    countElement.textContent = selectedImages.length;
  }
}

function updateImagePreviewVisibility() {
  const container = document.getElementById("image-preview-container");
  if (!container) return;

  if (selectedImages.length > 0) {
    container.classList.remove("hidden");
    container.classList.add("visible");
  } else {
    container.classList.add("hidden");
    container.classList.remove("visible");
  }
}

async function handleFileUpload(files) {
  const fileCount = files.length;
  const maxConcurrent = 3;
  let processed = 0;
  let successful = 0;

  if (fileCount > 1) {
    showStatus(
      t("status.processingBatch", { count: fileCount }),
      "info",
    );
  }

  for (let i = 0; i < fileCount; i += maxConcurrent) {
    const batchEnd = Math.min(i + maxConcurrent, fileCount);
    const batchPromises = [];

    for (let j = i; j < batchEnd; j += 1) {
      const file = files[j];
      batchPromises.push(
        (async () => {
          try {
            const success = await addImageToList(file);
            if (success) successful++;
            processed++;

            if (fileCount > 1) {
              showStatus(
                t("status.processProgress", {
                  done: processed,
                  total: fileCount,
                }),
                "info",
              );
            }

            return success;
          } catch (error) {
            console.error("File processing failed:", file.name, error);
            processed++;
            return false;
          }
        })(),
      );
    }

    await Promise.all(batchPromises);

    if (batchEnd < fileCount) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }

  updateImagePreviewVisibility();

  if (fileCount > 1) {
    showStatus(
      t("status.batchComplete", { successful, total: fileCount }),
      successful > 0 ? "success" : "error",
    );
  } else if (fileCount === 1) {
    const file = files[0];
    const filename = file && file.name ? file.name : "";
    showStatus(
      successful > 0
        ? t("status.fileProcessSuccess", { filename })
        : t("status.fileProcessFailed", { filename, reason: "" }),
      successful > 0 ? "success" : "error",
    );
  }
}

function initializeDragAndDrop() {
  if (typeof window.__aiInterventionAgentDragDropCleanup === "function") {
    try {
      window.__aiInterventionAgentDragDropCleanup();
    } catch (_) {

    }
  }

  const textarea = document.getElementById("feedback-text");
  const dragOverlay = document.getElementById("drag-overlay");

  if (!textarea || !dragOverlay) {
    const missing = [];
    if (!textarea) missing.push("#feedback-text");
    if (!dragOverlay) missing.push("#drag-overlay");
    console.debug(
      `Image drag-and-drop skipped: ${missing.join(", ")} unavailable`,
    );
    return false;
  }

  let dragCounter = 0;
  let dragTimer = null;
  const listenerEntries = [];

  const addDocumentListener = (type, handler, options) => {
    document.addEventListener(type, handler, options);
    listenerEntries.push({ type, handler, options });
  };

  const preventDefaultListenerOptions = { passive: false };
  addDocumentListener("dragenter", preventDefaults, preventDefaultListenerOptions);
  addDocumentListener("dragover", preventDefaults, preventDefaultListenerOptions);
  addDocumentListener("dragleave", preventDefaults, preventDefaultListenerOptions);
  addDocumentListener("drop", preventDefaults, preventDefaultListenerOptions);

  function preventDefaults(e) {
    if (!dataTransferHasFiles(e)) return;
    e.preventDefault();
    e.stopPropagation();
  }

  const throttledFileDragEnter = throttle((e) => {
    dragCounter++;
    rafUpdate(() => {
      dragOverlay.classList.remove("hidden");
      textarea.classList.add("textarea-drag-over");
    });
  }, 100);

  const throttledFileDragLeave = throttle((e) => {
    dragCounter--;
    if (dragCounter <= 0) {
      dragCounter = 0;
      clearTimeout(dragTimer);
      dragTimer = setTimeout(() => {
        rafUpdate(() => {
          dragOverlay.classList.add("hidden");
          textarea.classList.remove("textarea-drag-over");
        });
      }, 100);
    }
  }, 50);

  const throttledFileDragOver = throttle((e) => {
    e.dataTransfer.dropEffect = "copy";
  }, 50);

  const dragEnterHandler = (e) => {
    if (!dataTransferHasFiles(e)) return;
    throttledFileDragEnter(e);
  };

  const dragLeaveHandler = (e) => {
    if (!dataTransferHasFiles(e)) return;
    throttledFileDragLeave(e);
  };

  const dragOverHandler = (e) => {
    if (!dataTransferHasFiles(e)) return;
    throttledFileDragOver(e);
  };

  const dropHandler = function (e) {
    dragCounter = 0;
    clearTimeout(dragTimer);

    rafUpdate(() => {
      dragOverlay.classList.add("hidden");
      textarea.classList.remove("textarea-drag-over");
    });

    const files = e && e.dataTransfer ? e.dataTransfer.files : null;
    if (!files || files.length === 0) return;

    const totalFiles = selectedImages.length + files.length;
    if (totalFiles > MAX_IMAGE_COUNT) {
      showStatus(t("status.maxImages", { count: MAX_IMAGE_COUNT }), "error");
      return;
    }

    handleFileUpload(files);
  };

  addDocumentListener("dragenter", dragEnterHandler);
  addDocumentListener("dragleave", dragLeaveHandler);
  addDocumentListener("dragover", dragOverHandler);
  addDocumentListener("drop", dropHandler);

  function cleanupDragAndDrop() {
    const listenerEntryCount = listenerEntries.length;
    for (let index = 0; index < listenerEntryCount; index += 1) {
      if (!(index in listenerEntries)) continue;
      const entry = listenerEntries[index];
      document.removeEventListener(entry.type, entry.handler, entry.options);
    }
    clearTimeout(dragTimer);
    dragCounter = 0;
    dragOverlay.classList.add("hidden");
    textarea.classList.remove("textarea-drag-over");
    if (window.__aiInterventionAgentDragDropCleanup === cleanupDragAndDrop) {
      window.__aiInterventionAgentDragDropCleanup = null;
    }
  }

  window.__aiInterventionAgentDragDropCleanup = cleanupDragAndDrop;

  return true;
}

function initializePasteFunction() {
  const textarea = document.getElementById("feedback-text");

  const dataUriToFile = (dataUri) => {
    try {
      const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(dataUri);
      if (!match) return null;

      const mime = match[1];
      const base64 = match[2].replace(/\s+/g, "");

      if (base64.length > 15 * 1024 * 1024) {
        console.warn("Clipboard data URI too large; skipped");
        return null;
      }

      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      let ext = "png";
      if (mime === "image/jpeg") ext = "jpg";
      else if (mime === "image/webp") ext = "webp";
      else if (mime === "image/png") ext = "png";
      const filename = `pasted-image-${Date.now()}.${ext}`;
      return new File([bytes], filename, {
        type: mime,
        lastModified: Date.now(),
      });
    } catch (err) {
      console.warn("Failed to parse clipboard data URI image:", err);
      return null;
    }
  };

  try {
    if (window.__aiInterventionAgentPasteHandler) {
      document.removeEventListener(
        "paste",
        window.__aiInterventionAgentPasteHandler,
      );
    }
  } catch (_) {

  }

  const pasteHandler = async function (e) {
    const clipboardData = e.clipboardData;
    if (!clipboardData) return;

    if (!textarea || document.activeElement !== textarea) return;

    const filesToAdd = [];
    let matches = [];

    forEachClipboardEntry(clipboardData.items, (item) => {
      if (!item) return;
      if (item.kind !== "file") return;
      if (!item.type || !item.type.startsWith("image/")) return;

      const file = item.getAsFile();
      if (file) filesToAdd.push(file);
    });

    if (filesToAdd.length === 0) {
      forEachClipboardEntry(clipboardData.files, (file) => {
        if (file && file.type && file.type.startsWith("image/")) {
          filesToAdd.push(file);
        }
      });
    }

    if (filesToAdd.length === 0) {
      const html = clipboardData.getData("text/html") || "";
      const text =
        clipboardData.getData("text/plain") ||
        clipboardData.getData("text") ||
        "";
      const combined = `${html}\n${text}`;

      const dataUriRegex =
        /data:image\/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=\s]+/g;
      matches = combined.match(dataUriRegex) || [];

      for (const dataUri of matches.slice(0, MAX_IMAGE_COUNT)) {
        const file = dataUriToFile(dataUri);
        if (file) filesToAdd.push(file);
      }
    }

    if (filesToAdd.length === 0) return;

    const rawPastedText =
      clipboardData.getData("text/plain") ||
      clipboardData.getData("text") ||
      "";
    const pastedText = rawPastedText.trim();
    const dataUriText = pastedText.replace(/\s+/g, "");
    const dataUriOnly =
      matches.length > 0 &&
      /^data:image\/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+$/i.test(dataUriText);

    if (!pastedText || dataUriOnly) {
      e.preventDefault();
    }

    let added = 0;
    for (const file of filesToAdd) {
      const ok = await addImageToList(file);
      if (ok) added++;
    }

    updateImagePreviewVisibility();
    if (added > 0) {
      showStatus(t("status.clipboardAdded", { count: added }), "success");
    }
  };

  window.__aiInterventionAgentPasteHandler = pasteHandler;
  document.addEventListener("paste", pasteHandler);
}

function initializeFileSelection() {
  const fileInput = document.getElementById("file-upload-input");
  const uploadBtn = document.getElementById("upload-image-btn");

  if (!fileInput || !uploadBtn) {
    console.debug(
      "Image file selection skipped: upload controls unavailable",
    );
    return false;
  }

  if (!uploadBtn.dataset.aiiaImageUploadWired) {
    uploadBtn.dataset.aiiaImageUploadWired = "1";
    uploadBtn.addEventListener("click", () => {
      if (typeof fileInput.click === "function") {
        fileInput.click();
      }
    });
  }

  if (!fileInput.dataset.aiiaImageUploadWired) {
    fileInput.dataset.aiiaImageUploadWired = "1";
    fileInput.addEventListener("change", (e) => {
      const target = e && e.target ? e.target : fileInput;
      if (target.files && target.files.length > 0) {
        handleFileUpload(target.files);

        target.value = "";
      }
    });
  }

  return true;
}

let _imageModalPreviouslyFocusedElement = null;
let _imageModalKeydownHandlersAttached = false;

function _imageModalBackgroundClickHandler(e) {
  const modal = document.getElementById("image-modal");
  if (e.target === modal) {
    closeImageModal();
  }
}

function _imageModalTabTrapHandler(event) {

  if (event.key !== "Tab") return;
  const closeBtn = document.querySelector(".image-modal-close");
  if (!closeBtn) return;
  event.preventDefault();
  try {
    closeBtn.focus();
  } catch (_e) {

  }
}

function _initImageModalOnce() {

  const modal = document.getElementById("image-modal");
  if (!modal || modal.dataset.aiiaInited === "1") return;
  modal.addEventListener("click", _imageModalBackgroundClickHandler);
  modal.dataset.aiiaInited = "1";
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", _initImageModalOnce);
} else {
  _initImageModalOnce();
}

function _attachImageModalKeydownHandlers() {
  if (_imageModalKeydownHandlersAttached) return;
  document.addEventListener("keydown", handleModalKeydown);
  document.addEventListener("keydown", _imageModalTabTrapHandler);
  _imageModalKeydownHandlersAttached = true;
}

function _detachImageModalKeydownHandlers() {
  if (!_imageModalKeydownHandlersAttached) return;
  document.removeEventListener("keydown", handleModalKeydown);
  document.removeEventListener("keydown", _imageModalTabTrapHandler);
  _imageModalKeydownHandlersAttached = false;
}

function _getImageModalPartsForOpen() {
  const modal = document.getElementById("image-modal");
  const modalImage = document.getElementById("modal-image");
  const modalInfo = document.getElementById("modal-info");

  if (!modal || !modalImage || !modalInfo) {
    const missing = [];
    if (!modal) missing.push("#image-modal");
    if (!modalImage) missing.push("#modal-image");
    if (!modalInfo) missing.push("#modal-info");
    console.debug(`Image modal open skipped: ${missing.join(", ")} unavailable`);
    return null;
  }

  return { modal, modalImage, modalInfo };
}

function openImageModal(base64, name, size) {
  const parts = _getImageModalPartsForOpen();
  if (!parts) return false;

  const { modal, modalImage, modalInfo } = parts;
  const wasAlreadyOpen = modal.classList.contains("show");

  modalImage.src = base64;
  modalImage.alt = name;
  const _formatNum =
    (window.AIIA_I18N && window.AIIA_I18N.formatNumber) ||
    function (n) {
      return Number(n).toFixed(2);
    };
  modalInfo.textContent = t("status.sizeLabelKB", {
    name: name,
    size: _formatNum(size / 1024, { maximumFractionDigits: 2 }),
  });

  if (!wasAlreadyOpen) {
    _imageModalPreviouslyFocusedElement = document.activeElement;
  }

  modal.removeAttribute("hidden");
  modal.classList.add("show");

  _attachImageModalKeydownHandlers();

  const closeBtn = modal.querySelector(".image-modal-close");
  if (!wasAlreadyOpen && closeBtn) {
    try {
      closeBtn.focus();
    } catch (_e) {

    }
  }

  return true;
}

function closeImageModal() {
  const modal = document.getElementById("image-modal");
  if (modal) {
    modal.classList.remove("show");

    modal.setAttribute("hidden", "");
  } else {
    console.debug("Image modal close skipped: #image-modal unavailable");
  }

  _detachImageModalKeydownHandlers();

  if (
    _imageModalPreviouslyFocusedElement &&
    document.contains(_imageModalPreviouslyFocusedElement)
  ) {
    try {
      _imageModalPreviouslyFocusedElement.focus();
    } catch (_e) {

    }
  }
  _imageModalPreviouslyFocusedElement = null;

  return !!modal;
}

function handleModalKeydown(event) {
  if (event.key === "Escape") {
    closeImageModal();
  }
}

function checkBrowserCompatibility() {
  const features = {
    fileAPI: !!(
      window.File &&
      window.FileReader &&
      window.FileList &&
      window.Blob
    ),
    dragDrop: "ondragstart" in document.createElement("div"),
    canvas: !!document.createElement("canvas").getContext,
    webWorker: !!window.Worker,
    requestAnimationFrame: !!(
      window.requestAnimationFrame || window.webkitRequestAnimationFrame
    ),
    objectURL: !!(window.URL && window.URL.createObjectURL),
    clipboard: !!(navigator.clipboard && navigator.clipboard.read),
  };

  console.debug("Browser compatibility check:", features);

  if (!features.fileAPI) {
    showStatus(t("status.noFileAPI"), "warning");
    return false;
  }

  if (!features.canvas) {
    showStatus(t("status.noCanvas"), "warning");
  }

  return true;
}

function setupFeatureFallbacks() {

  if (!window.requestAnimationFrame) {
    window.requestAnimationFrame =
      window.webkitRequestAnimationFrame ||
      window.mozRequestAnimationFrame ||
      window.oRequestAnimationFrame ||
      window.msRequestAnimationFrame ||
      function (callback) {
        return setTimeout(callback, 16);
      };
  }

  if (!navigator.clipboard) {
    console.warn("Clipboard API unavailable; falling back to manual paste");
  }

  if (!Object.assign) {
    Object.assign = function (target, ...sources) {
      for (let sourceIndex = 0; sourceIndex < sources.length; sourceIndex += 1) {
        const source = sources[sourceIndex];
        if (source) {
          for (const key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              target[key] = source[key];
            }
          }
        }
      }
      return target;
    };
  }
}

function initializeImageFeatures() {

  if (!checkBrowserCompatibility()) {
    console.error("Browser compatibility check failed");
    return;
  }

  setupFeatureFallbacks();

  try {
    initializeDragAndDrop();
    initializePasteFunction();
    initializeFileSelection();

    const clearBtn = document.getElementById("clear-all-images-btn");
    if (clearBtn && !clearBtn.dataset.aiiaImageUploadWired) {
      clearBtn.dataset.aiiaImageUploadWired = "1";
      clearBtn.addEventListener("click", clearAllImages);
    }

    console.debug("Image features initialized");
  } catch (error) {
    console.error("Image features init failed:", error);
    showStatus(t("status.imageInitFailed"), "error");
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    OBJECT_URL_MAX_AGE_MS,
    OBJECT_URL_CLEANUP_INTERVAL_MS,
    createObjectURL,
    revokeObjectURL,
    cleanupAllObjectURLs,
    cleanupExpiredObjectURLs,
    startPeriodicCleanup,
    stopPeriodicCleanup,
    setupObjectURLCleanupLifecycle,
    _getObjectURLLifecycleState: () => ({
      size: objectURLs.size,
      cleanupIntervalId: objectURLCleanupIntervalId,
      lifecycleListenersInstalled: objectURLLifecycleListenersInstalled,
      trackedUrls: Array.from(objectURLs),
      creationTimes: Array.from(urlCreationTime.entries()),
    }),
  };
}
