;(function () {

  var DEFAULT_LANG = 'en'
  var currentLang = DEFAULT_LANG
  var locales = {}

  var _INTL_LRU_MAX = 50
  var _PLURAL_LRU_MAX = 16
  var _pluralRulesCache = new Map()

  var _pluralRulesOrdinalCache = new Map()
  var _intlCache = {
    NumberFormat: new Map(),
    DateTimeFormat: new Map(),
    RelativeTimeFormat: new Map(),
    ListFormat: new Map()
  }

  var _FSI = '\u2068'
  var _PDI = '\u2069'

  var _ICU_COMPILE_LRU_MAX = 256
  var _icuCompileCache = new Map()

  function _touchLru(map, key, value, max) {
    if (map.has(key)) map.delete(key)
    map.set(key, value)
    while (map.size > max) {
      var firstKey = map.keys().next().value
      if (firstKey === undefined) break
      map.delete(firstKey)
    }
  }

  function _getPluralRules(lang) {
    if (typeof Intl === 'undefined' || typeof Intl.PluralRules !== 'function') {
      return null
    }
    if (_pluralRulesCache.has(lang)) {
      var hit = _pluralRulesCache.get(lang)
      _pluralRulesCache.delete(lang)
      _pluralRulesCache.set(lang, hit)
      return hit
    }
    var instance
    try {
      instance = new Intl.PluralRules(lang)
    } catch (e) {
      instance = null
    }
    _touchLru(_pluralRulesCache, lang, instance, _PLURAL_LRU_MAX)
    return instance
  }

  function _getPluralRulesOrdinal(lang) {
    if (typeof Intl === 'undefined' || typeof Intl.PluralRules !== 'function') {
      return null
    }
    if (_pluralRulesOrdinalCache.has(lang)) {
      var hit = _pluralRulesOrdinalCache.get(lang)
      _pluralRulesOrdinalCache.delete(lang)
      _pluralRulesOrdinalCache.set(lang, hit)
      return hit
    }
    var instance
    try {
      instance = new Intl.PluralRules(lang, { type: 'ordinal' })
    } catch (e) {
      instance = null
    }
    _touchLru(_pluralRulesOrdinalCache, lang, instance, _PLURAL_LRU_MAX)
    return instance
  }

  function _stableStringify(value) {
    return _stableStringifyInner(value, new WeakSet())
  }

  function _stableStringifyInner(value, seen) {
    if (value === undefined) return undefined
    if (value === null) return 'null'
    var t = typeof value
    if (t === 'bigint') {
      return JSON.stringify(value.toString() + 'n')
    }
    if (t !== 'object') return JSON.stringify(value)
    if (typeof value.toJSON === 'function') {
      var viaToJson
      try {
        viaToJson = value.toJSON()
      } catch (e) {
        viaToJson = undefined
      }
      if (viaToJson !== value) {
        return _stableStringifyInner(viaToJson, seen)
      }
    }
    if (seen.has(value)) {
      var cycleErr = new Error('_stableStringify: circular reference')
      cycleErr.__aiiaCircular = true
      throw cycleErr
    }
    seen.add(value)
    try {
      if (Array.isArray(value)) {
        var arr = []
        for (var i = 0; i < value.length; i++) {
          var el = _stableStringifyInner(value[i], seen)
          arr.push(el === undefined ? 'null' : el)
        }
        return '[' + arr.join(',') + ']'
      }
      var keys = Object.keys(value).sort()
      var parts = []
      for (var j = 0; j < keys.length; j++) {
        var k = keys[j]
        var v = _stableStringifyInner(value[k], seen)
        if (v === undefined) continue
        parts.push(JSON.stringify(k) + ':' + v)
      }
      return '{' + parts.join(',') + '}'
    } finally {
      seen.delete(value)
    }
  }

  function _shapeSignature(opts) {
    if (!opts || typeof opts !== 'object') return ''
    try {
      return Object.keys(opts).sort().join(',')
    } catch (e) {
      return ''
    }
  }

  function _intlKey(lang, opts) {
    try {
      var body = _stableStringify(opts || {})
      return lang + '|' + (body === undefined ? '{}' : body)
    } catch (e) {
      var marker = e && e.__aiiaCircular ? 'cycle' : 'err'
      return lang + '|?' + marker + '|' + _shapeSignature(opts)
    }
  }

  function _getIntl(ctor, lang, opts) {
    if (typeof Intl === 'undefined' || typeof Intl[ctor] !== 'function') return null
    var bucket = _intlCache[ctor]
    if (!bucket) return null
    var key = _intlKey(lang, opts)
    if (bucket.has(key)) {
      var hit = bucket.get(key)
      bucket.delete(key)
      bucket.set(key, hit)
      return hit
    }
    var instance
    try {
      instance = new Intl[ctor](lang, opts || undefined)
    } catch (e) {
      instance = null
    }
    _touchLru(bucket, key, instance, _INTL_LRU_MAX)
    return instance
  }

  function _getNumberFormat(lang) {
    return _getIntl('NumberFormat', lang, undefined)
  }

  var _PUA_BRACE_OPEN = '\uE001'
  var _PUA_BRACE_CLOSE = '\uE002'
  var _PUA_PIPE = '\uE003'
  var _PUA_HASH = '\uE004'
  var _PUA_APOSTROPHE = '\uE005'
  var _PUA_CLEAN_RE = /[\uE001\uE002\uE003\uE004\uE005]/g
  function _puaFor(ch) {
    if (ch === '{') return _PUA_BRACE_OPEN
    if (ch === '}') return _PUA_BRACE_CLOSE
    if (ch === '|') return _PUA_PIPE
    if (ch === '#') return _PUA_HASH
    return ch
  }
  function _icuEscapeApostrophes(str) {
    if (str.indexOf("'") === -1) return str
    var out = ''
    var i = 0
    var n = str.length
    while (i < n) {
      var ch = str.charAt(i)
      if (ch !== "'") {
        out += ch
        i++
        continue
      }
      var next = i + 1 < n ? str.charAt(i + 1) : ''
      if (next === "'") {
        out += _PUA_APOSTROPHE
        i += 2
        continue
      }
      if (next === '{' || next === '}' || next === '|' || next === '#') {

        var j = i + 1
        while (j < n) {
          if (str.charAt(j) === "'") {
            if (j + 1 < n && str.charAt(j + 1) === "'") {
              j += 2
              continue
            }
            break
          }
          j++
        }
        var endIdx = j < n ? j : n
        for (var k = i + 1; k < endIdx; k++) {
          var cc = str.charAt(k)
          if (cc === "'" && k + 1 < endIdx && str.charAt(k + 1) === "'") {
            out += _PUA_APOSTROPHE
            k++
            continue
          }
          out += _puaFor(cc)
        }

        i = endIdx + (j < n ? 1 : 0)
        continue
      }

      out += "'"
      i++
    }
    return out
  }
  function _icuUnescapePua(str) {
    if (!str) return str
    return str.replace(_PUA_CLEAN_RE, function (ch) {
      if (ch === _PUA_BRACE_OPEN) return '{'
      if (ch === _PUA_BRACE_CLOSE) return '}'
      if (ch === _PUA_PIPE) return '|'
      if (ch === _PUA_HASH) return '#'
      return "'"
    })
  }

  function _findIcuBlock(str, from) {
    var i = from || 0
    while (i < str.length) {
      var open = str.indexOf('{', i)
      if (open === -1) return null
      if (str.charAt(open + 1) === '{') {

        var close = str.indexOf('}}', open + 2)
        if (close === -1) return null
        i = close + 2
        continue
      }

      var depth = 1
      var j = open + 1
      while (j < str.length && depth > 0) {
        var ch = str.charAt(j)
        if (ch === '{') depth++
        else if (ch === '}') depth--
        if (depth === 0) break
        j++
      }
      if (depth !== 0) return null
      var body = str.substring(open + 1, j)

      var commaIdx = body.indexOf(',')
      if (commaIdx === -1) {
        i = j + 1
        continue
      }
      var arg = body.substring(0, commaIdx).trim()
      var rest = body.substring(commaIdx + 1).trimStart()
      var kindMatch = rest.match(/^(plural|selectordinal|select)\s*,\s*/)
      if (!kindMatch) {
        i = j + 1
        continue
      }
      var kind = kindMatch[1]
      var optionsStr = rest.substring(kindMatch[0].length)
      return {
        start: open,
        end: j + 1,
        argName: arg,
        kind: kind,
        options: _parseIcuOptions(optionsStr)
      }
    }
    return null
  }

  function _parseIcuOptions(src) {
    var out = {}
    var i = 0
    var n = src.length
    while (i < n) {

      while (i < n && /\s/.test(src.charAt(i))) i++
      if (i >= n) break

      var keyStart = i
      while (i < n && !/\s/.test(src.charAt(i)) && src.charAt(i) !== '{') i++
      var key = src.substring(keyStart, i).trim()
      if (!key) break

      while (i < n && /\s/.test(src.charAt(i))) i++
      if (src.charAt(i) !== '{') break

      var depth = 1
      var bodyStart = i + 1
      i++
      while (i < n && depth > 0) {
        var ch = src.charAt(i)
        if (ch === '{') depth++
        else if (ch === '}') depth--
        if (depth === 0) break
        i++
      }
      if (depth !== 0) break
      out[key] = src.substring(bodyStart, i)
      i++
    }
    return out
  }

  function _selectPluralOption(options, count, lang, ordinal) {

    var exactKey = '=' + String(count)
    if (Object.prototype.hasOwnProperty.call(options, exactKey)) {
      return options[exactKey]
    }
    var rules = ordinal ? _getPluralRulesOrdinal(lang) : _getPluralRules(lang)

    var category
    if (rules) {
      category = rules.select(count)
    } else if (ordinal) {
      category = 'other'
    } else {
      category = count === 1 ? 'one' : 'other'
    }
    if (Object.prototype.hasOwnProperty.call(options, category)) {
      return options[category]
    }
    if (Object.prototype.hasOwnProperty.call(options, 'other')) {
      return options.other
    }
    return ''
  }

  function _selectSelectOption(options, value) {
    var key = String(value)
    if (Object.prototype.hasOwnProperty.call(options, key)) {
      return options[key]
    }
    if (Object.prototype.hasOwnProperty.call(options, 'other')) {
      return options.other
    }
    return ''
  }

  function _formatNumber(value, lang) {
    var nf = _getNumberFormat(lang)
    if (nf) {
      try {
        return nf.format(value)
      } catch (e) {

      }
    }
    return String(value)
  }

  function _interpolateMustache(template, params) {
    if (!params || typeof params !== 'object') return template
    return template.replace(/\{\{(\w+)\}\}/g, function (match, name) {
      if (name === '__proto__' || name === 'constructor' || name === 'prototype') {
        return match
      }
      if (!Object.prototype.hasOwnProperty.call(params, name)) {
        return match
      }
      var value = params[name]
      return value !== undefined ? String(value) : match
    })
  }

  function _compileIcuTemplate(template) {
    if (_icuCompileCache.has(template)) {
      var hit = _icuCompileCache.get(template)
      _icuCompileCache.delete(template)
      _icuCompileCache.set(template, hit)
      return hit
    }
    var blocks = []
    var cursor = 0
    while (true) {
      var block = _findIcuBlock(template, cursor)
      if (!block) break
      blocks.push(block)
      cursor = block.end
    }
    var compiled = { blocks: blocks, trivial: blocks.length === 0 }
    _touchLru(_icuCompileCache, template, compiled, _ICU_COMPILE_LRU_MAX)
    return compiled
  }

  function _renderIcu(template, params, lang) {
    if (!params || typeof params !== 'object') return template

    if (template.indexOf('{') === -1) return template
    var compiled = _compileIcuTemplate(template)
    if (compiled.trivial) return template
    var result = ''
    var cursor = 0
    var blocks = compiled.blocks
    for (var bi = 0; bi < blocks.length; bi++) {
      var block = blocks[bi]
      result += template.substring(cursor, block.start)
      var argValue = params[block.argName]
      var chosen
      if (block.kind === 'plural' || block.kind === 'selectordinal') {
        var n = Number(argValue)
        if (!isFinite(n)) n = 0
        chosen = _selectPluralOption(block.options, n, lang, block.kind === 'selectordinal')

        chosen = _replaceHashAtDepth0(chosen, _formatNumber(n, lang))
      } else {
        chosen = _selectSelectOption(block.options, argValue)
      }

      chosen = _renderIcu(chosen, params, lang)
      chosen = _interpolateMustache(chosen, params)
      result += chosen
      cursor = block.end
    }
    result += template.substring(cursor)
    return result
  }

  function _replaceHashAtDepth0(str, replacement) {
    if (!str || str.indexOf('#') === -1) return str
    var out = ''
    var depth = 0
    for (var i = 0, L = str.length; i < L; i++) {
      var ch = str.charAt(i)
      if (ch === '{') {
        depth++
        out += ch
      } else if (ch === '}') {
        if (depth > 0) depth--
        out += ch
      } else if (ch === '#' && depth === 0) {
        out += replacement
      } else {
        out += ch
      }
    }
    return out
  }

  function detectLang() {
    try {
      if (typeof window !== 'undefined' && window.location && window.location.search) {
        var sp = new URLSearchParams(window.location.search)
        var qp = sp.get('lang')
        if (qp) return normalizeLang(qp)
      }
    } catch (e) {

    }
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        var ls = window.localStorage.getItem('aiia_i18n_lang')
        if (ls) return normalizeLang(ls)
      }
    } catch (e) {

    }
    try {
      if (typeof window !== 'undefined' && window.__AIIA_I18N_LANG) {
        return normalizeLang(String(window.__AIIA_I18N_LANG))
      }
    } catch (e) {

    }
    try {
      if (typeof navigator !== 'undefined' && navigator.language) {
        return normalizeLang(navigator.language)
      }
    } catch (e) {

    }
    return DEFAULT_LANG
  }

  function normalizeLang(raw) {
    var s = String(raw || '')
      .trim()
      .toLowerCase()
    if (s === 'pseudo' || s === 'xx-ac' || s === 'xx') return 'pseudo'

    if (s.indexOf('zh') === 0) {
      if (
        s === 'zh-tw' ||
        s === 'zh-hk' ||
        s === 'zh-mo' ||
        s === 'zh-hant' ||
        s.indexOf('zh-hant-') === 0
      ) {
        return 'zh-TW'
      }
      return 'zh-CN'
    }
    if (s.indexOf('en') === 0) return 'en'
    return DEFAULT_LANG
  }

  function registerLocale(lang, data) {
    if (!lang || !data || typeof data !== 'object') return
    locales[normalizeLang(lang)] = data
  }

  function langToDir(lang) {
    if (/^(ar|fa|he|iw|ps|ur|yi|ug|ckb|ku|dv|sd)(-|$)/i.test(String(lang || ''))) {
      return 'rtl'
    }
    return 'ltr'
  }

  function setLang(lang) {
    currentLang = normalizeLang(lang)
    try {
      var docEl = document.documentElement

      docEl.lang = currentLang
      docEl.dir = langToDir(currentLang)
    } catch (e) {

    }
  }

  function getLang() {
    return currentLang
  }
  function getAvailableLangs() {
    return Object.keys(locales)
  }

  function _resolvePath(key, lang) {
    var dict = locales[lang || currentLang]
    if (!dict) dict = locales[DEFAULT_LANG]
    if (!dict) return { value: undefined, shape: 'missing', nodeType: 'undefined' }
    var parts = String(key).split('.')
    var node = dict
    for (var i = 0; i < parts.length; i++) {
      if (node === null || node === undefined || typeof node !== 'object') {
        return { value: undefined, shape: 'missing', nodeType: typeof node }
      }
      var part = parts[i]
      if (part === '__proto__' || part === 'constructor' || part === 'prototype') {
        return { value: undefined, shape: 'missing', nodeType: 'blocked' }
      }
      if (!Object.prototype.hasOwnProperty.call(node, part)) {
        return { value: undefined, shape: 'missing', nodeType: 'undefined' }
      }
      node = node[part]
    }
    if (typeof node === 'string') return { value: node, shape: 'ok', nodeType: 'string' }
    return { value: undefined, shape: 'non-string', nodeType: node === null ? 'null' : typeof node }
  }

  var _missingKeyHandler = null
  var _strictMissing = false
  var _missingKeyStats = Object.create(null)

  var _nonStringHits = Object.create(null)
  var _NONSTRING_SEP = '\u0001'

  function _reportMissing(key, lang) {
    try {
      _missingKeyStats[key] = (_missingKeyStats[key] || 0) + 1
    } catch (e) {

    }
    if (typeof _missingKeyHandler === 'function') {
      try {
        _missingKeyHandler(key, lang)
      } catch (e) {
        if (_strictMissing) throw e
        try {
          if (typeof console !== 'undefined' && console.warn) {
            console.warn('[i18n] missing-key handler threw:', e)
          }
        } catch (_) {

        }
      }
    } else if (_strictMissing) {
      throw new Error('[i18n] missing key: ' + key + ' (lang=' + lang + ')')
    }
  }

  function setMissingKeyHandler(fn) {
    _missingKeyHandler = typeof fn === 'function' ? fn : null
  }

  function setStrict(on) {
    _strictMissing = !!on
  }

  function getMissingKeyStats() {
    var out = {}
    var keys = Object.keys(_missingKeyStats)
    for (var i = 0; i < keys.length; i++) out[keys[i]] = _missingKeyStats[keys[i]]
    return out
  }

  function resetMissingKeyStats() {
    _missingKeyStats = Object.create(null)
  }

  function _reportNonString(key, lang, nodeType) {
    var bucketKey = (lang == null ? '' : String(lang)) + _NONSTRING_SEP + String(key)
    if (Object.prototype.hasOwnProperty.call(_nonStringHits, bucketKey)) {
      return
    }
    _nonStringHits[bucketKey] = { lang: lang, key: key, type: nodeType }
    if (_strictMissing) {
      throw new Error(
        '[i18n] non-string resolve: ' + key +
        ' (lang=' + lang + ', type=' + nodeType + ')'
      )
    }
    try {
      if (typeof console !== 'undefined' && console.warn) {
        console.warn(
          '[i18n] resolved non-string:',
          key,
          '(lang=' + lang + ', type=' + nodeType + ', hint: try a deeper key)'
        )
      }
    } catch (_) {

    }
  }

  function t(key, params) {
    var detail = _resolvePath(key, currentLang)
    var val = detail.value
    var observed = detail
    if (val === undefined && currentLang !== DEFAULT_LANG) {
      var fallback = _resolvePath(key, DEFAULT_LANG)
      val = fallback.value

      if (observed.shape === 'missing' && fallback.shape !== 'missing') {
        observed = fallback
      }

      if (val === undefined && !locales[DEFAULT_LANG] && _localeBaseUrl) {
        ensureDefaultLocale()
      }
    }
    if (val === undefined) {
      if (observed.shape === 'non-string') {
        _reportNonString(key, currentLang, observed.nodeType)
      } else {
        _reportMissing(key, currentLang)
      }
      return key
    }

    if (params && typeof params === 'object') {
      val = _icuEscapeApostrophes(val)
      val = _renderIcu(val, params, currentLang)
      val = _interpolateMustache(val, params)
      val = _icuUnescapePua(val)
    } else {
      val = _renderIcu(val, params, currentLang)
      val = _interpolateMustache(val, params)
    }
    return val
  }

  function formatNumber(value, options) {
    var f = _getIntl('NumberFormat', currentLang, options)
    if (f) {
      try {
        return f.format(value)
      } catch (e) {

      }
    }
    return String(value)
  }

  function _toDate(value) {
    if (value instanceof Date) return value
    if (typeof value === 'number' || typeof value === 'string') return new Date(value)
    return new Date(NaN)
  }

  function formatDate(value, options) {
    var d = _toDate(value)
    var f = _getIntl('DateTimeFormat', currentLang, options)
    if (f) {
      try {
        return f.format(d)
      } catch (e) {

      }
    }
    try {
      return d.toISOString()
    } catch (e) {
      return String(value)
    }
  }

  function formatRelativeTime(value, unit, options) {
    var n = Number(value)
    if (!isFinite(n)) n = 0
    var f = _getIntl('RelativeTimeFormat', currentLang, options)
    if (f) {
      try {
        return f.format(n, unit)
      } catch (e) {

      }
    }

    return n + ' ' + unit + (Math.abs(n) === 1 ? '' : 's')
  }

  function formatRelativeFromNow(date, options) {
    var target = _toDate(date)
    var diffMs = target.getTime() - Date.now()
    if (!isFinite(diffMs)) return formatRelativeTime(0, 'second', options)
    var absSec = Math.abs(diffMs) / 1000
    var sign = diffMs < 0 ? -1 : 1
    var value, unit
    if (absSec < 45) {
      value = sign * Math.round(absSec)
      unit = 'second'
    } else if (absSec < 2700) {
      value = sign * Math.round(absSec / 60)
      unit = 'minute'
    } else if (absSec < 79200) {
      value = sign * Math.round(absSec / 3600)
      unit = 'hour'
    } else if (absSec < 2246400) {
      value = sign * Math.round(absSec / 86400)
      unit = 'day'
    } else if (absSec < 28512000) {
      value = sign * Math.round(absSec / 2592000)
      unit = 'month'
    } else {
      value = sign * Math.round(absSec / 31536000)
      unit = 'year'
    }
    return formatRelativeTime(value, unit, options)
  }

  function formatList(values, options) {
    if (!values) return ''
    var arr = []
    for (var i = 0; i < values.length; i++) arr.push(String(values[i]))
    var f = _getIntl('ListFormat', currentLang, options)
    if (f) {
      try {
        return f.format(arr)
      } catch (e) {

      }
    }
    if (arr.length === 0) return ''
    if (arr.length === 1) return arr[0]

    var zh = /^zh/i.test(currentLang)
    var sep = zh ? '、' : ', '
    var conj = zh ? '和' : ' and ' // aiia:i18n-allow-cjk
    return arr.slice(0, -1).join(sep) + conj + arr[arr.length - 1]
  }

  var ATTR_BINDINGS = [
    { dataAttr: 'data-i18n-title', target: 'title', setter: 'property' },
    { dataAttr: 'data-i18n-placeholder', target: 'placeholder', setter: 'property' },
    { dataAttr: 'data-i18n-alt', target: 'alt', setter: 'property' },
    { dataAttr: 'data-i18n-aria-label', target: 'aria-label', setter: 'attribute' },
    { dataAttr: 'data-i18n-value', target: 'value', setter: 'property' }
  ]

  function translateDOM(root) {

    var scope = root || (typeof document !== 'undefined' ? document : null)
    if (!scope || typeof scope.querySelectorAll !== 'function') return
    var els = scope.querySelectorAll('[data-i18n]')
    for (var i = 0; i < els.length; i++) {
      var el = els[i]
      var key = el.getAttribute('data-i18n')
      if (!key) continue
      var val = t(key)
      if (val !== key) el.textContent = val
    }

    var htmlEls = scope.querySelectorAll('[data-i18n-html]')
    for (var h = 0; h < htmlEls.length; h++) {
      var hEl = htmlEls[h]
      var hKey = hEl.getAttribute('data-i18n-html')
      if (!hKey) continue
      var hVal = t(hKey)
      // AIIA-XSS-SAFE: ``data-i18n-html`` 是 opt-in 的 authored-markup

      if (hVal !== hKey) hEl.innerHTML = hVal
    }

    for (var b = 0; b < ATTR_BINDINGS.length; b++) {
      var binding = ATTR_BINDINGS[b]
      var matches = scope.querySelectorAll('[' + binding.dataAttr + ']')
      for (var m = 0; m < matches.length; m++) {
        var mEl = matches[m]
        var mKey = mEl.getAttribute(binding.dataAttr)
        if (!mKey) continue
        var mVal = t(mKey)
        if (mVal === mKey) continue
        if (binding.setter === 'property') {
          mEl[binding.target] = mVal
        } else {
          mEl.setAttribute(binding.target, mVal)
        }
      }
    }
  }

  var _localeBaseUrl = null
  var _pendingLoads = {}
  var _defaultPromise = null

  function _localeVersionFor(lang) {
    try {
      var versions =
        typeof window !== 'undefined' && window.AIIA_LOCALE_VERSIONS
          ? window.AIIA_LOCALE_VERSIONS
          : null
      if (!versions || typeof versions !== 'object') return ''
      return versions[normalizeLang(lang)] || ''
    } catch (e) {
      return ''
    }
  }

  function _appendLocaleVersion(url, lang) {
    var version = _localeVersionFor(lang)
    if (!version) return url
    return url + (url.indexOf('?') === -1 ? '?' : '&') + 'v=' + encodeURIComponent(version)
  }

  function _localeUrlFor(lang) {
    if (!_localeBaseUrl) return null
    var normalized = normalizeLang(lang)
    var path =
      normalized === 'pseudo'
        ? '/_pseudo/pseudo.json'
        : '/' + normalized + '.json'
    return _appendLocaleVersion(_localeBaseUrl + path, normalized)
  }

  async function loadLocale(lang, url) {

    var normalized = normalizeLang(lang)
    var target = url
    if (!target && _localeBaseUrl) {
      target = _localeUrlFor(normalized)
    }
    if (!target) return false

    if (_pendingLoads[normalized]) return _pendingLoads[normalized]
    _pendingLoads[normalized] = (async function () {
      try {
        var resp = await fetch(target, { cache: 'default' })
        if (!resp.ok) return false
        var data = await resp.json()
        registerLocale(normalized, data)
        return true
      } catch (e) {
        return false
      } finally {
        delete _pendingLoads[normalized]
      }
    })()
    return _pendingLoads[normalized]
  }

  function ensureDefaultLocale() {
    if (locales[DEFAULT_LANG]) return Promise.resolve(true)
    if (_defaultPromise) return _defaultPromise
    if (!_localeBaseUrl) return Promise.resolve(false)
    _defaultPromise = loadLocale(DEFAULT_LANG).then(
      function (ok) {
        if (ok) {
          try {
            translateDOM()
          } catch (e) {

          }
        }
        return ok
      }
    )
    return _defaultPromise
  }

  async function init(options) {
    var opts = options && typeof options === 'object' ? options : {}

    if (opts.locales && typeof opts.locales === 'object') {
      var keys = Object.keys(opts.locales)
      for (var i = 0; i < keys.length; i++) {
        registerLocale(keys[i], opts.locales[keys[i]])
      }
    }

    var lang = opts.lang ? normalizeLang(opts.lang) : detectLang()

    if (opts.localeBaseUrl) {
      _localeBaseUrl = opts.localeBaseUrl
      if (!locales[lang]) {

        await loadLocale(lang)
      }

      if (lang !== DEFAULT_LANG) {
        ensureDefaultLocale()
      }
    }

    setLang(lang)

    if (opts.translateDOM !== false) {
      translateDOM()
    }
  }

  function wrapBidi(value) {
    if (value === undefined || value === null) return ''
    var s = typeof value === 'string' ? value : String(value)
    if (s === '') return ''
    if (
      s.length >= 2 &&
      s.charAt(0) === _FSI &&
      s.charAt(s.length - 1) === _PDI
    ) {
      return s
    }
    return _FSI + s + _PDI
  }

  function _testingFlushPendingLoads() {
    var keys = Object.keys(_pendingLoads)
    return Promise.all(
      keys.map(function (k) {
        return _pendingLoads[k]
      })
    )
  }

  function _testingClearIntlCaches() {
    _pluralRulesCache.clear()
    _pluralRulesOrdinalCache.clear()
    _icuCompileCache.clear()
    var names = Object.keys(_intlCache)
    for (var i = 0; i < names.length; i++) _intlCache[names[i]].clear()
  }
  function _testingGetIcuCompileCacheSize() {
    return _icuCompileCache.size
  }
  function _testingPeekIcuCompileKeys() {
    return Array.from(_icuCompileCache.keys())
  }
  function _testingGetIntlCacheSize(ctor) {
    var bucket = _intlCache[ctor]
    return bucket ? bucket.size : 0
  }
  function _testingPeekIntlCacheKeys(ctor) {
    var bucket = _intlCache[ctor]
    return bucket ? Array.from(bucket.keys()) : []
  }
  function _testingGetPluralRulesCacheSize() {
    return _pluralRulesCache.size
  }
  function _testingPeekPluralRulesKeys() {
    return Array.from(_pluralRulesCache.keys())
  }
  function _testingGetPluralRulesOrdinalCacheSize() {
    return _pluralRulesOrdinalCache.size
  }
  function _testingPeekPluralRulesOrdinalKeys() {
    return Array.from(_pluralRulesOrdinalCache.keys())
  }
  function _testingGetNonStringHits() {
    var out = []
    var keys = Object.keys(_nonStringHits)
    for (var i = 0; i < keys.length; i++) out.push(_nonStringHits[keys[i]])
    return out
  }
  function _testingResetNonStringHits() {
    _nonStringHits = Object.create(null)
  }

  var api = {
    t: t,
    init: init,
    setLang: setLang,
    getLang: getLang,
    getAvailableLangs: getAvailableLangs,
    registerLocale: registerLocale,
    loadLocale: loadLocale,
    ensureDefaultLocale: ensureDefaultLocale,
    detectLang: detectLang,
    normalizeLang: normalizeLang,
    translateDOM: translateDOM,
    formatNumber: formatNumber,
    formatDate: formatDate,
    formatRelativeTime: formatRelativeTime,
    formatRelativeFromNow: formatRelativeFromNow,
    formatList: formatList,
    wrapBidi: wrapBidi,
    setMissingKeyHandler: setMissingKeyHandler,
    setStrict: setStrict,
    getMissingKeyStats: getMissingKeyStats,
    resetMissingKeyStats: resetMissingKeyStats,
    DEFAULT_LANG: DEFAULT_LANG
  }

  try {
    window.AIIA_I18N = api
  } catch (e) {

  }

  try {
    window.AIIA_I18N__test = {
      flushPendingLoads: _testingFlushPendingLoads,
      clearIntlCaches: _testingClearIntlCaches,
      getIntlCacheSize: _testingGetIntlCacheSize,
      peekIntlCacheKeys: _testingPeekIntlCacheKeys,
      getPluralRulesCacheSize: _testingGetPluralRulesCacheSize,
      peekPluralRulesKeys: _testingPeekPluralRulesKeys,
      getPluralRulesOrdinalCacheSize: _testingGetPluralRulesOrdinalCacheSize,
      peekPluralRulesOrdinalKeys: _testingPeekPluralRulesOrdinalKeys,
      getIcuCompileCacheSize: _testingGetIcuCompileCacheSize,
      peekIcuCompileKeys: _testingPeekIcuCompileKeys,
      getNonStringHits: _testingGetNonStringHits,
      resetNonStringHits: _testingResetNonStringHits
    }
  } catch (e) {

  }
})()
