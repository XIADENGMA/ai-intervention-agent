function _tl(key, fallback) {
  try {
    if (window.AIIA_I18N && typeof window.AIIA_I18N.t === "function") {
      const value = window.AIIA_I18N.t(key);
      if (value && value !== key) return value;
    }
  } catch (_e) {

  }
  return fallback;
}

function _suppressConfigChangedEchoIfAvailable(ms) {
  try {
    if (
      typeof window !== "undefined" &&
      typeof window.suppressLocalConfigChangedEcho === "function"
    ) {
      window.suppressLocalConfigChangedEcho(typeof ms === "number" ? ms : 5000);
    }
  } catch (_e) {

  }
}

class SettingsManager {
  constructor() {
    this.storageKey = "ai-intervention-agent-settings";
    this.defaultSettings = {
      enabled: true,
      webEnabled: true,
      autoRequestPermission: true,
      soundEnabled: true,
      soundMute: false,
      soundVolume: 80,
      mobileOptimized: true,
      mobileVibrate: true,
      barkEnabled: false,
      barkUrl: "https://api.day.app/push",
      barkDeviceKey: "",
      barkIcon: "",
      barkAction: "none",
      barkUrlTemplate: "{base_url}/?task_id={task_id}",
    };
    this.initialized = false;
    this._initPromise = null;
    this._eventListenersInitialized = false;
    this._settingsEscHandler = null;
    this._previouslyFocusedElement = null;
    this._backendSyncPromise = null;
    this._pendingBackendSyncSettings = null;
    this._settingsEditEpoch = 0;
    this._feedbackConfigSavePromise = null;
    this._pendingFeedbackConfigUpdates = null;
    this._feedbackConfigDebounceTimer = null;
    this._pendingDebouncedFeedbackConfigUpdates = null;
    this._feedbackConfigSaveEpoch = 0;
    this._feedbackConfigEditEpoch = 0;
    this._languageChangeEpoch = 0;
    this._languagePersistPromise = null;
    this._pendingLanguagePreference = null;

  }

  _setElementPropertyById(id, propertyName, value) {
    const element = document.getElementById(id);
    if (element) {
      element[propertyName] = value;
    }
    return element;
  }

  _setFirstMatchText(selector, value) {
    const element = document.querySelector(selector);
    if (element) {
      element.textContent = value;
    }
    return element;
  }

  init() {
    if (this.initialized) {
      return Promise.resolve();
    }
    if (this._initPromise) {
      return this._initPromise;
    }

    this._initPromise = (async () => {
      try {
        this.settings = await this.loadSettings();
        this.feedbackConfig = await this.loadFeedbackConfig();
        this.initEventListeners();
        this.initOpenConfigFileButton();
        this.initBarkBaseUrlStatus();
        this.initialized = true;
        console.debug("SettingsManager initialized");
      } finally {

        this._initPromise = null;
      }
    })();

    return this._initPromise;
  }

  async loadSettings() {
    try {

      const response = await fetch("/api/get-notification-config");
      if (response.ok) {
        const result = await response.json();
        if (result.status === "success") {

          const serverConfig = result.config;
          const settings = {
            enabled: serverConfig.enabled ?? this.defaultSettings.enabled,
            webEnabled:
              serverConfig.web_enabled ?? this.defaultSettings.webEnabled,
            autoRequestPermission:
              serverConfig.auto_request_permission ??
              this.defaultSettings.autoRequestPermission,
            soundEnabled:
              serverConfig.sound_enabled ?? this.defaultSettings.soundEnabled,
            soundMute:
              serverConfig.sound_mute ?? this.defaultSettings.soundMute,
            soundVolume:
              serverConfig.sound_volume ?? this.defaultSettings.soundVolume,
            mobileOptimized:
              serverConfig.mobile_optimized ??
              this.defaultSettings.mobileOptimized,
            mobileVibrate:
              serverConfig.mobile_vibrate ?? this.defaultSettings.mobileVibrate,
            barkEnabled:
              serverConfig.bark_enabled ?? this.defaultSettings.barkEnabled,
            barkUrl: serverConfig.bark_url ?? this.defaultSettings.barkUrl,
            barkDeviceKey:
              serverConfig.bark_device_key ??
              this.defaultSettings.barkDeviceKey,
            barkIcon: serverConfig.bark_icon ?? this.defaultSettings.barkIcon,
            barkAction:
              serverConfig.bark_action ?? this.defaultSettings.barkAction,
            barkUrlTemplate:
              serverConfig.bark_url_template ??
              this.defaultSettings.barkUrlTemplate,
          };
          console.debug("Loaded settings from server");
          return settings;
        }
      }
    } catch (error) {
      console.warn(
        "Load settings from server failed; falling back to localStorage:",
        error,
      );
    }

    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...this.defaultSettings, ...parsed };
      }
    } catch (error) {
      console.warn("Load settings failed; using defaults:", error);
    }
    return { ...this.defaultSettings };
  }

  saveSettings() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.settings));
      console.debug("Settings saved");
    } catch (error) {
      console.error("Save settings failed:", error);
    }
  }

  updateSetting(key, value) {
    this._settingsEditEpoch += 1;
    this.settings[key] = value;
    this.saveSettings();
    this.applySettings();
    console.debug(`Setting updated: ${key} = ${value}`);
  }

  applySettings(options = {}) {
    const { syncBackend = true } = options;

    if (notificationManager) {
      notificationManager.updateConfig({
        enabled: this.settings.enabled,
        webEnabled: this.settings.webEnabled,
        autoRequestPermission: this.settings.autoRequestPermission,
        soundEnabled: this.settings.soundEnabled,
        soundMute: this.settings.soundMute,
        soundVolume: this.settings.soundVolume / 100,
        mobileOptimized: this.settings.mobileOptimized,
        mobileVibrate: this.settings.mobileVibrate,
        barkEnabled: this.settings.barkEnabled,
        barkUrl: this.settings.barkUrl,
        barkDeviceKey: this.settings.barkDeviceKey,
        barkIcon: this.settings.barkIcon,
        barkAction: this.settings.barkAction,
        barkUrlTemplate: this.settings.barkUrlTemplate,
      });
    }

    if (syncBackend) {
      this.syncConfigToBackend();
    }
  }

  syncConfigToBackend() {
    this._pendingBackendSyncSettings = {
      ...(this.settings || this.defaultSettings),
    };
    if (!this._backendSyncPromise) {
      this._backendSyncPromise = this._drainBackendConfigSyncQueue();
    }
    return this._backendSyncPromise;
  }

  async _drainBackendConfigSyncQueue() {
    try {
      while (this._pendingBackendSyncSettings) {
        const settingsSnapshot = this._pendingBackendSyncSettings;
        this._pendingBackendSyncSettings = null;
        await this._postNotificationConfigToBackend(settingsSnapshot);
      }
    } finally {

      this._backendSyncPromise = null;
    }
  }

  async _postNotificationConfigToBackend(settingsSnapshot) {
    try {
      _suppressConfigChangedEchoIfAvailable();
      const response = await fetch("/api/update-notification-config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settingsSnapshot),
      });

      const result = await response.json();
      if (response.ok && result.status === "success") {
        console.debug("Notification config synced to server");
      } else {
        console.warn(
          "Sync notification config to server failed:",
          result.message,
        );
      }
    } catch (error) {
      console.error("Sync notification config to server failed:", error);
    }
  }

  resetSettings() {
    var confirmMsg = _tl(
      "settings.resetConfirm",
      "Reset all local notification settings to defaults? Your overrides will be lost (server-stored feedback config is not affected).",
    );
    if (
      typeof window !== "undefined" &&
      typeof window.confirm === "function" &&
      !window.confirm(confirmMsg)
    ) {
      console.debug(
        _tl("settings.resetCancelled", "Settings reset cancelled by user"),
      );
      return;
    }
    this.settings = { ...this.defaultSettings };
    this.saveSettings();
    this.updateUI();
    this.applySettings();

    try {
      notificationManager.clearCustomSound();
      this._wireCustomSoundControls();
    } catch (_e) {

    }
    console.debug("Settings reset to defaults");
  }

  updateUI() {

    this._setElementPropertyById(
      "notification-enabled",
      "checked",
      this.settings.enabled,
    );
    this._setElementPropertyById(
      "web-notification-enabled",
      "checked",
      this.settings.webEnabled,
    );
    this._setElementPropertyById(
      "auto-request-permission",
      "checked",
      this.settings.autoRequestPermission,
    );
    this._setElementPropertyById(
      "sound-notification-enabled",
      "checked",
      this.settings.soundEnabled,
    );
    this._setElementPropertyById(
      "sound-mute",
      "checked",
      this.settings.soundMute,
    );
    this._setElementPropertyById(
      "sound-volume",
      "value",
      this.settings.soundVolume,
    );
    this._setFirstMatchText(".volume-value", `${this.settings.soundVolume}%`);
    this._setElementPropertyById(
      "mobile-optimized",
      "checked",
      this.settings.mobileOptimized,
    );
    this._setElementPropertyById(
      "mobile-vibrate",
      "checked",
      this.settings.mobileVibrate,
    );

    const langSelect = document.getElementById("language-select");
    if (langSelect) {
      const currentLang = window.AIIA_I18N
        ? window.AIIA_I18N.getLang()
        : "auto";
      const cfgLang = window.AIIA_CONFIG_LANG || "auto";
      langSelect.value = cfgLang !== "auto" ? cfgLang : currentLang || "auto";
    }

    this._setElementPropertyById(
      "bark-notification-enabled",
      "checked",
      this.settings.barkEnabled,
    );
    this._setElementPropertyById("bark-url", "value", this.settings.barkUrl);
    this._setElementPropertyById(
      "bark-device-key",
      "value",
      this.settings.barkDeviceKey,
    );
    this._setElementPropertyById("bark-icon", "value", this.settings.barkIcon);
    this._setElementPropertyById(
      "bark-action",
      "value",
      this.settings.barkAction,
    );
    const barkUrlTplEl = document.getElementById("bark-url-template");
    if (barkUrlTplEl) {
      barkUrlTplEl.value = this.settings.barkUrlTemplate || "";
    }
  }

  getStatusIcon(type) {
    const icons = {

      success: `<svg class="status-icon status-icon-success" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #4CAF50;"><polyline points="20 6 9 17 4 12"></polyline></svg>`,

      error: `<svg class="status-icon status-icon-error" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #F44336;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,

      warning: `<svg class="status-icon status-icon-warning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #FF9800;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`,

      paused: `<svg class="status-icon status-icon-paused" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #9E9E9E;"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`,
    };

    return icons[type] || icons.warning;
  }

  updateStatus() {

    const secureContext =
      typeof window !== "undefined" &&
      typeof window.isSecureContext === "boolean"
        ? window.isSecureContext
        : null;
    const origin =
      typeof window !== "undefined" &&
      window.location &&
      typeof window.location.origin === "string"
        ? window.location.origin
        : "";

    const browserSupportHtml = notificationManager.isSupported
      ? secureContext === false
        ? this.getStatusIcon("warning") + t("env.supportedLimited")
        : this.getStatusIcon("success") + t("env.supported")
      : this.getStatusIcon("error") + t("env.notSupported");

    let secureContextHtml;
    if (secureContext === true) {
      secureContextHtml =
        this.getStatusIcon("success") +
        (origin ? t("env.secureOrigin", { origin: origin }) : t("env.secure"));
    } else if (secureContext === false) {
      secureContextHtml =
        this.getStatusIcon("warning") +
        (origin
          ? t("env.insecureOrigin", { origin: origin })
          : t("env.insecure"));
    } else {
      secureContextHtml = this.getStatusIcon("warning") + t("env.unknown");
    }

    let permissionHtml;
    if (secureContext === false) {
      permissionHtml = this.getStatusIcon("warning") + t("env.permLimited");
    } else if (notificationManager.permission === "granted") {
      permissionHtml = this.getStatusIcon("success") + t("env.permGranted");
    } else if (notificationManager.permission === "denied") {
      permissionHtml = this.getStatusIcon("error") + t("env.permDenied");
    } else {
      permissionHtml =
        this.getStatusIcon("warning") + t("env.permNotRequested");
    }

    let audioStateHtml =
      this.getStatusIcon("error") + t("env.audioUnavailable");
    if (notificationManager.audioContext) {
      const state = notificationManager.audioContext.state;
      switch (state) {
        case "running":
          audioStateHtml =
            this.getStatusIcon("success") + t("env.audioRunning");
          break;
        case "suspended":
          audioStateHtml = this.getStatusIcon("paused") + t("env.audioPaused");
          break;
        case "closed":
          audioStateHtml = this.getStatusIcon("error") + t("env.audioClosed");
          break;
        default:
          audioStateHtml = this.getStatusIcon("warning") + state;
      }
    }

    this._setElementPropertyById(
      "browser-support-status",
      "innerHTML",
      browserSupportHtml,
    );
    this._setElementPropertyById(
      "notification-permission-status",
      "innerHTML",
      permissionHtml,
    );
    this._setElementPropertyById("audio-status", "innerHTML", audioStateHtml);
    const secureEl = document.getElementById(
      "notification-secure-context-status",
    );
    if (secureEl) {
      secureEl.innerHTML = secureContextHtml;
    }
  }

  initEventListeners() {
    if (this._eventListenersInitialized) {
      return;
    }
    this._eventListenersInitialized = true;

    const settingsBtn = document.getElementById("settings-btn");
    const settingsCloseBtn = document.getElementById("settings-close-btn");
    const testNotificationBtn = document.getElementById(
      "test-notification-btn",
    );
    const testBarkNotificationBtn = document.getElementById(
      "test-bark-notification-btn",
    );
    const resetSettingsBtn = document.getElementById("reset-settings-btn");

    if (settingsBtn) {
      settingsBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.showSettings();
      });
    }
    if (settingsCloseBtn) {
      settingsCloseBtn.addEventListener("click", () => this.hideSettings());
    }

    const settingsPanel = document.getElementById("settings-panel");
    if (settingsPanel && !settingsPanel.dataset.aiiaBackdropWired) {
      settingsPanel.addEventListener("click", (e) => {
        if (e.target === settingsPanel) {
          this.hideSettings();
        }
      });
      settingsPanel.dataset.aiiaBackdropWired = "1";
    }
    if (testNotificationBtn) {
      testNotificationBtn.addEventListener("click", () =>
        this.testNotification(),
      );
    }
    if (testBarkNotificationBtn) {
      testBarkNotificationBtn.addEventListener("click", () =>
        this.testBarkNotification(),
      );
    }
    if (resetSettingsBtn) {
      resetSettingsBtn.addEventListener("click", () => this.resetSettings());
    }

    const resetFeedbackBtn = document.getElementById(
      "reset-feedback-config-btn",
    );
    if (resetFeedbackBtn) {
      resetFeedbackBtn.addEventListener("click", () =>
        this.resetFeedbackConfig(),
      );
    }

    const openConfigBtn = document.getElementById("open-config-file-btn");
    if (openConfigBtn) {
      openConfigBtn.addEventListener("click", () => this.openConfigFileInIde());
    }

    const feedbackCountdown = document.getElementById("feedback-countdown");
    const feedbackPrompt = document.getElementById("feedback-resubmit-prompt");
    const feedbackSuffix = document.getElementById("feedback-prompt-suffix");

    if (feedbackCountdown) {
      feedbackCountdown.addEventListener("change", () => {
        const val = parseInt(feedbackCountdown.value, 10);

        if (!isNaN(val) && val >= 0 && val <= 3600) {
          this._queueFeedbackConfigSaveFromUi({ frontend_countdown: val });
        }
      });
    }
    if (feedbackPrompt) {
      feedbackPrompt.addEventListener("input", () => {
        this._queueFeedbackConfigSaveFromUi({
          resubmit_prompt: feedbackPrompt.value,
        });
      });
    }
    if (feedbackSuffix) {
      feedbackSuffix.addEventListener("input", () => {
        this._queueFeedbackConfigSaveFromUi({
          prompt_suffix: feedbackSuffix.value,
        });
      });
    }

    const langSelect = document.getElementById("language-select");
    if (langSelect) {
      langSelect.addEventListener("change", () => {
        return this._handleLanguageSelectChange(langSelect.value);
      });
    }

    document.addEventListener("click", (e) => {
      if (e.target.id === "settings-panel") {
        this.hideSettings();
      }
    });

    document.addEventListener("change", (e) => {
      const settingMap = {
        "notification-enabled": "enabled",
        "web-notification-enabled": "webEnabled",
        "auto-request-permission": "autoRequestPermission",
        "sound-notification-enabled": "soundEnabled",
        "sound-mute": "soundMute",
        "mobile-optimized": "mobileOptimized",
        "mobile-vibrate": "mobileVibrate",
        "bark-notification-enabled": "barkEnabled",
      };

      if (settingMap[e.target.id]) {
        this.updateSetting(settingMap[e.target.id], e.target.checked);
      } else if (e.target.id === "sound-volume") {
        this.updateSetting("soundVolume", parseInt(e.target.value));
        this._setFirstMatchText(".volume-value", `${e.target.value}%`);
      } else if (e.target.id === "bark-url") {
        this.updateSetting("barkUrl", e.target.value);
      } else if (e.target.id === "bark-device-key") {
        this.updateSetting("barkDeviceKey", e.target.value);
      } else if (e.target.id === "bark-icon") {
        this.updateSetting("barkIcon", e.target.value);
      } else if (e.target.id === "bark-action") {
        this.updateSetting("barkAction", e.target.value);
      } else if (e.target.id === "bark-url-template") {
        this.updateSetting("barkUrlTemplate", e.target.value);
      }
    });

    window.addEventListener("notification-permission-changed", () => {
      this.updateStatus();
    });

    this._wireCustomSoundControls();

  }

  _wireCustomSoundControls() {
    const fileInput = document.getElementById("custom-sound-input");
    const testBtn = document.getElementById("custom-sound-test");
    const clearBtn = document.getElementById("custom-sound-clear");
    const statusEl = document.getElementById("custom-sound-status");
    if (!fileInput || !testBtn || !clearBtn || !statusEl) return;

    const t =
      typeof window !== "undefined" && window.AIIA_I18N && typeof window.AIIA_I18N.t === "function"
        ? window.AIIA_I18N.t
        : (k) => k;

    const refresh = () => {
      const meta = notificationManager.getCustomSoundMeta();
      if (meta) {
        const kb = Math.round((meta.size || 0) / 1024);

        statusEl.removeAttribute("data-i18n");
        statusEl.textContent = `${meta.name} (${kb} KB)`;
        statusEl.setAttribute("data-status", "uploaded");
        testBtn.disabled = false;
        clearBtn.disabled = false;
      } else {

        statusEl.setAttribute("data-i18n", "settings.customSound.notUploaded");
        statusEl.textContent = t("settings.customSound.notUploaded");
        statusEl.setAttribute("data-status", "empty");
        testBtn.disabled = true;
        clearBtn.disabled = true;
      }
    };

    const resetFileInput = (input) => {
      if (!input) return;
      try {
        input.value = "";
      } catch (_e) {

      }
    };

    if (!fileInput.dataset.aiiaWired) {
      fileInput.dataset.aiiaWired = "1";
      fileInput.addEventListener("change", async (e) => {
        const target = e && e.target ? e.target : fileInput;
        const file = target.files && target.files[0];
        if (!file) {
          resetFileInput(target);
          return;
        }
        try {
          const result = await notificationManager.saveCustomSoundFromFile(file);
          if (result.success) {
            refresh();

            try {
              await notificationManager.playSound("custom");
            } catch (_e) {

            }
          } else {
            const code = String(result.error || "unknown");
            let msgKey = "settings.customSound.errors.generic";
            if (code === "invalid_mime") msgKey = "settings.customSound.errors.invalidMime";
            else if (code === "too_large") msgKey = "settings.customSound.errors.tooLarge";
            else if (code === "read_failed") msgKey = "settings.customSound.errors.readFailed";
            else if (code === "storage_failed") msgKey = "settings.customSound.errors.storageFailed";
            else if (code === "decode_failed") msgKey = "settings.customSound.errors.decodeFailed";
            else if (code === "duration_too_long") msgKey = "settings.customSound.errors.durationTooLong";

            statusEl.setAttribute("data-i18n", msgKey);
            statusEl.textContent = t(msgKey);
            statusEl.setAttribute("data-status", "error");
          }
        } catch (_e) {
          statusEl.setAttribute(
            "data-i18n",
            "settings.customSound.errors.generic",
          );
          statusEl.textContent = t("settings.customSound.errors.generic");
          statusEl.setAttribute("data-status", "error");
        } finally {

          resetFileInput(target);
        }
      });

      testBtn.addEventListener("click", () => {
        notificationManager.playSound("custom").catch(() => {});
      });

      clearBtn.addEventListener("click", () => {
        notificationManager.clearCustomSound();
        refresh();
      });
    }

    refresh();
  }

  async initOpenConfigFileButton() {
    const btn = document.getElementById("open-config-file-btn");
    const status = document.getElementById("open-config-file-status");
    if (!btn) return;

    const setDisabledWithReason = (reason) => {
      btn.disabled = true;
      btn.setAttribute("aria-disabled", "true");
      btn.title = reason;
      if (status) {
        status.textContent = reason;
        status.classList.remove("is-error", "is-success");
      }
    };

    try {
      const resp = await fetch("/api/system/open-config-file/info", {
        method: "GET",
        credentials: "same-origin",
      });
      if (resp.status === 403) {
        const remoteFallback =
          "Open-in-IDE is only available on the local machine running the server.";
        setDisabledWithReason(
          _tl("settings.openConfigInIdeRemoteBlocked", remoteFallback),
        );
        return;
      }
      if (!resp.ok) {
        setDisabledWithReason(
          _tl(
            "settings.openConfigInIdeUnavailable",
            "Open-in-IDE is unavailable.",
          ),
        );
        return;
      }
      const data = await resp.json();
      if (!data || data.success === false) {
        setDisabledWithReason(
          _tl(
            "settings.openConfigInIdeUnavailable",
            "Open-in-IDE is unavailable.",
          ),
        );
        return;
      }

      const editor = data.editor;
      const hasEditor = !!data.editor_available;
      const hasFallback = !!data.system_fallback_available;

      if (!hasEditor && !hasFallback) {
        const noEditorFallback =
          "No supported IDE (Cursor / VS Code / Sublime / etc.) found in PATH.";
        setDisabledWithReason(
          _tl("settings.openConfigInIdeNoEditor", noEditorFallback),
        );
        return;
      }

      btn.disabled = false;
      btn.removeAttribute("aria-disabled");
      const verb = hasEditor && editor ? editor : "system default";
      btn.title = _tl(
        "settings.openConfigInIdeReady",
        `Open with ${verb}`,
      ).replace("{editor}", verb);
      if (status) {
        status.classList.remove("is-error", "is-success");
        status.textContent = "";
      }
    } catch (e) {
      console.warn("open-config-file info fetch failed:", e);
      setDisabledWithReason(
        _tl(
          "settings.openConfigInIdeUnavailable",
          "Open-in-IDE is unavailable.",
        ),
      );
    }
  }

  async openConfigFileInIde() {
    const btn = document.getElementById("open-config-file-btn");
    const status = document.getElementById("open-config-file-status");
    const pathInput = document.getElementById("config-file-path");
    if (!btn) return;

    const originalDisabled = btn.disabled;
    btn.disabled = true;
    if (status) {
      status.classList.remove("is-error", "is-success");
      status.textContent = _tl(
        "settings.openConfigInIdeRequesting",
        "Opening…",
      );
    }

    try {
      const resp = await fetch("/api/system/open-config-file", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },

        body: JSON.stringify({}),
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || data.success === false) {
        const errMsg =
          (data && data.error) ||
          _tl("settings.openConfigInIdeFailed", "Failed to open config file.");
        if (status) {
          status.classList.add("is-error");
          status.textContent = errMsg;
        }
        return;
      }

      if (pathInput && data.path) {
        pathInput.value = data.path;
        pathInput.removeAttribute("data-i18n-value");
      }
      if (status) {
        status.classList.add("is-success");
        const editor = data.editor || "system";
        const tpl = _tl(
          "settings.openConfigInIdeOpened",
          "Opened with {editor}.",
        );
        status.textContent = tpl.replace("{editor}", editor);
      }
    } catch (e) {
      console.error("Open config file failed:", e);
      if (status) {
        status.classList.add("is-error");
        status.textContent = _tl(
          "settings.openConfigInIdeFailed",
          "Failed to open config file.",
        );
      }
    } finally {

      const btnNow = document.getElementById("open-config-file-btn");
      if (btnNow) {
        btnNow.disabled = originalDisabled;
      }
    }
  }

  async initBarkBaseUrlStatus() {
    const item = document.getElementById("bark-base-url-status-item");
    const message = document.getElementById("bark-base-url-status-message");
    const suggestion = document.getElementById(
      "bark-base-url-status-suggestion",
    );
    const copyBtn = document.getElementById("bark-base-url-copy-btn");
    const recheckBtn = document.getElementById("bark-base-url-recheck-btn");

    if (!item || !message || !suggestion) return;

    const renderStatus = async () => {
      try {
        const resp = await fetch("/api/system/network-base-url-status", {
          method: "GET",
          credentials: "same-origin",
        });
        if (!resp.ok) {
          item.hidden = true;
          return;
        }
        const data = await resp.json();
        if (!data || data.success === false) {
          item.hidden = true;
          return;
        }

        const isLoopback = data.is_loopback === true;
        const effective = data.effective_base_url || "";
        const suggested = data.suggested_lan_base_url || "";
        const recommendation = data.recommendation || "ok";

        if (recommendation === "ok") {
          message.textContent = (
            _tl("settings.baseUrlStatusOk", "Current base_url: {url}") || ""
          ).replace("{url}", effective);
          suggestion.textContent = "";
          item.hidden = false;
          item.classList.remove("is-warning");
          item.classList.add("is-ok");
          if (copyBtn) copyBtn.hidden = true;
          return;
        }

        item.hidden = false;
        item.classList.remove("is-ok");
        item.classList.add("is-warning");

        if (isLoopback && effective) {
          message.textContent = (
            _tl(
              "settings.baseUrlStatusLoopback",
              "Current base_url is a loopback address ({url}).",
            ) || ""
          ).replace("{url}", effective);
        } else {
          message.textContent = _tl(
            "settings.baseUrlStatusUnreachable",
            "No externally reachable base_url detected.",
          );
        }

        if (suggested) {
          suggestion.textContent = _tl(
            "settings.baseUrlSuggestLan",
            "Suggested fix: copy the LAN address below into web_ui.external_base_url.",
          );
          if (copyBtn) {
            copyBtn.hidden = false;
            copyBtn.dataset.lanUrl = suggested;
            copyBtn.title = suggested;
          }
        } else {
          suggestion.textContent = _tl(
            "settings.baseUrlSuggestNoLan",
            "No usable LAN interface detected; manually set web_ui.external_base_url.",
          );
          if (copyBtn) {
            copyBtn.hidden = true;
            copyBtn.dataset.lanUrl = "";
          }
        }
      } catch (e) {
        console.warn("network-base-url-status fetch failed:", e);
        item.hidden = true;
      }
    };

    if (recheckBtn) {
      recheckBtn.addEventListener("click", () => {
        renderStatus();
      });
    }
    if (copyBtn) {
      copyBtn.addEventListener("click", async () => {
        const url = copyBtn.dataset.lanUrl || "";
        if (!url) return;
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(url);
          } else {
            const ta = document.createElement("textarea");
            ta.value = url;
            ta.style.position = "fixed";
            ta.style.opacity = "0";
            document.body.appendChild(ta);
            ta.select();
            try {
              document.execCommand("copy");
            } finally {
              document.body.removeChild(ta);
            }
          }
          const span = copyBtn.querySelector("span");
          if (span) {
            const original = span.textContent;
            span.textContent = _tl("settings.baseUrlCopied", "Copied");
            setTimeout(() => {
              span.textContent = original;
            }, 1500);
          }
        } catch (e) {
          console.warn("Copy LAN url failed:", e);
        }
      });
    }

    await renderStatus();
  }

  async showSettings() {

    if (!this.initialized) {
      try {
        await this.init();
      } catch (e) {
        console.warn(
          "SettingsManager init failed while opening settings panel:",
          e,
        );
      }
    }

    const panel = document.getElementById("settings-panel");
    if (panel) {
      const wasAlreadyOpen = this._settingsEscHandler !== null;

      if (!wasAlreadyOpen) {
        this._previouslyFocusedElement = document.activeElement;
      }

      const container = document.querySelector(".container");
      if (container) {
        container.style.overflow = "visible";
        this._setContainerSiblingsInert(panel, true);
      }

      panel.classList.remove("hidden");
      panel.style.display = "flex";

      this.applySettingsTheme();

      this._attachSettingsKeydownHandler(panel);

      const firstFocusable = panel.querySelector(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
      );
      if (!wasAlreadyOpen && firstFocusable) {
        setTimeout(() => {
          this._focusSettingsPanelControl(firstFocusable, panel);
        }, 50);
      }
    }

    let shouldUpdateSettingsUI = true;
    try {
      shouldUpdateSettingsUI = await this._refreshSettingsForOpen();
    } catch (e) {
      console.warn("Refresh settings on open failed; keeping current:", e);
    }
    let shouldUpdateFeedbackUI = true;
    try {
      shouldUpdateFeedbackUI = await this._refreshFeedbackConfigForOpen();
    } catch (e) {
      console.warn("Refresh feedback config on open failed:", e);
    }

    if (shouldUpdateSettingsUI) {
      this.updateUI();
    }
    if (shouldUpdateFeedbackUI) {
      this.updateFeedbackUI();
    }
    this.updateStatus();
  }

  applySettingsTheme() {
    const theme = document.documentElement.getAttribute("data-theme");

    if (!document.getElementById("settings-light-theme-styles")) {
      const style = document.createElement("style");
      style.id = "settings-light-theme-styles";
      style.textContent = `
        [data-theme="light"] .settings-panel {
          background: rgba(0, 0, 0, 0.7) !important;
        }
        [data-theme="light"] .settings-content {
          background: #faf9f5 !important;
          border: 1px solid rgba(0, 0, 0, 0.12) !important;
          box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 20px rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .settings-body {
          background: #faf9f5 !important;
        }
        [data-theme="light"] .setting-group {
          background: #ffffff !important;
          border: 1px solid rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .setting-subgroup {
          background: #f8f8f5 !important;
        }
        [data-theme="light"] .settings-header {
          border-bottom: 1px solid rgba(0, 0, 0, 0.1) !important;
          background: #f2f1ec !important;
        }
        [data-theme="light"] .status-row {
          background: rgba(0, 0, 0, 0.02) !important;
          border-color: rgba(0, 0, 0, 0.08) !important;
          color: #141413 !important;
        }
        [data-theme="light"] .status-row span:first-child {
          color: rgba(20, 20, 19, 0.85) !important;
        }
        [data-theme="light"] .status-row span:last-child {
          color: #141413 !important;
        }
        [data-theme="light"] .setting-description {
          color: rgba(20, 20, 19, 0.65) !important;
        }
        [data-theme="light"] .setting-item:hover .setting-description {
          color: rgba(20, 20, 19, 0.75) !important;
        }
        [data-theme="light"] .setting-label:hover .setting-title {
          color: rgba(20, 20, 19, 0.9) !important;
        }
        [data-theme="light"] .setting-input::placeholder {
          color: rgba(20, 20, 19, 0.5) !important;
        }
        [data-theme="light"] .setting-label,
        [data-theme="light"] .setting-title,
        [data-theme="light"] .setting-subgroup-title,
        [data-theme="light"] .settings-main-title,
        [data-theme="light"] .setting-group-title,
        [data-theme="light"] #settings-title {
          color: #141413 !important;
        }
        [data-theme="light"] .settings-main-title {
          border-bottom-color: rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .setting-group::before {
          background: linear-gradient(90deg, transparent, rgba(0, 0, 0, 0.08), transparent) !important;
        }
        [data-theme="light"] .setting-group-title {
          -webkit-text-fill-color: #141413 !important;
          background: none !important;
          border-bottom-color: rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .setting-input {
          background: #ffffff !important;
          border-color: rgba(0, 0, 0, 0.15) !important;
          color: #141413 !important;
        }
        [data-theme="light"] .setting-select {
          background: #ffffff !important;
          border-color: rgba(0, 0, 0, 0.15) !important;
          color: #141413 !important;
        }
      `;
      document.head.appendChild(style);
    }
  }

  _setContainerSiblingsInert(openModalEl, value) {
    const container = document.querySelector(".container");
    if (!container) return;
    for (const child of container.children) {
      if (child === openModalEl) continue;
      this._safelySetInert(child, value);
    }
  }

  _safelySetInert(el, value) {
    if (!el) return;
    try {
      el.inert = value;
    } catch (_e) {
      if (value) {
        el.setAttribute("inert", "");
      } else {
        el.removeAttribute("inert");
      }
    }
  }

  _settingsFocusTrap(panel, event) {
    if (!panel) return;
    const focusables = panel.querySelectorAll(
      'button:not([disabled]),[href],input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',
    );
    let first = null;
    let last = null;
    const focusableCount =
      focusables && Number.isFinite(focusables.length) ? focusables.length : 0;
    for (let i = 0; i < focusableCount; i += 1) {
      const el = focusables[i];
      if (!el || el.offsetParent === null || el.hasAttribute("aria-hidden")) {
        continue;
      }
      if (!first) first = el;
      last = el;
    }
    if (!first || !last) return;
    const active = document.activeElement;
    if (event.shiftKey && active === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  }

  _attachSettingsKeydownHandler(panel) {
    if (this._settingsEscHandler) return;
    this._settingsEscHandler = (e) => {
      if (e.key === "Escape") {
        this.hideSettings();
        return;
      }
      if (e.key === "Tab") this._settingsFocusTrap(panel, e);
    };
    document.addEventListener("keydown", this._settingsEscHandler);
  }

  _focusSettingsPanelControl(element, panel) {
    if (!element || typeof element.focus !== "function") return false;

    try {
      if (panel) {
        if (
          typeof document.contains === "function" &&
          !document.contains(panel)
        ) {
          return false;
        }
        if (typeof panel.contains === "function" && !panel.contains(element)) {
          return false;
        }
        if (
          panel.classList &&
          typeof panel.classList.contains === "function" &&
          panel.classList.contains("hidden")
        ) {
          return false;
        }
        if (
          typeof panel.getAttribute === "function" &&
          panel.getAttribute("aria-hidden") === "true"
        ) {
          return false;
        }
        if (panel.style && panel.style.display === "none") {
          return false;
        }
      }
      if (
        typeof document.contains === "function" &&
        !document.contains(element)
      ) {
        return false;
      }
    } catch (_e) {
      return false;
    }

    return this._focusElementWithoutScroll(element);
  }

  _focusElementWithoutScroll(element) {
    if (!element || typeof element.focus !== "function") return false;

    try {
      element.focus({ preventScroll: true });
      return true;
    } catch (_e) {
      try {
        element.focus();
        return true;
      } catch (_e2) {
        return false;
      }
    }
  }

  async _refreshSettingsForOpen() {
    const editEpoch = this._settingsEditEpoch;
    const nextSettings = await this.loadSettings();
    if (editEpoch !== this._settingsEditEpoch) {
      return false;
    }
    this.settings = nextSettings;
    return true;
  }

  hideSettings() {
    const panel = document.getElementById("settings-panel");
    if (panel) {
      const container = document.querySelector(".container");
      if (container) {
        container.style.overflow = "";
        this._setContainerSiblingsInert(panel, false);
      }

      panel.classList.add("hidden");
      panel.style.display = "none";
    }

    if (this._settingsEscHandler) {
      document.removeEventListener("keydown", this._settingsEscHandler);
      this._settingsEscHandler = null;
    }

    const prev = this._previouslyFocusedElement;
    this._previouslyFocusedElement = null;
    if (prev && document.contains(prev) && this._focusElementWithoutScroll(prev)) {
      return;
    }
    const settingsBtn = document.getElementById("settings-btn");
    this._focusElementWithoutScroll(settingsBtn);
  }

  async testNotification() {
    try {
      await notificationManager.sendNotification(
        t("notify.testTitle"),
        t("notify.testBody"),
        {
          tag: "settings-test",
          requireInteraction: false,
        },
      );
      showStatus(t("status.testNotifySent"), "success");
    } catch (error) {
      console.error("Test notification failed:", error);
      showStatus(t("status.testNotifyFailed") + ": " + error.message, "error");
    }
  }

  async testBarkNotification() {
    try {
      if (!this.settings.barkEnabled) {
        showStatus(t("status.enableBarkFirst"), "warning");
        return;
      }

      if (!this.settings.barkUrl || !this.settings.barkDeviceKey) {
        showStatus(t("status.configureBark"), "warning");
        return;
      }

      showStatus(t("status.sendingBark"), "info");

      const response = await fetch("/api/test-bark", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          bark_url: this.settings.barkUrl,
          bark_device_key: this.settings.barkDeviceKey,
          bark_icon: this.settings.barkIcon,
          bark_action: this.settings.barkAction,
          bark_url_template:
            this.settings.barkUrlTemplate ||
            this.defaultSettings.barkUrlTemplate,
        }),
      });

      const result = await response.json();

      if (response.ok && result.status === "success") {
        showStatus(result.message, "success");
        console.debug("Bark notification sent:", result);
      } else {
        showStatus(result.message || t("status.barkFailed"), "error");
        console.error("Bark notification send failed:", result);
      }
    } catch (error) {
      console.error("Bark test notification failed:", error);
      showStatus(
        t("status.barkTestFailed", { reason: error.message }),
        "error",
      );
    }
  }

  async loadFeedbackConfig() {
    try {
      const resp = await fetch("/api/get-feedback-prompts", {
        cache: "no-store",
      });
      if (resp.ok) {
        const data = await resp.json();
        if (data.status === "success" && data.config) {
          return {
            frontend_countdown: data.config.frontend_countdown ?? 240,
            resubmit_prompt: data.config.resubmit_prompt ?? "",
            prompt_suffix: data.config.prompt_suffix ?? "",
          };
        }
      }
    } catch (e) {
      console.warn("Load feedback config failed:", e);
    }
    return { frontend_countdown: 240, resubmit_prompt: "", prompt_suffix: "" };
  }

  updateFeedbackUI() {
    const fc = this.feedbackConfig || {};
    const countdownEl = document.getElementById("feedback-countdown");
    const promptEl = document.getElementById("feedback-resubmit-prompt");
    const suffixEl = document.getElementById("feedback-prompt-suffix");
    if (countdownEl) countdownEl.value = fc.frontend_countdown ?? 240;
    if (promptEl) promptEl.value = fc.resubmit_prompt ?? "";
    if (suffixEl) suffixEl.value = fc.prompt_suffix ?? "";
  }

  _queueFeedbackConfigSaveFromUi(updates) {
    this._feedbackConfigEditEpoch += 1;
    if (this._feedbackConfigDebounceTimer) {
      clearTimeout(this._feedbackConfigDebounceTimer);
    }
    this._pendingDebouncedFeedbackConfigUpdates = Object.assign(
      this._pendingDebouncedFeedbackConfigUpdates || {},
      updates || {},
    );
    this._feedbackConfigDebounceTimer = setTimeout(() => {
      const merged = this._pendingDebouncedFeedbackConfigUpdates;
      this._pendingDebouncedFeedbackConfigUpdates = null;
      this._feedbackConfigDebounceTimer = null;
      this.saveFeedbackConfig(merged);
    }, 800);
  }

  _cancelPendingFeedbackConfigUiSave() {
    if (this._feedbackConfigDebounceTimer) {
      clearTimeout(this._feedbackConfigDebounceTimer);
    }
    this._feedbackConfigDebounceTimer = null;
    this._pendingDebouncedFeedbackConfigUpdates = null;
  }

  async _flushStaleFeedbackConfigSaveBeforeReset() {
    this._cancelPendingFeedbackConfigUiSave();
    this._pendingFeedbackConfigUpdates = null;
    this._feedbackConfigSaveEpoch += 1;
    this._feedbackConfigEditEpoch += 1;
    const savePromise = this._feedbackConfigSavePromise;
    if (!savePromise) return;
    try {
      await savePromise;
    } catch (_e) {

    }
  }

  async _refreshFeedbackConfigForOpen() {
    const editEpoch = this._feedbackConfigEditEpoch;
    const nextFeedbackConfig = await this.loadFeedbackConfig();
    if (editEpoch !== this._feedbackConfigEditEpoch) {
      return false;
    }
    this.feedbackConfig = nextFeedbackConfig;
    return true;
  }

  async _handleLanguageSelectChange(newLang) {
    const changeEpoch = this._languageChangeEpoch + 1;
    this._languageChangeEpoch = changeEpoch;

    try {
      if (window.AIIA_I18N) {
        const i18n = window.AIIA_I18N;
        const targetLang =
          newLang === "auto" ? i18n.detectLang() : i18n.normalizeLang(newLang);

        if (!i18n.getAvailableLangs().includes(targetLang)) {
          await i18n.loadLocale(targetLang);
          if (changeEpoch !== this._languageChangeEpoch) return;
        }
        if (
          targetLang !== "en" &&
          !i18n.getAvailableLangs().includes("en")
        ) {
          await i18n.loadLocale("en");
          if (changeEpoch !== this._languageChangeEpoch) return;
        }

        if (changeEpoch !== this._languageChangeEpoch) return;
        i18n.setLang(targetLang);
        i18n.translateDOM();
      }

      if (changeEpoch !== this._languageChangeEpoch) return;
      this._queueLanguagePreferenceSave(newLang);
    } catch (e) {
      if (changeEpoch === this._languageChangeEpoch) {
        console.warn("Apply language preference failed:", e);
      }
    }
  }

  _queueLanguagePreferenceSave(language) {
    this._pendingLanguagePreference = language;
    if (!this._languagePersistPromise) {
      this._languagePersistPromise = this._drainLanguagePreferenceSaveQueue();
    }
    return this._languagePersistPromise;
  }

  async _drainLanguagePreferenceSaveQueue() {
    try {
      while (this._pendingLanguagePreference !== null) {
        const language = this._pendingLanguagePreference;
        this._pendingLanguagePreference = null;
        await this._postLanguagePreference(language);
      }
    } finally {

      this._languagePersistPromise = null;
    }
  }

  async _postLanguagePreference(language) {
    try {
      _suppressConfigChangedEchoIfAvailable();
      const resp = await fetch("/api/update-language", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language: language }),
      });
      if (!resp.ok) {
        console.warn("Persist language preference failed:", resp.status);
      }
    } catch (e) {
      console.warn("Persist language preference failed:", e);
    }
  }

  saveFeedbackConfig(updates) {
    this._pendingFeedbackConfigUpdates = Object.assign(
      this._pendingFeedbackConfigUpdates || {},
      updates || {},
    );
    if (!this._feedbackConfigSavePromise) {
      this._feedbackConfigSavePromise = this._drainFeedbackConfigSaveQueue();
    }
    return this._feedbackConfigSavePromise;
  }

  async _drainFeedbackConfigSaveQueue() {
    const saveEpoch = this._feedbackConfigSaveEpoch;
    const acknowledgedUpdates = {};
    let hasAcknowledgedUpdates = false;
    let finalResult = null;

    try {
      while (this._pendingFeedbackConfigUpdates) {
        const updates = this._pendingFeedbackConfigUpdates;
        this._pendingFeedbackConfigUpdates = null;
        finalResult = await this._postFeedbackConfigUpdates(updates);
        if (saveEpoch !== this._feedbackConfigSaveEpoch) {
          return;
        }
        if (finalResult.ok) {
          Object.assign(acknowledgedUpdates, updates);
          hasAcknowledgedUpdates = true;
        } else if (!this._pendingFeedbackConfigUpdates) {
          if (hasAcknowledgedUpdates) {
            Object.assign(
              this.feedbackConfig || (this.feedbackConfig = {}),
              acknowledgedUpdates,
            );
          }
          this._showFeedbackConfigSaveResult(finalResult);
          return;
        }
      }

      if (saveEpoch !== this._feedbackConfigSaveEpoch) {
        return;
      }
      if (hasAcknowledgedUpdates) {
        Object.assign(
          this.feedbackConfig || (this.feedbackConfig = {}),
          acknowledgedUpdates,
        );
      }
      if (finalResult) {
        this._showFeedbackConfigSaveResult(finalResult);
      }
    } finally {

      this._feedbackConfigSavePromise = null;
    }
  }

  async _postFeedbackConfigUpdates(updates) {
    try {
      _suppressConfigChangedEchoIfAvailable();
      const resp = await fetch("/api/update-feedback-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data.status === "success") {
        return { ok: true };
      }
      return {
        ok: false,
        message: data.message || t("settings.feedbackConfigSaveFailed"),
      };
    } catch (e) {
      console.error("Save feedback config failed:", e);
      return {
        ok: false,
        message: t("settings.feedbackConfigSaveFailed"),
      };
    }
  }

  _showFeedbackConfigSaveResult(result) {
    if (result && result.ok) {
      showStatus(t("settings.feedbackConfigSaved"), "success");
    } else {
      showStatus(
        (result && result.message) || t("settings.feedbackConfigSaveFailed"),
        "error",
      );
    }
  }

  async resetFeedbackConfig() {

    const confirmMsg = _tl(
      "settings.resetFeedbackConfirm",
      "Reset server-stored feedback config (countdown timeout, resubmit prompt, prompt suffix) to defaults? All collaborators on this server will see the change via SSE broadcast.",
    );
    if (
      typeof window !== "undefined" &&
      typeof window.confirm === "function" &&
      !window.confirm(confirmMsg)
    ) {
      console.debug(
        _tl(
          "settings.resetFeedbackCancelled",
          "Feedback config reset cancelled by user",
        ),
      );
      return;
    }
    await this._flushStaleFeedbackConfigSaveBeforeReset();

    try {
      _suppressConfigChangedEchoIfAvailable();
      const resp = await fetch("/api/reset-feedback-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || data.status !== "success") {
        showStatus(
          data.message || t("settings.feedbackConfigSaveFailed"),
          "error",
        );
        return;
      }
      if (data.defaults && typeof data.defaults === "object") {
        Object.assign(
          this.feedbackConfig || (this.feedbackConfig = {}),
          data.defaults,
        );
      } else {
        this.feedbackConfig = await this.loadFeedbackConfig();
      }
    } catch (e) {
      console.error("Reset feedback config failed:", e);
      showStatus(t("settings.feedbackConfigSaveFailed"), "error");
      return;
    }
    this.updateFeedbackUI();
    showStatus(t("settings.feedbackConfigReset"), "success");
  }
}

const settingsManager = new SettingsManager();

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    SettingsManager,
    settingsManager,
    _tl,
    _suppressConfigChangedEchoIfAvailable,
  };
}
