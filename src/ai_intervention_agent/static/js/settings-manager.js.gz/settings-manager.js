/**
 * 设置管理器 - 从 app.js 拆分
 *
 * 管理 Web UI 的本地偏好设置（通知、声音、主题、Bark 等），
 * 支持 localStorage 持久化和后端配置同步。
 *
 * 依赖: notification-manager.js (notificationManager)
 * 暴露: window.settingsManager (SettingsManager 实例)
 */

// 模块内 i18n 帮助函数：调用 window.AIIA_I18N.t() 失败/缺键时回退到内置 fallback。
// 命名为 `_tl`（i18n 扫描器接受的 wrapper：_t / _tl / t / tl / hostT / __vuT 等），
// 不复用 multi_task.js 的 `_t`，因为后者的第二个参数是 params 而不是 fallback 字符串，
// 在 i18n 未加载等边界场景里会向用户暴露原始 key。
function _tl(key, fallback) {
  try {
    if (window.AIIA_I18N && typeof window.AIIA_I18N.t === "function") {
      const value = window.AIIA_I18N.t(key);
      if (value && value !== key) return value;
    }
  } catch (_e) {
    // 忽略 i18n 读取失败
  }
  return fallback;
}

// BUG1：主动写配置前，调用 multi_task.js 暴露的 ``suppressLocalConfigChangedEcho``
// 设置短期静音窗口，避免后端 file watcher 触发的 SSE ``config_changed`` 事件
// 在当前 client 上再弹一条"Configuration file changed. Reload..." toast。
// 详细动机见 multi_task.js 中 ``_suppressConfigChangedToastUntilMs`` 注释。
//
// 设计取舍：
// - 把"是否暴露 helper"的判断放在调用方而非 multi_task.js 是因为
//   settings-manager.js 可能在 multi_task.js 之前加载（理论上 HTML
//   load order 决定，但保险起见各模块都自我兜底）。
// - 静音 5000ms 是经验值：覆盖后端 R50-B 的 250ms debounce + Flask
//   响应延迟 + 网络抖动 + 浏览器调度。窗口越长越不会"漏掉"自己的回响，
//   但代价是别人在窗口内改配置时本 client 看不到 toast；按使用场景，
//   多 client 同时改同一份配置概率极低，5s 是合理上限。
// - 不依赖 multi_task.js 必然存在：若 helper 不可用就静默 noop，保证
//   主流程（保存配置）不会因此 break。
function _suppressConfigChangedEchoIfAvailable(ms) {
  try {
    if (
      typeof window !== "undefined" &&
      typeof window.suppressLocalConfigChangedEcho === "function"
    ) {
      window.suppressLocalConfigChangedEcho(typeof ms === "number" ? ms : 5000);
    }
  } catch (_e) {
    // helper 抛错绝不能影响主流程（保存配置）。
  }
}

// 设置管理器
class SettingsManager {
  constructor() {
    this.storageKey = "ai-intervention-agent-settings";
    this.defaultSettings = {
      enabled: true,
      webEnabled: true,
      autoRequestPermission: true,
      soundEnabled: true,
      soundMute: false,
      soundVolume: 80,
      mobileOptimized: true,
      mobileVibrate: true,
      barkEnabled: false,
      barkUrl: "https://api.day.app/push",
      barkDeviceKey: "",
      barkIcon: "",
      barkAction: "none",
      barkUrlTemplate: "{base_url}/?task_id={task_id}",
    };
    this.initialized = false;
    // 注意：不在构造函数中调用 init()，由 DOMContentLoaded 触发
  }

  async init() {
    if (this.initialized) return;
    this.settings = await this.loadSettings();
    this.feedbackConfig = await this.loadFeedbackConfig();
    this.initEventListeners();
    this.initOpenConfigFileButton();
    this.initBarkBaseUrlStatus();
    this.initialized = true;
    console.debug("SettingsManager initialized");
  }

  async loadSettings() {
    try {
      // 优先从服务器加载配置
      const response = await fetch("/api/get-notification-config");
      if (response.ok) {
        const result = await response.json();
        if (result.status === "success") {
          // 将服务器配置映射到前端格式
          const serverConfig = result.config;
          const settings = {
            enabled: serverConfig.enabled ?? this.defaultSettings.enabled,
            webEnabled:
              serverConfig.web_enabled ?? this.defaultSettings.webEnabled,
            autoRequestPermission:
              serverConfig.auto_request_permission ??
              this.defaultSettings.autoRequestPermission,
            soundEnabled:
              serverConfig.sound_enabled ?? this.defaultSettings.soundEnabled,
            soundMute:
              serverConfig.sound_mute ?? this.defaultSettings.soundMute,
            soundVolume:
              serverConfig.sound_volume ?? this.defaultSettings.soundVolume,
            mobileOptimized:
              serverConfig.mobile_optimized ??
              this.defaultSettings.mobileOptimized,
            mobileVibrate:
              serverConfig.mobile_vibrate ?? this.defaultSettings.mobileVibrate,
            barkEnabled:
              serverConfig.bark_enabled ?? this.defaultSettings.barkEnabled,
            barkUrl: serverConfig.bark_url ?? this.defaultSettings.barkUrl,
            barkDeviceKey:
              serverConfig.bark_device_key ??
              this.defaultSettings.barkDeviceKey,
            barkIcon: serverConfig.bark_icon ?? this.defaultSettings.barkIcon,
            barkAction:
              serverConfig.bark_action ?? this.defaultSettings.barkAction,
            barkUrlTemplate:
              serverConfig.bark_url_template ??
              this.defaultSettings.barkUrlTemplate,
          };
          console.debug("Loaded settings from server");
          return settings;
        }
      }
    } catch (error) {
      console.warn(
        "Load settings from server failed; falling back to localStorage:",
        error,
      );
    }

    // 回退到localStorage
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...this.defaultSettings, ...parsed };
      }
    } catch (error) {
      console.warn("Load settings failed; using defaults:", error);
    }
    return { ...this.defaultSettings };
  }

  saveSettings() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.settings));
      console.debug("Settings saved");
    } catch (error) {
      console.error("Save settings failed:", error);
    }
  }

  updateSetting(key, value) {
    this.settings[key] = value;
    this.saveSettings();
    this.applySettings();
    console.debug(`Setting updated: ${key} = ${value}`);
  }

  applySettings(options = {}) {
    const { syncBackend = true } = options;
    // 更新前端通知管理器配置
    if (notificationManager) {
      notificationManager.updateConfig({
        enabled: this.settings.enabled,
        webEnabled: this.settings.webEnabled,
        autoRequestPermission: this.settings.autoRequestPermission,
        soundEnabled: this.settings.soundEnabled,
        soundMute: this.settings.soundMute,
        soundVolume: this.settings.soundVolume / 100,
        mobileOptimized: this.settings.mobileOptimized,
        mobileVibrate: this.settings.mobileVibrate,
        barkEnabled: this.settings.barkEnabled,
        barkUrl: this.settings.barkUrl,
        barkDeviceKey: this.settings.barkDeviceKey,
        barkIcon: this.settings.barkIcon,
        barkAction: this.settings.barkAction,
        barkUrlTemplate: this.settings.barkUrlTemplate,
      });
    }

    // 同步配置到后端
    if (syncBackend) {
      this.syncConfigToBackend();
    }
  }

  async syncConfigToBackend() {
    try {
      _suppressConfigChangedEchoIfAvailable();
      const response = await fetch("/api/update-notification-config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(this.settings),
      });

      const result = await response.json();
      if (response.ok && result.status === "success") {
        console.debug("Notification config synced to server");
      } else {
        console.warn(
          "Sync notification config to server failed:",
          result.message,
        );
      }
    } catch (error) {
      console.error("Sync notification config to server failed:", error);
    }
  }

  // feat-reset-confirm：
  // 重置设置是破坏性操作（一键覆盖本地 + 同步推回后端），用户曾反馈"误点
  // 完成只能手工逐项再调一遍"。改为弹原生 ``window.confirm`` 二次确认，
  // 取消则直接 noop，保留全部既有偏好。
  //
  // 选型理由：
  // - 与 ``quick_phrases.js`` 的删除短语 / 全量替换确认走同一套范式，
  //   不引入额外 modal 组件，最小变更面 + 行为一致。
  // - i18n key ``settings.resetConfirm`` / ``settings.resetCancelled``
  //   覆盖 en / zh-CN / pseudo；缺 key 时退到内置英文 fallback，与
  //   其它 ``_tl`` 调用站对齐。
  // - 在浏览器禁用 ``window.confirm``（极少见，如自动化测试 / 某些
  //   嵌入场景）的环境下，行为退化为"不再二次确认、直接重置"，
  //   而不是"重置永远点不动"——后者会让用户更困惑。
  resetSettings() {
    var confirmMsg = _tl(
      "settings.resetConfirm",
      "Reset all local notification settings to defaults? Your overrides will be lost (server-stored feedback config is not affected).",
    );
    if (
      typeof window !== "undefined" &&
      typeof window.confirm === "function" &&
      !window.confirm(confirmMsg)
    ) {
      console.debug(
        _tl("settings.resetCancelled", "Settings reset cancelled by user"),
      );
      return;
    }
    this.settings = { ...this.defaultSettings };
    this.saveSettings();
    this.updateUI();
    this.applySettings();
    // feat-custom-sound (§3.4): reset 也要清掉自定义音效 localStorage entry
    // + audioBuffers['custom']，否则 "重置到默认" 的语义就有窟窿（用户期望
    // reset = "完全回到出厂默认"）。
    try {
      notificationManager.clearCustomSound();
      this._wireCustomSoundControls(); // 刷新 status / disabled 状态
    } catch (_e) {
      // 静默：reset 主路径已经完成，custom sound 清理失败不应 gate UX
    }
    console.debug("Settings reset to defaults");
  }

  updateUI() {
    // 更新设置面板中的控件状态
    document.getElementById("notification-enabled").checked =
      this.settings.enabled;
    document.getElementById("web-notification-enabled").checked =
      this.settings.webEnabled;
    document.getElementById("auto-request-permission").checked =
      this.settings.autoRequestPermission;
    document.getElementById("sound-notification-enabled").checked =
      this.settings.soundEnabled;
    document.getElementById("sound-mute").checked = this.settings.soundMute;
    document.getElementById("sound-volume").value = this.settings.soundVolume;
    document.querySelector(".volume-value").textContent =
      `${this.settings.soundVolume}%`;
    document.getElementById("mobile-optimized").checked =
      this.settings.mobileOptimized;
    document.getElementById("mobile-vibrate").checked =
      this.settings.mobileVibrate;

    // 语言选择器
    const langSelect = document.getElementById("language-select");
    if (langSelect) {
      const currentLang = window.AIIA_I18N
        ? window.AIIA_I18N.getLang()
        : "auto";
      const cfgLang = window.AIIA_CONFIG_LANG || "auto";
      langSelect.value = cfgLang !== "auto" ? cfgLang : currentLang || "auto";
    }

    // 更新 Bark 设置
    document.getElementById("bark-notification-enabled").checked =
      this.settings.barkEnabled;
    document.getElementById("bark-url").value = this.settings.barkUrl;
    document.getElementById("bark-device-key").value =
      this.settings.barkDeviceKey;
    document.getElementById("bark-icon").value = this.settings.barkIcon;
    document.getElementById("bark-action").value = this.settings.barkAction;
    const barkUrlTplEl = document.getElementById("bark-url-template");
    if (barkUrlTplEl) {
      barkUrlTplEl.value = this.settings.barkUrlTemplate || "";
    }
  }

  /**
   * 获取状态图标 SVG（Claude 风格线条图标）
   *
   * 功能说明：
   *   生成用于设置面板状态显示的 SVG 图标，替代原有的 emoji。
   *   采用 Claude 官方设计风格：线条图标、适当的 stroke-width。
   *
   * 设计规范：
   *   - 尺寸：16x16px
   *   - stroke-width: 2（与其他图标一致）
   *   - stroke-linecap/linejoin: round（圆润的线条端点）
   *   - 垂直居中：vertical-align: middle
   *   - 与文字间距：margin-right: 4px
   *
   * 颜色方案：
   *   - success: #4CAF50（绿色）- 表示正常/已启用
   *   - error: #F44336（红色）- 表示错误/已禁用
   *   - warning: #FF9800（橙色）- 表示警告/未配置
   *   - paused: #9E9E9E（灰色）- 表示暂停状态
   *
   * @param {string} type - 图标类型：'success' | 'error' | 'warning' | 'paused'
   * @returns {string} SVG HTML 字符串，可直接插入到 innerHTML
   */
  getStatusIcon(type) {
    const icons = {
      // 成功图标（勾号）- 浏览器支持/通知已授权/音频运行中
      success: `<svg class="status-icon status-icon-success" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #4CAF50;"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
      // 错误图标（叉号）- 不支持/已拒绝/已关闭
      error: `<svg class="status-icon status-icon-error" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #F44336;"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,
      // 警告图标（感叹号三角形）- 未请求权限/未知状态
      warning: `<svg class="status-icon status-icon-warning" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #FF9800;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`,
      // 暂停图标（双竖线）- 音频已暂停
      paused: `<svg class="status-icon status-icon-paused" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #9E9E9E;"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`,
    };
    // 默认返回警告图标，处理未知类型
    return icons[type] || icons.warning;
  }

  updateStatus() {
    // 更新状态信息（使用 SVG 图标替代 emoji）
    const secureContext =
      typeof window !== "undefined" &&
      typeof window.isSecureContext === "boolean"
        ? window.isSecureContext
        : null;
    const origin =
      typeof window !== "undefined" &&
      window.location &&
      typeof window.location.origin === "string"
        ? window.location.origin
        : "";

    const browserSupportHtml = notificationManager.isSupported
      ? secureContext === false
        ? this.getStatusIcon("warning") + t("env.supportedLimited")
        : this.getStatusIcon("success") + t("env.supported")
      : this.getStatusIcon("error") + t("env.notSupported");

    let secureContextHtml;
    if (secureContext === true) {
      secureContextHtml =
        this.getStatusIcon("success") +
        (origin ? t("env.secureOrigin", { origin: origin }) : t("env.secure"));
    } else if (secureContext === false) {
      secureContextHtml =
        this.getStatusIcon("warning") +
        (origin
          ? t("env.insecureOrigin", { origin: origin })
          : t("env.insecure"));
    } else {
      secureContextHtml = this.getStatusIcon("warning") + t("env.unknown");
    }

    let permissionHtml;
    if (secureContext === false) {
      permissionHtml = this.getStatusIcon("warning") + t("env.permLimited");
    } else if (notificationManager.permission === "granted") {
      permissionHtml = this.getStatusIcon("success") + t("env.permGranted");
    } else if (notificationManager.permission === "denied") {
      permissionHtml = this.getStatusIcon("error") + t("env.permDenied");
    } else {
      permissionHtml =
        this.getStatusIcon("warning") + t("env.permNotRequested");
    }

    // 音频状态中文化
    let audioStateHtml =
      this.getStatusIcon("error") + t("env.audioUnavailable");
    if (notificationManager.audioContext) {
      const state = notificationManager.audioContext.state;
      switch (state) {
        case "running":
          audioStateHtml =
            this.getStatusIcon("success") + t("env.audioRunning");
          break;
        case "suspended":
          audioStateHtml = this.getStatusIcon("paused") + t("env.audioPaused");
          break;
        case "closed":
          audioStateHtml = this.getStatusIcon("error") + t("env.audioClosed");
          break;
        default:
          audioStateHtml = this.getStatusIcon("warning") + state;
      }
    }

    document.getElementById("browser-support-status").innerHTML =
      browserSupportHtml;
    document.getElementById("notification-permission-status").innerHTML =
      permissionHtml;
    document.getElementById("audio-status").innerHTML = audioStateHtml;
    const secureEl = document.getElementById(
      "notification-secure-context-status",
    );
    if (secureEl) {
      secureEl.innerHTML = secureContextHtml;
    }
  }

  initEventListeners() {
    // 设置按钮点击事件 - 使用直接绑定确保可靠
    const settingsBtn = document.getElementById("settings-btn");
    const settingsCloseBtn = document.getElementById("settings-close-btn");
    const testNotificationBtn = document.getElementById(
      "test-notification-btn",
    );
    const testBarkNotificationBtn = document.getElementById(
      "test-bark-notification-btn",
    );
    const resetSettingsBtn = document.getElementById("reset-settings-btn");

    if (settingsBtn) {
      settingsBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.showSettings();
      });
    }
    if (settingsCloseBtn) {
      settingsCloseBtn.addEventListener("click", () => this.hideSettings());
    }
    if (testNotificationBtn) {
      testNotificationBtn.addEventListener("click", () =>
        this.testNotification(),
      );
    }
    if (testBarkNotificationBtn) {
      testBarkNotificationBtn.addEventListener("click", () =>
        this.testBarkNotification(),
      );
    }
    if (resetSettingsBtn) {
      resetSettingsBtn.addEventListener("click", () => this.resetSettings());
    }

    const resetFeedbackBtn = document.getElementById(
      "reset-feedback-config-btn",
    );
    if (resetFeedbackBtn) {
      resetFeedbackBtn.addEventListener("click", () =>
        this.resetFeedbackConfig(),
      );
    }

    const openConfigBtn = document.getElementById("open-config-file-btn");
    if (openConfigBtn) {
      openConfigBtn.addEventListener("click", () => this.openConfigFileInIde());
    }

    const feedbackCountdown = document.getElementById("feedback-countdown");
    const feedbackPrompt = document.getElementById("feedback-resubmit-prompt");
    const feedbackSuffix = document.getElementById("feedback-prompt-suffix");

    // Debounce + accumulate：800ms 窗口内多个字段的修改必须合并保存。
    //
    // 历史 bug：旧实现 ``setTimeout(..., updates)`` 每次都用最新一次调用
    // 的 ``updates``，clearTimeout 时旧 payload 直接丢弃。重现：
    //   T=0    改 frontend_countdown=60        → timer(at 800)
    //   T=300  改 resubmit_prompt="x"          → clearTimeout(旧)，
    //                                            新 timer(at 1100)
    //   T=1100 发送 {resubmit_prompt:"x"}      → frontend_countdown=60 永久丢
    //
    // 修复：每次调用把 updates 合进 ``feedbackPendingUpdates``，timer
    // 触发时一次性 POST。和 packages/vscode/webview-settings-ui.js 保持
    // byte-parity（双份代码必须同步修，否则 Web/VSCode 行为分歧）。
    let feedbackSaveTimer = null;
    let feedbackPendingUpdates = null;
    const debounceSaveFeedback = (updates) => {
      if (feedbackSaveTimer) clearTimeout(feedbackSaveTimer);
      feedbackPendingUpdates = Object.assign(
        feedbackPendingUpdates || {},
        updates || {},
      );
      feedbackSaveTimer = setTimeout(() => {
        const merged = feedbackPendingUpdates;
        feedbackPendingUpdates = null;
        feedbackSaveTimer = null;
        this.saveFeedbackConfig(merged);
      }, 800);
    };

    if (feedbackCountdown) {
      feedbackCountdown.addEventListener("change", () => {
        const val = parseInt(feedbackCountdown.value, 10);
        // Range mirrors server_config.AUTO_RESUBMIT_TIMEOUT_MAX (3600s); 0
        // remains the "disabled" sentinel. Locked by
        // tests/test_frontend_input_range_parity.py.
        if (!isNaN(val) && val >= 0 && val <= 3600) {
          debounceSaveFeedback({ frontend_countdown: val });
        }
      });
    }
    if (feedbackPrompt) {
      feedbackPrompt.addEventListener("input", () => {
        debounceSaveFeedback({ resubmit_prompt: feedbackPrompt.value });
      });
    }
    if (feedbackSuffix) {
      feedbackSuffix.addEventListener("input", () => {
        debounceSaveFeedback({ prompt_suffix: feedbackSuffix.value });
      });
    }

    // 主题切换按钮点击事件 - 已由 theme.js 处理，此处删除避免重复绑定

    // 语言切换
    const langSelect = document.getElementById("language-select");
    if (langSelect) {
      langSelect.addEventListener("change", async () => {
        const newLang = langSelect.value;
        if (window.AIIA_I18N) {
          const targetLang =
            newLang === "auto"
              ? window.AIIA_I18N.detectLang()
              : window.AIIA_I18N.normalizeLang(newLang);

          if (!window.AIIA_I18N.getAvailableLangs().includes(targetLang)) {
            await window.AIIA_I18N.loadLocale(
              targetLang,
              "/static/locales/" + targetLang + ".json",
            );
          }
          if (
            targetLang !== "en" &&
            !window.AIIA_I18N.getAvailableLangs().includes("en")
          ) {
            await window.AIIA_I18N.loadLocale("en", "/static/locales/en.json");
          }

          window.AIIA_I18N.setLang(targetLang);
          window.AIIA_I18N.translateDOM();
        }

        try {
          _suppressConfigChangedEchoIfAvailable();
          await fetch("/api/update-language", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ language: newLang }),
          });
        } catch (e) {
          console.warn("Persist language preference failed:", e);
        }
      });
    }

    // 设置面板背景点击关闭
    document.addEventListener("click", (e) => {
      if (e.target.id === "settings-panel") {
        this.hideSettings();
      }
    });

    // 设置项变更事件
    document.addEventListener("change", (e) => {
      const settingMap = {
        "notification-enabled": "enabled",
        "web-notification-enabled": "webEnabled",
        "auto-request-permission": "autoRequestPermission",
        "sound-notification-enabled": "soundEnabled",
        "sound-mute": "soundMute",
        "mobile-optimized": "mobileOptimized",
        "mobile-vibrate": "mobileVibrate",
        "bark-notification-enabled": "barkEnabled",
      };

      if (settingMap[e.target.id]) {
        this.updateSetting(settingMap[e.target.id], e.target.checked);
      } else if (e.target.id === "sound-volume") {
        this.updateSetting("soundVolume", parseInt(e.target.value));
        document.querySelector(".volume-value").textContent =
          `${e.target.value}%`;
      } else if (e.target.id === "bark-url") {
        this.updateSetting("barkUrl", e.target.value);
      } else if (e.target.id === "bark-device-key") {
        this.updateSetting("barkDeviceKey", e.target.value);
      } else if (e.target.id === "bark-icon") {
        this.updateSetting("barkIcon", e.target.value);
      } else if (e.target.id === "bark-action") {
        this.updateSetting("barkAction", e.target.value);
      } else if (e.target.id === "bark-url-template") {
        this.updateSetting("barkUrlTemplate", e.target.value);
      }
    });

    window.addEventListener("notification-permission-changed", () => {
      this.updateStatus();
    });

    // feat-custom-sound (§3.4): 自定义通知音效上传/测试/清除
    this._wireCustomSoundControls();
  }

  /**
   * feat-custom-sound (§3.4): 把自定义音效相关的 3 个 control 接到
   * notificationManager 的对应方法上。
   *
   * 行为：
   *   - file picker: ``change`` → saveCustomSoundFromFile → 刷新 status
   *   - test 按钮: ``click`` → playSound('custom') 显式（无 fallback）
   *   - clear 按钮: ``click`` → clearCustomSound → 刷新 status
   *
   * 错误处理：MIME/size/decode 失败以 i18n 翻译过的字符串显示在 status 行；
   * 不弹 alert，不写 toast — 用户已经在看着 settings 面板，inline status
   * 反馈足够。
   */
  _wireCustomSoundControls() {
    const fileInput = document.getElementById("custom-sound-input");
    const testBtn = document.getElementById("custom-sound-test");
    const clearBtn = document.getElementById("custom-sound-clear");
    const statusEl = document.getElementById("custom-sound-status");
    if (!fileInput || !testBtn || !clearBtn || !statusEl) return;

    const t =
      typeof window !== "undefined" && window.AIIA_I18N && typeof window.AIIA_I18N.t === "function"
        ? window.AIIA_I18N.t
        : (k) => k;

    const refresh = () => {
      const meta = notificationManager.getCustomSoundMeta();
      if (meta) {
        const kb = Math.round((meta.size || 0) / 1024);
        statusEl.textContent = `${meta.name} (${kb} KB)`;
        statusEl.setAttribute("data-status", "uploaded");
        testBtn.disabled = false;
        clearBtn.disabled = false;
      } else {
        statusEl.textContent = t("settings.customSound.notUploaded");
        statusEl.setAttribute("data-status", "empty");
        testBtn.disabled = true;
        clearBtn.disabled = true;
      }
    };

    fileInput.addEventListener("change", async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const result = await notificationManager.saveCustomSoundFromFile(file);
      if (result.success) {
        refresh();
        // 立即播放一次让用户听到效果（同时也确认 decode 真的 OK）
        try {
          await notificationManager.playSound("custom");
        } catch (_e) {
          // 静默：上传成功 + decode 成功就够了，自动 play 失败不算 error
        }
      } else {
        const code = String(result.error || "unknown");
        let msgKey = "settings.customSound.errors.generic";
        if (code === "invalid_mime") msgKey = "settings.customSound.errors.invalidMime";
        else if (code === "too_large") msgKey = "settings.customSound.errors.tooLarge";
        else if (code === "read_failed") msgKey = "settings.customSound.errors.readFailed";
        else if (code === "storage_failed") msgKey = "settings.customSound.errors.storageFailed";
        else if (code === "decode_failed") msgKey = "settings.customSound.errors.decodeFailed";
        else if (code === "duration_too_long") msgKey = "settings.customSound.errors.durationTooLong";
        statusEl.textContent = t(msgKey);
        statusEl.setAttribute("data-status", "error");
      }
      // reset input so re-selecting the same file re-triggers ``change``
      e.target.value = "";
    });

    testBtn.addEventListener("click", () => {
      notificationManager.playSound("custom").catch(() => {});
    });

    clearBtn.addEventListener("click", () => {
      notificationManager.clearCustomSound();
      refresh();
    });

    refresh();
  }

  // ==================== 配置文件路径：用 IDE 打开按钮（TODO #4） ====================
  // 设计：先调用 /api/system/open-config-file/info 拿到当前可用的编辑器名，
  //  - 如果有可用 IDE，启用按钮并把 IDE 名写到 tooltip / 状态文案；
  //  - 如果只有 system fallback，依然启用，但提示用"系统默认应用"打开；
  //  - 完全没有可用方式时，禁用按钮并解释原因。
  // 后端只接受环回请求，所以远程访问的客户端按钮也应保持禁用且显示原因。
  async initOpenConfigFileButton() {
    const btn = document.getElementById("open-config-file-btn");
    const status = document.getElementById("open-config-file-status");
    if (!btn) return;

    const setDisabledWithReason = (reason) => {
      btn.disabled = true;
      btn.setAttribute("aria-disabled", "true");
      btn.title = reason;
      if (status) {
        status.textContent = reason;
        status.classList.remove("is-error", "is-success");
      }
    };

    try {
      const resp = await fetch("/api/system/open-config-file/info", {
        method: "GET",
        credentials: "same-origin",
      });
      if (resp.status === 403) {
        const remoteFallback =
          "Open-in-IDE is only available on the local machine running the server.";
        setDisabledWithReason(
          _tl("settings.openConfigInIdeRemoteBlocked", remoteFallback),
        );
        return;
      }
      if (!resp.ok) {
        setDisabledWithReason(
          _tl(
            "settings.openConfigInIdeUnavailable",
            "Open-in-IDE is unavailable.",
          ),
        );
        return;
      }
      const data = await resp.json();
      if (!data || data.success === false) {
        setDisabledWithReason(
          _tl(
            "settings.openConfigInIdeUnavailable",
            "Open-in-IDE is unavailable.",
          ),
        );
        return;
      }

      const editor = data.editor;
      const hasEditor = !!data.editor_available;
      const hasFallback = !!data.system_fallback_available;

      if (!hasEditor && !hasFallback) {
        const noEditorFallback =
          "No supported IDE (Cursor / VS Code / Sublime / etc.) found in PATH.";
        setDisabledWithReason(
          _tl("settings.openConfigInIdeNoEditor", noEditorFallback),
        );
        return;
      }

      btn.disabled = false;
      btn.removeAttribute("aria-disabled");
      const verb = hasEditor && editor ? editor : "system default";
      btn.title = _tl(
        "settings.openConfigInIdeReady",
        `Open with ${verb}`,
      ).replace("{editor}", verb);
      if (status) {
        status.classList.remove("is-error", "is-success");
        status.textContent = "";
      }
    } catch (e) {
      console.warn("open-config-file info fetch failed:", e);
      setDisabledWithReason(
        _tl(
          "settings.openConfigInIdeUnavailable",
          "Open-in-IDE is unavailable.",
        ),
      );
    }
  }

  async openConfigFileInIde() {
    const btn = document.getElementById("open-config-file-btn");
    const status = document.getElementById("open-config-file-status");
    const pathInput = document.getElementById("config-file-path");
    if (!btn) return;

    const originalDisabled = btn.disabled;
    btn.disabled = true;
    if (status) {
      status.classList.remove("is-error", "is-success");
      status.textContent = _tl(
        "settings.openConfigInIdeRequesting",
        "Opening…",
      );
    }

    try {
      const resp = await fetch("/api/system/open-config-file", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        // 不传 path：让后端使用它自己读到的当前配置文件路径，避免前端被篡改的输入框
        // 绕过白名单校验。如果后端有多个候选路径，这里默认使用主路径（primary）。
        body: JSON.stringify({}),
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || data.success === false) {
        const errMsg =
          (data && data.error) ||
          _tl("settings.openConfigInIdeFailed", "Failed to open config file.");
        if (status) {
          status.classList.add("is-error");
          status.textContent = errMsg;
        }
        return;
      }
      // 成功：把后端返回的实际路径回填到输入框（确保前后端视角一致）
      // BUG6：同时移除 ``data-i18n-value``，否则 i18n re-translate（语言切换或
      // ensureDefaultLocale 完成）会把真实路径覆盖回 ``page.loading`` 的翻译值。
      if (pathInput && data.path) {
        pathInput.value = data.path;
        pathInput.removeAttribute("data-i18n-value");
      }
      if (status) {
        status.classList.add("is-success");
        const editor = data.editor || "system";
        const tpl = _tl(
          "settings.openConfigInIdeOpened",
          "Opened with {editor}.",
        );
        status.textContent = tpl.replace("{editor}", editor);
      }
    } catch (e) {
      console.error("Open config file failed:", e);
      if (status) {
        status.classList.add("is-error");
        status.textContent = _tl(
          "settings.openConfigInIdeFailed",
          "Failed to open config file.",
        );
      }
    } finally {
      btn.disabled = originalDisabled;
    }
  }

  // ==================== Bark base_url 可达性诊断（TODO #3） ====================
  // 设计：Bark 通知点击后会让手机浏览器打开 ``bark_url_template`` 渲染出的
  //   URL；但若 web_ui 监听 loopback（默认 127.0.0.1）且未配 external_base_url，
  //   渲染出的 url host 会被手机解析到自身，必然打不开。本面板通过
  //   /api/system/network-base-url-status 拉取后端探测的 effective_base_url
  //   + LAN IP 推荐 + 修复建议，引导用户改 web_ui.host 或 external_base_url。
  // 容错：探测失败 / 离线时，整个诊断块隐藏，不打扰用户主流程。
  async initBarkBaseUrlStatus() {
    const item = document.getElementById("bark-base-url-status-item");
    const message = document.getElementById("bark-base-url-status-message");
    const suggestion = document.getElementById(
      "bark-base-url-status-suggestion",
    );
    const copyBtn = document.getElementById("bark-base-url-copy-btn");
    const recheckBtn = document.getElementById("bark-base-url-recheck-btn");

    if (!item || !message || !suggestion) return;

    const renderStatus = async () => {
      try {
        const resp = await fetch("/api/system/network-base-url-status", {
          method: "GET",
          credentials: "same-origin",
        });
        if (!resp.ok) {
          item.hidden = true;
          return;
        }
        const data = await resp.json();
        if (!data || data.success === false) {
          item.hidden = true;
          return;
        }

        const isLoopback = data.is_loopback === true;
        const effective = data.effective_base_url || "";
        const suggested = data.suggested_lan_base_url || "";
        const recommendation = data.recommendation || "ok";

        if (recommendation === "ok") {
          message.textContent = (
            _tl("settings.baseUrlStatusOk", "Current base_url: {url}") || ""
          ).replace("{url}", effective);
          suggestion.textContent = "";
          item.hidden = false;
          item.classList.remove("is-warning");
          item.classList.add("is-ok");
          if (copyBtn) copyBtn.hidden = true;
          return;
        }

        item.hidden = false;
        item.classList.remove("is-ok");
        item.classList.add("is-warning");

        if (isLoopback && effective) {
          message.textContent = (
            _tl(
              "settings.baseUrlStatusLoopback",
              "Current base_url is a loopback address ({url}).",
            ) || ""
          ).replace("{url}", effective);
        } else {
          message.textContent = _tl(
            "settings.baseUrlStatusUnreachable",
            "No externally reachable base_url detected.",
          );
        }

        if (suggested) {
          suggestion.textContent = _tl(
            "settings.baseUrlSuggestLan",
            "Suggested fix: copy the LAN address below into web_ui.external_base_url.",
          );
          if (copyBtn) {
            copyBtn.hidden = false;
            copyBtn.dataset.lanUrl = suggested;
            copyBtn.title = suggested;
          }
        } else {
          suggestion.textContent = _tl(
            "settings.baseUrlSuggestNoLan",
            "No usable LAN interface detected; manually set web_ui.external_base_url.",
          );
          if (copyBtn) {
            copyBtn.hidden = true;
            copyBtn.dataset.lanUrl = "";
          }
        }
      } catch (e) {
        console.warn("network-base-url-status fetch failed:", e);
        item.hidden = true;
      }
    };

    if (recheckBtn) {
      recheckBtn.addEventListener("click", () => {
        renderStatus();
      });
    }
    if (copyBtn) {
      copyBtn.addEventListener("click", async () => {
        const url = copyBtn.dataset.lanUrl || "";
        if (!url) return;
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(url);
          } else {
            const ta = document.createElement("textarea");
            ta.value = url;
            ta.style.position = "fixed";
            ta.style.opacity = "0";
            document.body.appendChild(ta);
            ta.select();
            try {
              document.execCommand("copy");
            } finally {
              document.body.removeChild(ta);
            }
          }
          const span = copyBtn.querySelector("span");
          if (span) {
            const original = span.textContent;
            span.textContent = _tl("settings.baseUrlCopied", "Copied");
            setTimeout(() => {
              span.textContent = original;
            }, 1500);
          }
        } catch (e) {
          console.warn("Copy LAN url failed:", e);
        }
      });
    }

    await renderStatus();
  }

  async showSettings() {
    // 防御性：确保已初始化（极端情况下用户可能在 init() 未完成时快速点击）
    if (!this.initialized) {
      try {
        await this.init();
      } catch (e) {
        console.warn(
          "SettingsManager init failed while opening settings panel:",
          e,
        );
      }
    }

    const panel = document.getElementById("settings-panel");
    if (panel) {
      const container = document.querySelector(".container");
      if (container) {
        container.style.overflow = "visible";
        this._setContainerSiblingsInert(panel, true);
      }

      panel.classList.remove("hidden");
      panel.style.display = "flex";

      this.applySettingsTheme();

      this._settingsEscHandler = (e) => {
        if (e.key === "Escape") {
          this.hideSettings();
          return;
        }
        if (e.key === "Tab") this._settingsFocusTrap(panel, e);
      };
      document.addEventListener("keydown", this._settingsEscHandler);

      const firstFocusable = panel.querySelector(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
      );
      if (firstFocusable) setTimeout(() => firstFocusable.focus(), 50);
    }

    // 每次打开设置面板都从后端刷新一次配置
    // 目的：
    // - 让“外部编辑 config.jsonc”能在不刷新页面的情况下反映到 UI
    // - 避免打开面板时把旧的本地缓存配置反向写回后端（覆盖外部修改）
    try {
      this.settings = await this.loadSettings();
    } catch (e) {
      console.warn("Refresh settings on open failed; keeping current:", e);
    }
    try {
      this.feedbackConfig = await this.loadFeedbackConfig();
    } catch (e) {
      console.warn("Refresh feedback config on open failed:", e);
    }

    this.updateUI();
    this.updateFeedbackUI();
    this.updateStatus();
  }

  applySettingsTheme() {
    const theme = document.documentElement.getAttribute("data-theme");

    // 动态注入浅色主题样式（解决 CSS 优先级问题）
    if (!document.getElementById("settings-light-theme-styles")) {
      const style = document.createElement("style");
      style.id = "settings-light-theme-styles";
      style.textContent = `
        [data-theme="light"] .settings-panel {
          background: rgba(0, 0, 0, 0.7) !important;
        }
        [data-theme="light"] .settings-content {
          background: #faf9f5 !important;
          border: 1px solid rgba(0, 0, 0, 0.12) !important;
          box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2), 0 10px 20px rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .settings-body {
          background: #faf9f5 !important;
        }
        [data-theme="light"] .setting-group {
          background: #ffffff !important;
          border: 1px solid rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .setting-subgroup {
          background: #f8f8f5 !important;
        }
        [data-theme="light"] .settings-header {
          border-bottom: 1px solid rgba(0, 0, 0, 0.1) !important;
          background: #f2f1ec !important;
        }
        [data-theme="light"] .status-row {
          background: rgba(0, 0, 0, 0.02) !important;
          border-color: rgba(0, 0, 0, 0.08) !important;
          color: #141413 !important;
        }
        [data-theme="light"] .status-row span:first-child {
          color: rgba(20, 20, 19, 0.85) !important;
        }
        [data-theme="light"] .status-row span:last-child {
          color: #141413 !important;
        }
        [data-theme="light"] .setting-description {
          color: rgba(20, 20, 19, 0.65) !important;
        }
        [data-theme="light"] .setting-item:hover .setting-description {
          color: rgba(20, 20, 19, 0.75) !important;
        }
        [data-theme="light"] .setting-label:hover .setting-title {
          color: rgba(20, 20, 19, 0.9) !important;
        }
        [data-theme="light"] .setting-input::placeholder {
          color: rgba(20, 20, 19, 0.5) !important;
        }
        [data-theme="light"] .setting-label,
        [data-theme="light"] .setting-title,
        [data-theme="light"] .setting-subgroup-title,
        [data-theme="light"] .settings-main-title,
        [data-theme="light"] .setting-group-title,
        [data-theme="light"] #settings-title {
          color: #141413 !important;
        }
        [data-theme="light"] .settings-main-title {
          border-bottom-color: rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .setting-group::before {
          background: linear-gradient(90deg, transparent, rgba(0, 0, 0, 0.08), transparent) !important;
        }
        [data-theme="light"] .setting-group-title {
          -webkit-text-fill-color: #141413 !important;
          background: none !important;
          border-bottom-color: rgba(0, 0, 0, 0.1) !important;
        }
        [data-theme="light"] .setting-input {
          background: #ffffff !important;
          border-color: rgba(0, 0, 0, 0.15) !important;
          color: #141413 !important;
        }
        [data-theme="light"] .setting-select {
          background: #ffffff !important;
          border-color: rgba(0, 0, 0, 0.15) !important;
          color: #141413 !important;
        }
      `;
      document.head.appendChild(style);
    }
  }

  /**
   * R244: iterate `.container > *`, set inert on every child except
   * the open dialog. See app.js `_setContainerSiblingsInert` doc for
   * the full rationale (R240 was buggy — dialog inside .container
   * inherited inert and became uninteractive).
   *
   * @param {HTMLElement} openModalEl - dialog that stays interactive
   * @param {boolean} value - true to inert siblings, false to clear
   */
  _setContainerSiblingsInert(openModalEl, value) {
    const container = document.querySelector(".container");
    if (!container) return;
    for (const child of container.children) {
      if (child === openModalEl) continue;
      this._safelySetInert(child, value);
    }
  }

  _safelySetInert(el, value) {
    if (!el) return;
    try {
      el.inert = value;
    } catch (_e) {
      if (value) {
        el.setAttribute("inert", "");
      } else {
        el.removeAttribute("inert");
      }
    }
  }

  _settingsFocusTrap(panel, event) {
    if (!panel) return;
    const focusables = panel.querySelectorAll(
      'button:not([disabled]),[href],input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',
    );
    const visible = Array.prototype.filter.call(
      focusables,
      (el) => el.offsetParent !== null && !el.hasAttribute("aria-hidden"),
    );
    if (visible.length === 0) return;
    const first = visible[0];
    const last = visible[visible.length - 1];
    const active = document.activeElement;
    if (event.shiftKey && active === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  }

  hideSettings() {
    const panel = document.getElementById("settings-panel");
    if (panel) {
      const container = document.querySelector(".container");
      if (container) {
        container.style.overflow = "";
        this._setContainerSiblingsInert(panel, false);
      }

      panel.classList.add("hidden");
      panel.style.display = "none";
    }

    if (this._settingsEscHandler) {
      document.removeEventListener("keydown", this._settingsEscHandler);
      this._settingsEscHandler = null;
    }

    const settingsBtn = document.getElementById("settings-btn");
    if (settingsBtn) settingsBtn.focus();
  }

  async testNotification() {
    try {
      await notificationManager.sendNotification(
        t("notify.testTitle"),
        t("notify.testBody"),
        {
          tag: "settings-test",
          requireInteraction: false,
        },
      );
      showStatus(t("status.testSent"), "success");
    } catch (error) {
      console.error("Test notification failed:", error);
      showStatus(t("status.testFailed") + ": " + error.message, "error");
    }
  }

  async testBarkNotification() {
    try {
      if (!this.settings.barkEnabled) {
        showStatus(t("status.enableBarkFirst"), "warning");
        return;
      }

      if (!this.settings.barkUrl || !this.settings.barkDeviceKey) {
        showStatus(t("status.configureBark"), "warning");
        return;
      }

      // 显示发送中状态
      showStatus(t("status.sendingBark"), "info");

      // 通过后端API发送Bark通知，避免CORS问题
      const response = await fetch("/api/test-bark", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          bark_url: this.settings.barkUrl,
          bark_device_key: this.settings.barkDeviceKey,
          bark_icon: this.settings.barkIcon,
          bark_action: this.settings.barkAction,
          bark_url_template:
            this.settings.barkUrlTemplate ||
            this.defaultSettings.barkUrlTemplate,
        }),
      });

      const result = await response.json();

      if (response.ok && result.status === "success") {
        showStatus(result.message, "success");
        console.debug("Bark notification sent:", result);
      } else {
        showStatus(result.message || t("status.barkFailed"), "error");
        console.error("Bark notification send failed:", result);
      }
    } catch (error) {
      console.error("Bark test notification failed:", error);
      showStatus(
        t("status.barkTestFailed", { reason: error.message }),
        "error",
      );
    }
  }

  async loadFeedbackConfig() {
    try {
      const resp = await fetch("/api/get-feedback-prompts", {
        cache: "no-store",
      });
      if (resp.ok) {
        const data = await resp.json();
        if (data.status === "success" && data.config) {
          return {
            frontend_countdown: data.config.frontend_countdown ?? 240,
            resubmit_prompt: data.config.resubmit_prompt ?? "",
            prompt_suffix: data.config.prompt_suffix ?? "",
          };
        }
      }
    } catch (e) {
      console.warn("Load feedback config failed:", e);
    }
    return { frontend_countdown: 240, resubmit_prompt: "", prompt_suffix: "" };
  }

  updateFeedbackUI() {
    const fc = this.feedbackConfig || {};
    const countdownEl = document.getElementById("feedback-countdown");
    const promptEl = document.getElementById("feedback-resubmit-prompt");
    const suffixEl = document.getElementById("feedback-prompt-suffix");
    if (countdownEl) countdownEl.value = fc.frontend_countdown ?? 240;
    if (promptEl) promptEl.value = fc.resubmit_prompt ?? "";
    if (suffixEl) suffixEl.value = fc.prompt_suffix ?? "";
  }

  async saveFeedbackConfig(updates) {
    try {
      _suppressConfigChangedEchoIfAvailable();
      const resp = await fetch("/api/update-feedback-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      const data = await resp.json();
      if (resp.ok && data.status === "success") {
        Object.assign(this.feedbackConfig, updates);
        showStatus(t("settings.feedbackConfigSaved"), "success");
      } else {
        showStatus(
          data.message || t("settings.feedbackConfigSaveFailed"),
          "error",
        );
      }
    } catch (e) {
      console.error("Save feedback config failed:", e);
      showStatus(t("settings.feedbackConfigSaveFailed"), "error");
    }
  }

  async resetFeedbackConfig() {
    // 真源：调用后端 /api/reset-feedback-config，避免前端硬编码中文默认值。
    // 若后端不可用，回退到重新读取当前配置；不再吞掉错误，好让用户知道发生了什么。
    try {
      _suppressConfigChangedEchoIfAvailable();
      const resp = await fetch("/api/reset-feedback-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok || data.status !== "success") {
        showStatus(
          data.message || t("settings.feedbackConfigSaveFailed"),
          "error",
        );
        return;
      }
      if (data.defaults && typeof data.defaults === "object") {
        Object.assign(
          this.feedbackConfig || (this.feedbackConfig = {}),
          data.defaults,
        );
      } else {
        this.feedbackConfig = await this.loadFeedbackConfig();
      }
    } catch (e) {
      console.error("Reset feedback config failed:", e);
      showStatus(t("settings.feedbackConfigSaveFailed"), "error");
      return;
    }
    this.updateFeedbackUI();
    showStatus(t("settings.feedbackConfigReset"), "success");
  }
}

// 创建全局设置管理器实例
const settingsManager = new SettingsManager();
