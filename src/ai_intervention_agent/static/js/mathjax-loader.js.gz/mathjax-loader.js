window.MathJax = {
  tex: {
    inlineMath: [
      ['$', '$'],
      ['\\(', '\\)']
    ],
    displayMath: [
      ['$$', '$$'],
      ['\\[', '\\]']
    ],
    processEscapes: true,
    processEnvironments: true,
    packages: { '[+]': ['ams', 'newcommand', 'configmacros'] },
    tags: 'ams'
  },
  options: {
    skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code'],
    ignoreHtmlClass: 'tex2jax_ignore',
    processHtmlClass: 'tex2jax_process'
  },
  startup: {
    ready: () => {
      console.debug('MathJax loaded')
      MathJax.startup.defaultReady()
      if (window._mathJaxPendingElements) {
        const pendingElements = window._mathJaxPendingElements
        const pendingElementCount = pendingElements.length
        for (let index = 0; index < pendingElementCount; index += 1) {
          if (!(index in pendingElements)) continue
          const el = pendingElements[index]
          MathJax.typesetPromise([el]).catch(err => console.warn('MathJax render failed:', err))
        }
        window._mathJaxPendingElements = []
      }
    }
  }
}

window._mathJaxLoading = false
window._mathJaxLoaded = false
window._mathJaxPendingElements = []

window.protectMathDelimiters = function (text) {
  if (
    typeof text !== 'string' ||
    (text.indexOf('\\(') === -1 && text.indexOf('\\[') === -1)
  ) {
    return { text, segments: [] }
  }
  const segments = []
  const protectedText = text.replace(

    /(```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$)|`[^`\n]*`)|(\\\([\s\S]+?\\\)|\\\[[\s\S]+?\\\])/g,
    (match, code, math) => {
      if (code) return code
      const index = segments.push(math) - 1
      return '%%AIIA_MATH_SLOT_' + index + '%%'
    }
  )
  return { text: protectedText, segments }
}

window.restoreMathDelimiters = function (html, segments) {
  if (typeof html !== 'string' || !segments || segments.length === 0) {
    return html
  }
  return html.replace(/%%AIIA_MATH_SLOT_(\d+)%%/g, (match, rawIndex) => {
    const segment = segments[Number(rawIndex)]
    if (segment === undefined) return match
    return segment
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
  })
}

window.hasMathContent = function (text) {
  if (!text) return false

  const mathPatterns = [
    /\$[^$]+\$/,
    /\$\$[^$]+\$\$/,
    /\\\([^)]+\\\)/,
    /\\\[[^\]]+\\\]/
  ]
  return mathPatterns.some(pattern => pattern.test(text))
}

window.loadMathJaxIfNeeded = function (element, text) {

  if (!window.hasMathContent(text)) {
    return
  }

  if (window._mathJaxLoaded && window.MathJax && window.MathJax.typesetPromise) {
    MathJax.typesetPromise([element]).catch(err => console.warn('MathJax render failed:', err))
    return
  }

  window._mathJaxPendingElements.push(element)

  if (window._mathJaxLoading) {
    return
  }

  window._mathJaxLoading = true
  console.debug('MathJax: math content detected, loading MathJax (~1.17MB)…')

  const script = document.createElement('script')
  script.id = 'MathJax-script'
  script.async = true
  script.src = '/static/js/tex-mml-chtml.js'
  script.onload = function () {
    window._mathJaxLoaded = true
    console.debug('MathJax script loaded')
  }
  script.onerror = function () {
    console.error('MathJax script load failed')
    window._mathJaxLoading = false
  }
  document.head.appendChild(script)
}
