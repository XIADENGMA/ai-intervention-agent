const KeyboardShortcuts = (function () {
  'use strict';

  const MODIFIER_KEYS = {
    ctrl: 'ctrlKey',
    alt: 'altKey',
    shift: 'shiftKey',
    meta: 'metaKey',
    cmd: 'metaKey',
    command: 'metaKey',
    option: 'altKey'
  };

  const KEY_ALIASES = {
    'esc': 'Escape',
    'escape': 'Escape',
    'enter': 'Enter',
    'return': 'Enter',
    'space': ' ',
    'spacebar': ' ',
    'up': 'ArrowUp',
    'down': 'ArrowDown',
    'left': 'ArrowLeft',
    'right': 'ArrowRight',
    'delete': 'Delete',
    'del': 'Delete',
    'backspace': 'Backspace',
    'tab': 'Tab',
    'home': 'Home',
    'end': 'End',
    'pageup': 'PageUp',
    'pagedown': 'PageDown'
  };

  const IGNORED_ELEMENTS = ['INPUT', 'TEXTAREA', 'SELECT'];

  const shortcuts = new Map();

  let initialized = false;

  function parseShortcut(shortcut) {
    const normalized = shortcut.toLowerCase();
    const modifiers = new Set();
    let key = '';

    for (let start = 0, i = 0; i <= normalized.length; i += 1) {
      if (i < normalized.length && normalized.charCodeAt(i) !== 43) continue;
      const part = normalized.slice(start, i).trim();
      start = i + 1;
      if (MODIFIER_KEYS[part]) {
        modifiers.add(MODIFIER_KEYS[part]);
      } else {
        key = KEY_ALIASES[part] || part;
      }
    }

    return { modifiers, key };
  }

  function normalizeKeyForId(key) {
    const normalized = String(key || '').toLowerCase();
    const aliased = KEY_ALIASES[normalized] || normalized;
    if (aliased === ' ') return 'space';
    return String(aliased).toLowerCase();
  }

  function buildShortcutId(modifiers, key) {
    const parts = [];
    if (modifiers.has('ctrlKey')) parts.push('ctrl');
    if (modifiers.has('altKey')) parts.push('alt');
    if (modifiers.has('shiftKey')) parts.push('shift');
    if (modifiers.has('metaKey')) parts.push('meta');
    parts.push(normalizeKeyForId(key));
    return parts.join('+');
  }

  function getShortcutId(event) {
    const parts = [];

    if (event.ctrlKey) parts.push('ctrl');
    if (event.altKey) parts.push('alt');
    if (event.shiftKey) parts.push('shift');
    if (event.metaKey) parts.push('meta');

    parts.push(normalizeKeyForId(event.key));

    return parts.join('+');
  }

  function getActiveTaskTabIndex(tabs) {
    for (let i = 0; i < tabs.length; i += 1) {
      if (tabs[i].classList.contains('active')) {
        return i;
      }
    }
    return -1;
  }

  function shouldIgnore(event, options) {

    if (!options.allowInInputs) {
      const target = event.target;
      if (!target) {
        return false;
      }
      const tagName = typeof target.tagName === 'string' ? target.tagName.toUpperCase() : '';
      if (IGNORED_ELEMENTS.includes(tagName)) {
        return true;
      }
      if (target.isContentEditable) {
        return true;
      }
    }
    return false;
  }

  function handleKeydown(event) {
    const id = getShortcutId(event);
    const shortcutData = shortcuts.get(id);

    if (!shortcutData) return;

    const { callback, options } = shortcutData;

    if (shouldIgnore(event, options)) return;

    if (options.preventDefault) {
      event.preventDefault();
    }

    if (options.stopPropagation) {
      event.stopPropagation();
    }

    try {
      callback(event);
    } catch (error) {
      console.error(`[KeyboardShortcuts] Error while executing shortcut "${id}":`, error);
    }
  }

  return {

    init: function () {
      if (initialized) return;

      document.addEventListener('keydown', handleKeydown);
      initialized = true;

      this.registerDefaults();

      console.debug('[KeyboardShortcuts] initialized');
    },

    register: function (shortcut, callback, options = {}) {
      const defaultOptions = {
        preventDefault: true,
        stopPropagation: false,
        allowInInputs: false
      };

      const mergedOptions = { ...defaultOptions, ...options };
      const { modifiers, key } = parseShortcut(shortcut);
      const id = buildShortcutId(modifiers, key);

      if (shortcuts.has(id)) {
        console.warn(`[KeyboardShortcuts] Shortcut "${shortcut}" already exists, will be overridden`);
      }

      shortcuts.set(id, { callback, options: mergedOptions });
      console.debug(`[KeyboardShortcuts] registered: ${id}`);
    },

    unregister: function (shortcut) {
      const { modifiers, key } = parseShortcut(shortcut);
      const id = buildShortcutId(modifiers, key);

      if (shortcuts.delete(id)) {
        console.debug(`[KeyboardShortcuts] unregistered: ${id}`);
      }
    },

    registerDefaults: function () {

      this.register('escape', () => {

        const settingsPanel = document.getElementById('settings-panel');
        if (settingsPanel && settingsPanel.classList.contains('show')) {
          if (
            typeof settingsManager !== 'undefined' &&
            settingsManager &&
            typeof settingsManager.hideSettings === 'function'
          ) {
            settingsManager.hideSettings();
          } else {

            settingsPanel.classList.remove('show');
            settingsPanel.classList.add('hidden');
          }
          return;
        }

        const imageModal = document.getElementById('image-modal');
        if (imageModal && imageModal.classList.contains('show')) {
          if (typeof closeImageModal === 'function') {
            closeImageModal();
          } else {

            imageModal.classList.remove('show');
          }
          return;
        }
      });

      const submitShortcut = navigator.platform.includes('Mac') ? 'meta+enter' : 'ctrl+enter';
      this.register(submitShortcut, () => {
        const submitBtn = document.getElementById('submit-btn');
        if (submitBtn && !submitBtn.disabled) {
          submitBtn.click();
        }
      }, { allowInInputs: true });

      const helpShortcut = navigator.platform.includes('Mac') ? 'meta+/' : 'ctrl+/';
      this.register(helpShortcut, () => {
        this.showHelp();
      });

      const settingsShortcut = navigator.platform.includes('Mac') ? 'meta+,' : 'ctrl+,';
      this.register(settingsShortcut, () => {
        const settingsBtn = document.getElementById('settings-btn');
        if (settingsBtn) settingsBtn.click();
      });

      this.register('t', () => {
        if (typeof ThemeManager !== 'undefined') {
          ThemeManager.toggle();
        }
      });

      this.register('tab', (event) => {
        const tabs = document.querySelectorAll('.task-tab:not(.hidden)');
        if (tabs.length > 1) {
          event.preventDefault();
          const currentIndex = getActiveTaskTabIndex(tabs);
          const nextIndex = (currentIndex + 1) % tabs.length;
          tabs[nextIndex].click();
        }
      });

      this.register('shift+tab', (event) => {
        const tabs = document.querySelectorAll('.task-tab:not(.hidden)');
        if (tabs.length > 1) {
          event.preventDefault();
          const currentIndex = getActiveTaskTabIndex(tabs);
          const prevIndex = (currentIndex - 1 + tabs.length) % tabs.length;
          tabs[prevIndex].click();
        }
      });
    },

    showHelp: function () {

      if (
        typeof window !== 'undefined' &&
        window.AIIA_KEYBOARD_SHORTCUT_HELP &&
        typeof window.AIIA_KEYBOARD_SHORTCUT_HELP.showOverlay === 'function'
      ) {
        try {
          window.AIIA_KEYBOARD_SHORTCUT_HELP.showOverlay();
          return;
        } catch (_e) {

        }
      }

      const isMac = navigator.platform.includes('Mac');
      const mod = isMac ? '⌘' : 'Ctrl';

      const t = (key, params) => window.AIIA_I18N ? window.AIIA_I18N.t(key, params) : key;
      const helpText = [
        '╔══════════════════════════════════════╗',
        `║  ${t('shortcuts.helpTitle')}  ║`.padEnd(42, ' ') + '║',
        '╠══════════════════════════════════════╣',
        `║  ${mod}+Enter    ${t('shortcuts.submitFeedback')}`,
        `║  ${mod}+,        ${t('shortcuts.openSettings')}`,
        `║  ${mod}+/        ${t('shortcuts.showHelp')}`,
        `║  T             ${t('shortcuts.toggleTheme')}`,
        `║  Tab           ${t('shortcuts.nextTask')}`,
        `║  Shift+Tab     ${t('shortcuts.prevTask')}`,
        `║  Escape        ${t('shortcuts.closeModal')}`,
        '╚══════════════════════════════════════╝'
      ].join('\n');

      console.debug(helpText);

      if (typeof notificationManager !== 'undefined') {
        notificationManager.sendNotification(
          t('shortcuts.notifyTitle'),
          t('shortcuts.notifyBody', { mod }),
          { tag: 'keyboard-help', requireInteraction: false }
        );
      }
    },

    getAll: function () {
      return new Map(shortcuts);
    },

    destroy: function () {
      document.removeEventListener('keydown', handleKeydown);
      shortcuts.clear();
      initialized = false;
      console.debug('[KeyboardShortcuts] destroyed');
    }
  };
})();

if (typeof window !== 'undefined') {
  window.KeyboardShortcuts = KeyboardShortcuts;
}

document.addEventListener('DOMContentLoaded', () => {
  KeyboardShortcuts.init();
});

if (typeof module !== 'undefined' && module.exports) {
  module.exports = KeyboardShortcuts;
}
