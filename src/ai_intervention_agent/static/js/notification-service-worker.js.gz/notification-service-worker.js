const STATIC_CACHE_NAME = 'aiia-static-v2'

const OFFLINE_CACHE_NAME = 'aiia-offline-v1'
const OFFLINE_FALLBACK_URL = '/offline.html'

const MAX_ENTRIES = 200

const CACHE_FIRST_PATTERNS = [
  /^\/static\/css\//,
  /^\/static\/js\//,
  /^\/static\/lottie\//,
  /^\/static\/locales\//,
  /^\/static\/images\//,
  /^\/icons\//,
  /^\/sounds\//,
  /^\/fonts\//,
  /^\/manifest\.webmanifest$/
]

self.addEventListener('install', event => {
  event.waitUntil(
    (async () => {

      try {
        const cache = await caches.open(OFFLINE_CACHE_NAME)
        const offlineResponse = await fetch(OFFLINE_FALLBACK_URL, {
          cache: 'reload'
        })
        if (offlineResponse && offlineResponse.ok) {
          await cache.put(OFFLINE_FALLBACK_URL, offlineResponse.clone())
        }
      } catch (_e) {

      }

      try {
        await self.skipWaiting()
      } catch (_e) {

      }
    })()
  )
})

self.addEventListener('activate', event => {
  event.waitUntil(
    (async () => {

      try {
        const cacheNames = await caches.keys()
        const deletions = []
        for (const name of cacheNames) {
          if (
            typeof name === 'string' &&
            ((name.startsWith('aiia-static-') &&
              name !== STATIC_CACHE_NAME) ||
              (name.startsWith('aiia-offline-') &&
                name !== OFFLINE_CACHE_NAME))
          ) {
            deletions.push(caches.delete(name).catch(() => false))
          }
        }
        await Promise.all(deletions)
      } catch (e) {

      }

      try {
        await self.clients.claim()
      } catch (e) {

      }
    })()
  )
})

self.addEventListener('fetch', event => {
  const request = event.request

  if (request.method !== 'GET') return

  let url
  try {
    url = new URL(request.url)
  } catch (e) {
    return
  }
  if (url.origin !== self.location.origin) return

  const acceptHeader = request.headers.get('Accept') || ''
  if (acceptHeader.includes('text/event-stream')) return

  if (request.mode === 'navigate') {
    event.respondWith(handleNavigationWithOfflineFallback(request))
    return
  }

  if (!CACHE_FIRST_PATTERNS.some(re => re.test(url.pathname))) return

  event.respondWith(handleCacheFirst(request, event))
})

async function handleNavigationWithOfflineFallback(request) {
  try {
    const networkResponse = await fetch(request)
    return networkResponse
  } catch (_e) {

    try {
      const cache = await caches.open(OFFLINE_CACHE_NAME)
      const offlineFallback = await cache.match(OFFLINE_FALLBACK_URL)
      if (offlineFallback) return offlineFallback
    } catch (_e2) {

    }
    return makeOfflineResponse(request)
  }
}

async function handleCacheFirst(request, event) {
  let cache
  try {
    cache = await caches.open(STATIC_CACHE_NAME)
  } catch (e) {

    return fetch(request).catch(() => makeOfflineResponse(request))
  }

  try {
    const cached = await cache.match(request)
    if (cached) {
      const refreshPromise = refreshStaticCache(request, cache)
      if (event && typeof event.waitUntil === 'function') {
        event.waitUntil(refreshPromise)
      }
      return cached
    }
  } catch (e) {

  }

  let networkResponse
  try {
    networkResponse = await fetch(request)
  } catch (e) {

    try {
      const stale = await cache.match(request)
      if (stale) return stale
    } catch (_e) {

    }
    return makeOfflineResponse(request)
  }

  maybeCacheStaticResponse(request, cache, networkResponse).catch(() => {})

  return networkResponse
}

async function refreshStaticCache(request, cache) {
  try {
    const networkResponse = await fetch(request)
    await maybeCacheStaticResponse(request, cache, networkResponse)
  } catch (_e) {

  }
}

async function maybeCacheStaticResponse(request, cache, networkResponse) {

  if (
    networkResponse &&
    networkResponse.ok &&
    networkResponse.status === 200 &&
    (networkResponse.type === 'basic' || networkResponse.type === 'default')
  ) {

    const responseClone = networkResponse.clone()
    await cache.put(request, responseClone).then(
      () => {
        trimCache(cache).catch(() => {})
      },
      () => {

      }
    )
  }
}

function makeOfflineResponse(request) {
  return new Response('', {
    status: 503,
    statusText: 'Service Unavailable (offline)',
    headers: { 'Content-Type': 'text/plain', 'X-AIIA-SW-Offline': '1' }
  })
}

async function trimCache(cache) {
  let keys
  try {
    keys = await cache.keys()
  } catch (e) {
    return
  }
  if (!Array.isArray(keys) || keys.length <= MAX_ENTRIES) return

  const deletions = []
  const overflowCount = keys.length - MAX_ENTRIES
  for (let i = 0; i < overflowCount; i += 1) {
    deletions.push(cache.delete(keys[i]).catch(() => false))
  }
  await Promise.all(deletions)
}

self.addEventListener('notificationclick', event => {
  event.notification.close()

  const data = event.notification.data || {}
  const targetUrl = typeof data.url === 'string' && data.url ? data.url : '/'

  event.waitUntil(
    (async () => {
      const absoluteTargetUrl = new URL(targetUrl, self.location.origin).toString()
      const targetPathname = new URL(absoluteTargetUrl).pathname
      const windowClients = await self.clients.matchAll({
        type: 'window',
        includeUncontrolled: true
      })

      for (const client of windowClients) {
        try {
          const clientUrl = new URL(client.url, self.location.origin)
          if (
            client.url === absoluteTargetUrl ||
            clientUrl.pathname === targetPathname
          ) {
            if ('focus' in client) {
              await client.focus()
            }
            return
          }
        } catch (error) {

        }
      }

      if (self.clients.openWindow) {
        await self.clients.openWindow(absoluteTargetUrl)
      }
    })()
  )
})
