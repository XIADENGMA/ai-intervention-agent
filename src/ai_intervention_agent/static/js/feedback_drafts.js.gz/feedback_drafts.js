(function () {
  "use strict";

  const STORAGE_KEY = "aiia.feedbackDrafts.v1";
  const SCHEMA_VERSION = 1;
  const TARGET_ID = "feedback-text";
  const TTL_MS = 7 * 24 * 60 * 60 * 1000;
  const MAX_DRAFTS = 50;
  const INPUT_DEBOUNCE_MS = 500;
  const SYNC_INTERVAL_MS = 30 * 1000;

  let inputHandle = null;
  let inputDebounceTimerId = null;
  let periodicSyncIntervalId = null;
  let lifecycleListenersInstalled = false;

  function _now() {
    return Date.now();
  }

  function _isStorageAvailable() {
    try {
      const probe = "__aiia_drafts_probe__";
      localStorage.setItem(probe, "1");
      localStorage.removeItem(probe);
      return true;
    } catch (_e) {
      return false;
    }
  }

  function _readEnvelope() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      if (parsed.schema_version !== SCHEMA_VERSION) return null;
      const drafts = parsed.drafts;
      if (!drafts || typeof drafts !== "object") return null;
      return drafts;
    } catch (_e) {
      return null;
    }
  }

  function _writeEnvelope(drafts) {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          schema_version: SCHEMA_VERSION,
          drafts: drafts,
          saved_at: _now(),
        }),
      );
      return true;
    } catch (_e) {

      return false;
    }
  }

  function _normalizeDraft(entry) {
    if (!entry || typeof entry !== "object") return null;
    const text = entry.text;
    if (typeof text !== "string") return null;
    const savedAt =
      typeof entry.saved_at === "number" && Number.isFinite(entry.saved_at)
        ? entry.saved_at
        : 0;
    return { text: text, saved_at: savedAt };
  }

  function _applyTtlAndLru(drafts) {
    const result = {};
    const fresh = [];
    const cutoff = _now() - TTL_MS;
    for (const taskId in drafts) {
      if (!Object.prototype.hasOwnProperty.call(drafts, taskId)) continue;
      const norm = _normalizeDraft(drafts[taskId]);
      if (norm === null) continue;
      if (norm.saved_at < cutoff) continue;
      fresh.push({ taskId: taskId, draft: norm });
    }
    fresh.sort(function (a, b) {
      return b.draft.saved_at - a.draft.saved_at;
    });
    const kept = fresh.slice(0, MAX_DRAFTS);
    for (let i = 0; i < kept.length; i++) {
      result[kept[i].taskId] = kept[i].draft;
    }
    return result;
  }

  function loadAllDrafts() {
    const drafts = _readEnvelope();
    if (drafts === null) return {};
    return _applyTtlAndLru(drafts);
  }

  function getDraft(taskId) {
    if (typeof taskId !== "string" || !taskId) return null;
    const all = loadAllDrafts();
    if (!Object.prototype.hasOwnProperty.call(all, taskId)) return null;
    return all[taskId].text;
  }

  function saveDraft(taskId, text) {
    if (typeof taskId !== "string" || !taskId) return false;
    if (typeof text !== "string") return false;
    if (!_isStorageAvailable()) return false;
    const drafts = _readEnvelope() || {};
    if (text === "") {
      delete drafts[taskId];
    } else {
      drafts[taskId] = { text: text, saved_at: _now() };
    }
    const trimmed = _applyTtlAndLru(drafts);
    return _writeEnvelope(trimmed);
  }

  function clearDraft(taskId) {
    return saveDraft(taskId, "");
  }

  function clearAllDrafts() {
    if (!_isStorageAvailable()) return false;
    try {
      localStorage.removeItem(STORAGE_KEY);
      return true;
    } catch (_e) {
      return false;
    }
  }

  function hydrateMemoryCache() {
    const drafts = loadAllDrafts();
    if (typeof window === "undefined") return 0;
    if (typeof window.taskTextareaContents !== "object" ||
        window.taskTextareaContents === null) {
      window.taskTextareaContents = {};
    }
    let hydrated = 0;
    for (const taskId in drafts) {
      if (!Object.prototype.hasOwnProperty.call(drafts, taskId)) continue;
      if (Object.prototype.hasOwnProperty.call(
        window.taskTextareaContents,
        taskId,
      )) {
        continue;
      }
      window.taskTextareaContents[taskId] = drafts[taskId].text;
      hydrated += 1;
    }
    return hydrated;
  }

  function reconcileMemoryToStorage() {
    if (typeof window === "undefined") return false;
    const memoryDrafts = window.taskTextareaContents;
    if (typeof memoryDrafts !== "object" || memoryDrafts === null) {
      return false;
    }
    const existing = _readEnvelope() || {};
    const merged = {};

    for (const taskId in memoryDrafts) {
      if (!Object.prototype.hasOwnProperty.call(memoryDrafts, taskId)) continue;
      const text = memoryDrafts[taskId];
      if (typeof text !== "string" || text === "") continue;
      const prev = _normalizeDraft(existing[taskId]);
      const savedAt = prev !== null && prev.text === text
        ? prev.saved_at
        : _now();
      merged[taskId] = { text: text, saved_at: savedAt };
    }
    const trimmed = _applyTtlAndLru(merged);
    return _writeEnvelope(trimmed);
  }

  function _getActiveTaskId() {
    if (typeof window === "undefined") return null;
    const id = window.activeTaskId;
    if (typeof id !== "string" || !id) return null;
    return id;
  }

  function setupInputListener() {
    const textarea = document.getElementById(TARGET_ID);
    if (inputHandle !== null) {
      if (inputHandle.textarea === textarea) return inputHandle;
      if (inputHandle.textarea.removeEventListener) {
        inputHandle.textarea.removeEventListener("input", inputHandle.handler);
      }
      inputHandle = null;
      if (inputDebounceTimerId && typeof clearTimeout === "function") {
        clearTimeout(inputDebounceTimerId);
      }
      inputDebounceTimerId = null;
    }
    if (!textarea) return null;
    const handler = function () {
      if (inputDebounceTimerId) clearTimeout(inputDebounceTimerId);
      inputDebounceTimerId = setTimeout(function () {
        inputDebounceTimerId = null;
        const taskId = _getActiveTaskId();
        if (taskId === null) return;
        saveDraft(taskId, textarea.value || "");
      }, INPUT_DEBOUNCE_MS);
    };
    textarea.addEventListener("input", handler);
    inputHandle = { textarea: textarea, handler: handler };
    return inputHandle;
  }

  function flushActiveTextareaDraft() {
    if (inputDebounceTimerId && typeof clearTimeout === "function") {
      clearTimeout(inputDebounceTimerId);
      inputDebounceTimerId = null;
    }
    const taskId = _getActiveTaskId();
    if (taskId === null) return false;
    let textarea =
      typeof document !== "undefined" ? document.getElementById(TARGET_ID) : null;
    if (!textarea && inputHandle && inputHandle.textarea) textarea = inputHandle.textarea;
    if (!textarea) return false;
    const text = textarea.value || "";
    if (typeof window !== "undefined") {
      if (
        typeof window.taskTextareaContents !== "object" ||
        window.taskTextareaContents === null
      ) {
        window.taskTextareaContents = {};
      }
      window.taskTextareaContents[taskId] = text;
    }
    return saveDraft(taskId, text);
  }

  function setupPeriodicSync() {
    if (periodicSyncIntervalId !== null) return periodicSyncIntervalId;
    if (typeof setInterval !== "function") return null;
    periodicSyncIntervalId = setInterval(
      reconcileMemoryToStorage,
      SYNC_INTERVAL_MS,
    );
    return periodicSyncIntervalId;
  }

  function stopPeriodicSync() {
    if (periodicSyncIntervalId === null) return false;
    if (typeof clearInterval === "function") {
      clearInterval(periodicSyncIntervalId);
    }
    periodicSyncIntervalId = null;
    return true;
  }

  function flushDraftsForPageExit() {
    reconcileMemoryToStorage();
    return flushActiveTextareaDraft();
  }

  function handleVisibilityChange() {
    if (typeof document === "undefined") return;
    if (document.hidden) {
      flushDraftsForPageExit();
      stopPeriodicSync();
      return;
    }
    hydrateMemoryCache();
    setupPeriodicSync();
  }

  function setupLifecycleListeners() {
    if (lifecycleListenersInstalled) return false;
    lifecycleListenersInstalled = true;
    if (
      typeof document !== "undefined" &&
      typeof document.addEventListener === "function"
    ) {
      document.addEventListener("visibilitychange", handleVisibilityChange);
    }
    if (
      typeof window !== "undefined" &&
      typeof window.addEventListener === "function"
    ) {
      window.addEventListener("pagehide", flushDraftsForPageExit);
    }
    return true;
  }

  function init() {
    if (!_isStorageAvailable()) return null;

    hydrateMemoryCache();
    const input = setupInputListener();
    const isHidden = typeof document !== "undefined" && document.hidden === true;
    const intervalId = isHidden ? null : setupPeriodicSync();
    setupLifecycleListeners();
    if (isHidden) {
      flushDraftsForPageExit();
    }
    return { input: input, intervalId: intervalId };
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.AIIA_FEEDBACK_DRAFTS = {
    STORAGE_KEY: STORAGE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    TARGET_ID: TARGET_ID,
    TTL_MS: TTL_MS,
    MAX_DRAFTS: MAX_DRAFTS,
    INPUT_DEBOUNCE_MS: INPUT_DEBOUNCE_MS,
    SYNC_INTERVAL_MS: SYNC_INTERVAL_MS,
    loadAllDrafts: loadAllDrafts,
    getDraft: getDraft,
    saveDraft: saveDraft,
    clearDraft: clearDraft,
    clearAllDrafts: clearAllDrafts,
    hydrateMemoryCache: hydrateMemoryCache,
    reconcileMemoryToStorage: reconcileMemoryToStorage,
    flushActiveTextareaDraft: flushActiveTextareaDraft,
    setupPeriodicSync: setupPeriodicSync,
    stopPeriodicSync: stopPeriodicSync,
    _applyTtlAndLru: _applyTtlAndLru,
    _normalizeDraft: _normalizeDraft,
    _isStorageAvailable: _isStorageAvailable,
    init: init,
  };
})();
