function __vuT(key, params) {
  try {
    if (
      typeof window !== "undefined" &&
      window.AIIA_I18N &&
      typeof window.AIIA_I18N.t === "function"
    ) {
      return window.AIIA_I18N.t(key, params);
    }
  } catch (_e) {

  }
  return key;
}

class ValidationUtils {

  static SUPPORTED_IMAGE_TYPES = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/bmp",
  ];

  static MIN_FILE_SIZE = 100;

  static MAX_FILE_SIZE = 10 * 1024 * 1024;

  static MAX_FILENAME_LENGTH = 255;

  static SUSPICIOUS_EXTENSIONS = [
    ".exe",
    ".bat",
    ".cmd",
    ".scr",
    ".com",
    ".pif",
    ".vbs",
    ".js",
    ".jar",
    ".msi",
    ".dll",
    ".ps1",
  ];

  static FORBIDDEN_FILENAME_CHARS = /[<>:"/\\|?*\x00-\x1f]/g;

  static XSS_PATTERNS = [
    /<script\b[^>]*>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /data:\s*text\/html/gi,
  ];

  static validateImageFile(file) {
    const errors = [];

    if (!file) {
      errors.push(__vuT("validation.invalidFile"));
      return { valid: false, errors };
    }

    if (!file.type) {
      errors.push(__vuT("validation.invalidFile"));
      return { valid: false, errors };
    }

    if (!this.SUPPORTED_IMAGE_TYPES.includes(file.type)) {
      errors.push(__vuT("validation.unsupportedFormat", { type: file.type }));
    }

    if (file.size < this.MIN_FILE_SIZE) {
      errors.push(__vuT("validation.fileTooSmall", { size: file.size }));
    }

    if (file.size > this.MAX_FILE_SIZE) {
      const sizeMB = (file.size / 1024 / 1024).toFixed(2);
      const limitMB = (this.MAX_FILE_SIZE / 1024 / 1024).toFixed(0);
      errors.push(
        __vuT("validation.fileSizeExceeded", {
          actual: sizeMB,
          limit: limitMB,
        }),
      );
    }

    const filenameErrors = this.validateFilename(file.name);
    errors.push(...filenameErrors);

    const securityErrors = this.checkFileSecurity(file);
    errors.push(...securityErrors);

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  static validateFilename(filename) {
    const errors = [];

    if (!filename) {
      errors.push(__vuT("validation.filenameEmpty"));
      return errors;
    }

    if (filename.length > this.MAX_FILENAME_LENGTH) {
      errors.push(
        __vuT("validation.fileNameTooLong") +
          ` (${filename.length} > ${this.MAX_FILENAME_LENGTH})`,
      );
    }

    this.FORBIDDEN_FILENAME_CHARS.lastIndex = 0;
    if (this.FORBIDDEN_FILENAME_CHARS.test(filename)) {
      errors.push(__vuT("validation.filenameIllegalChars"));
    }

    if (
      filename.includes("..") ||
      filename.includes("/") ||
      filename.includes("\\")
    ) {
      errors.push(__vuT("validation.filenamePathTraversal"));
    }

    return errors;
  }

  static checkFileSecurity(file) {
    const errors = [];
    const filename = file.name?.toLowerCase() || "";

    for (const ext of this.SUSPICIOUS_EXTENSIONS) {
      if (filename.endsWith(ext)) {
        errors.push(__vuT("validation.suspiciousExt", { ext }));
        break;
      }
    }

    const parts = filename.split(".");
    if (parts.length > 2) {
      const lastExt = "." + parts[parts.length - 1];
      if (this.SUSPICIOUS_EXTENSIONS.includes(lastExt)) {
        errors.push(__vuT("validation.maskedExecutable"));
      }
    }

    return errors;
  }

  static validateTextInput(text, options = {}) {
    const {
      minLength = 0,
      maxLength = 10000,
      allowEmpty = true,
      sanitize = true,
    } = options;

    const errors = [];
    let sanitized = text || "";

    if (!text || text.trim() === "") {
      if (!allowEmpty) {
        errors.push(__vuT("validation.emptyField"));
      }
      return { valid: allowEmpty, errors, sanitized: "" };
    }

    if (text.length < minLength) {
      errors.push(
        __vuT("validation.inputTooShort", {
          length: text.length,
          min: minLength,
        }),
      );
    }

    if (text.length > maxLength) {
      errors.push(
        __vuT("validation.inputTooLong", {
          length: text.length,
          max: maxLength,
        }),
      );
      sanitized = text.substring(0, maxLength);
    }

    if (sanitize) {
      sanitized = this.sanitizeText(sanitized);
    }

    return {
      valid: errors.length === 0,
      errors,
      sanitized,
    };
  }

  static sanitizeText(text) {
    if (!text) return "";

    let sanitized = text;

    for (const pattern of this.XSS_PATTERNS) {
      sanitized = sanitized.replace(pattern, "");
    }

    sanitized = sanitized
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#x27;");

    return sanitized;
  }

  static sanitizeFilename(filename, maxLength = 100) {
    if (!filename) return "";

    return filename
      .replace(this.FORBIDDEN_FILENAME_CHARS, "")
      .replace(/\s+/g, "_")
      .replace(/\.{2,}/g, ".")
      .trim()
      .substring(0, maxLength);
  }

  static validateNumberRange(value, min, max, fieldName) {
    const num = Number(value);
    const name = fieldName || __vuT("validation.defaultFieldName");

    if (isNaN(num)) {
      return {
        valid: false,
        value: min,
        error: __vuT("validation.notANumber", { field: name }),
      };
    }

    if (num < min) {
      return {
        valid: false,
        value: min,
        error: __vuT("validation.numberBelowMin", { field: name, min }),
      };
    }

    if (num > max) {
      return {
        valid: false,
        value: max,
        error: __vuT("validation.numberAboveMax", { field: name, max }),
      };
    }

    return {
      valid: true,
      value: num,
      error: null,
    };
  }

  static clampValue(value, min, max) {
    const num = Number(value);
    if (isNaN(num)) return min;
    return Math.max(min, Math.min(max, num));
  }
}

const API_CACHE_CLEANUP_INTERVAL_MS = 5 * 60 * 1000;

class APICache {
  constructor(
    defaultTTL = 30000,
    cleanupIntervalMs = API_CACHE_CLEANUP_INTERVAL_MS,
  ) {
    this.cache = new Map();
    this.defaultTTL = defaultTTL;
    this.cleanupIntervalMs = cleanupIntervalMs;
    this._cleanupTimerId = null;
    this._lifecycleListenersInstalled = false;
  }

  get(key) {
    const entry = this._getFreshEntry(key);
    return entry ? entry.value : null;
  }

  set(key, value, ttl = this.defaultTTL) {
    this.cache.set(key, {
      value,
      expiry: Date.now() + ttl,
    });
    this._ensureCleanupTimer();
  }

  delete(key) {
    const deleted = this.cache.delete(key);
    this._stopCleanupTimerIfIdle();
    return deleted;
  }

  clear() {
    this.cache.clear();
    this.stopCleanupTimer();
  }

  cleanup() {
    const now = Date.now();
    let removed = 0;
    for (const [key, entry] of this.cache.entries()) {
      if (now > entry.expiry) {
        this.cache.delete(key);
        removed += 1;
      }
    }
    this._stopCleanupTimerIfIdle();
    return removed;
  }

  _shouldRunCleanupTimer() {
    if (typeof setInterval !== "function") return false;
    if (typeof document !== "undefined" && document.hidden === true) {
      return false;
    }
    return this.cache.size > 0;
  }

  _ensureCleanupTimer() {
    if (this._cleanupTimerId !== null) return this._cleanupTimerId;
    if (!this._shouldRunCleanupTimer()) return null;
    this._cleanupTimerId = setInterval(() => {
      this.cleanup();
      this._stopCleanupTimerIfIdle();
    }, this.cleanupIntervalMs);
    return this._cleanupTimerId;
  }

  stopCleanupTimer() {
    if (this._cleanupTimerId === null) return false;
    if (typeof clearInterval === "function") {
      clearInterval(this._cleanupTimerId);
    }
    this._cleanupTimerId = null;
    return true;
  }

  _stopCleanupTimerIfIdle() {
    if (this.cache.size === 0) {
      this.stopCleanupTimer();
    }
  }

  _getFreshEntry(key) {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expiry) {
      this.cache.delete(key);
      this._stopCleanupTimerIfIdle();
      return null;
    }

    return entry;
  }

  get size() {
    return this.cache.size;
  }

  async fetchWithCache(url, options = {}, cacheTTL = this.defaultTTL) {
    const parseJsonOrThrow = async (response) => {
      const contentType = (
        response.headers.get("content-type") || ""
      ).toLowerCase();
      if (!contentType.includes("application/json")) {
        throw new Error(
          `APICache.fetchWithCache: expected JSON response, got "${contentType || "unknown"}" (url=${url})`,
        );
      }
      return response.json();
    };

    const method = options.method?.toUpperCase() || "GET";
    if (method !== "GET") {
      const response = await fetch(url, options);
      return parseJsonOrThrow(response);
    }

    const cacheKey = `${method}:${url}`;
    const cachedEntry = this._getFreshEntry(cacheKey);
    if (cachedEntry !== null) {
      return cachedEntry.value;
    }

    const response = await fetch(url, options);
    const data = await parseJsonOrThrow(response);

    if (response.ok) {
      this.set(cacheKey, data, cacheTTL);
    }

    return data;
  }
}

const apiCache = new APICache(30000);

function setupApiCacheLifecycle(cache) {
  if (!cache || cache._lifecycleListenersInstalled) return false;
  cache._lifecycleListenersInstalled = true;

  const syncTimerWithVisibility = () => {
    if (typeof document !== "undefined" && document.hidden === true) {
      cache.stopCleanupTimer();
      return;
    }
    cache.cleanup();
    cache._ensureCleanupTimer();
  };

  if (
    typeof document !== "undefined" &&
    typeof document.addEventListener === "function"
  ) {
    document.addEventListener("visibilitychange", syncTimerWithVisibility);
  }
  if (
    typeof window !== "undefined" &&
    typeof window.addEventListener === "function"
  ) {
    window.addEventListener("pagehide", () => {
      cache.stopCleanupTimer();
    });
    window.addEventListener("pageshow", syncTimerWithVisibility);
  }
  return true;
}

setupApiCacheLifecycle(apiCache);

function debounce(func, wait = 300, immediate = false) {
  let timeout = null;
  let result = null;
  let lastArgs = null;
  let lastThis = null;

  const clearLastCall = () => {
    lastArgs = null;
    lastThis = null;
  };

  const invokeLastCall = () => {
    const args = lastArgs;
    const context = lastThis;
    clearLastCall();
    result = func.apply(context, args);
    return result;
  };

  const debounced = function (...args) {
    lastArgs = args;
    lastThis = this;
    const callNow = immediate && !timeout;

    if (timeout) {
      clearTimeout(timeout);
    }

    timeout = setTimeout(() => {
      timeout = null;
      if (!immediate && lastArgs) {
        invokeLastCall();
      } else {
        clearLastCall();
      }
    }, wait);

    if (callNow) {
      result = func.apply(lastThis, lastArgs);
    }

    return result;
  };

  debounced.cancel = function () {
    if (timeout) {
      clearTimeout(timeout);
      timeout = null;
    }
    clearLastCall();
  };

  debounced.flush = function () {
    if (!timeout) {
      return result;
    }

    clearTimeout(timeout);
    timeout = null;

    if (!immediate && lastArgs) {
      return invokeLastCall();
    }

    clearLastCall();
    return result;
  };

  return debounced;
}

function throttle(func, wait = 200, options = {}) {
  let timeout = null;
  let previous = 0;
  const { leading = true, trailing = true } = options;

  const throttled = function (...args) {
    const context = this;
    const now = Date.now();

    if (!previous && !leading) {
      previous = now;
    }

    const remaining = wait - (now - previous);

    if (remaining <= 0 || remaining > wait) {

      if (timeout) {
        clearTimeout(timeout);
        timeout = null;
      }
      previous = now;
      func.apply(context, args);
    } else if (!timeout && trailing) {

      timeout = setTimeout(() => {
        previous = leading ? Date.now() : 0;
        timeout = null;
        func.apply(context, args);
      }, remaining);
    }
  };

  throttled.cancel = function () {
    if (timeout) {
      clearTimeout(timeout);
      timeout = null;
    }
    previous = 0;
  };

  return throttled;
}

class RequestDeduplicator {
  constructor() {
    this.pendingRequests = new Map();
  }

  async dedupe(key, asyncFn) {

    if (this.pendingRequests.has(key)) {
      console.debug(`[RequestDeduplicator] deduped request: ${key}`);
      return this.pendingRequests.get(key);
    }

    const promise = asyncFn().finally(() => {
      this.pendingRequests.delete(key);
    });

    this.pendingRequests.set(key, promise);
    return promise;
  }

  isPending(key) {
    return this.pendingRequests.has(key);
  }

  clear() {
    this.pendingRequests.clear();
  }
}

const requestDeduplicator = new RequestDeduplicator();

class LazyLoader {

  static defaultOptions = {
    rootMargin: "50px 0px",
    threshold: 0.01,
    loadingClass: "lazy-loading",
    loadedClass: "lazy-loaded",
    errorClass: "lazy-error",
  };

  static init(selector = ".lazy-image", options = {}) {
    const config = { ...this.defaultOptions, ...options };
    this.disconnect();

    if (!("IntersectionObserver" in window)) {
      console.warn(
        "IntersectionObserver not supported, falling back to eager load",
      );
      this.loadAllImages(selector);
      return;
    }

    const observer = new IntersectionObserver(
      (entries, obs) => {
        const entryCount =
          entries && Number.isFinite(entries.length) ? entries.length : 0;
        for (let entryIndex = 0; entryIndex < entryCount; entryIndex += 1) {
          const entry = entries[entryIndex];
          if (!entry) continue;
          if (entry.isIntersecting) {
            this.loadImage(entry.target, config);
            obs.unobserve(entry.target);
          }
        }
      },
      {
        rootMargin: config.rootMargin,
        threshold: config.threshold,
      },
    );

    const images = document.querySelectorAll(selector);
    const imageCount =
      images && Number.isFinite(images.length) ? images.length : 0;
    for (let imageIndex = 0; imageIndex < imageCount; imageIndex += 1) {
      const img = images[imageIndex];
      if (img) {
        observer.observe(img);
      }
    }

    this._observer = observer;
    console.debug(
      `Lazy loader initialized, watching ${imageCount} images`,
    );
  }

  static loadImage(img, config = this.defaultOptions) {
    const src = img.dataset.src;
    if (!src) return;

    img.classList.add(config.loadingClass);

    const tempImg = new Image();

    tempImg.onload = () => {
      img.src = src;
      img.classList.remove(config.loadingClass);
      img.classList.add(config.loadedClass);
      img.removeAttribute("data-src");
    };

    tempImg.onerror = () => {
      img.classList.remove(config.loadingClass);
      img.classList.add(config.errorClass);
      console.warn(`Image load failed: ${src}`);
    };

    tempImg.src = src;
  }

  static loadAllImages(selector) {
    const images = document.querySelectorAll(selector);
    const imageCount =
      images && Number.isFinite(images.length) ? images.length : 0;
    for (let imageIndex = 0; imageIndex < imageCount; imageIndex += 1) {
      const img = images[imageIndex];
      if (img) {
        this.loadImage(img);
      }
    }
  }

  static load(target) {
    const img =
      typeof target === "string" ? document.querySelector(target) : target;

    if (img) {
      this.loadImage(img);
    }
  }

  static observe(img) {
    if (this._observer && img) {
      this._observer.observe(img);
    }
  }

  static disconnect() {
    if (this._observer) {
      this._observer.disconnect();
      this._observer = null;
    }
  }
}

class VirtualScroller {

  constructor(container, options = {}) {
    this.container = container;
    this.itemHeight = options.itemHeight || 50;
    this.buffer = options.buffer || 5;
    this.items = [];
    this._scrollHandler = null;
    this._destroyed = false;

    this.renderItem =
      options.renderItem ||
      ((item) =>
        `<div>${ValidationUtils.sanitizeText(String(item ?? ""))}</div>`);

    this.init();
  }

  init() {

    this.wrapper = document.createElement("div");
    this.wrapper.className = "virtual-scroll-wrapper";
    this.wrapper.style.position = "relative";

    this.content = document.createElement("div");
    this.content.className = "virtual-scroll-content";
    this.wrapper.appendChild(this.content);

    this.container.appendChild(this.wrapper);

    this._scrollHandler =
      typeof throttle !== "undefined"
        ? throttle(() => this.render(), 16)
        : () => this.render();
    this.container.addEventListener("scroll", this._scrollHandler);
  }

  setItems(items) {
    this.items = items;
    this.wrapper.style.height = `${items.length * this.itemHeight}px`;
    this.render();
  }

  render() {
    const scrollTop = this.container.scrollTop;
    const containerHeight = this.container.clientHeight;

    const startIndex = Math.max(
      0,
      Math.floor(scrollTop / this.itemHeight) - this.buffer,
    );
    const endIndex = Math.min(
      this.items.length,
      Math.ceil((scrollTop + containerHeight) / this.itemHeight) + this.buffer,
    );

    this.content.style.transform = `translateY(${startIndex * this.itemHeight}px)`;
    let html = "";
    for (let index = startIndex; index < endIndex; index += 1) {
      if (!(index in this.items)) continue;
      const rendered = this.renderItem(this.items[index], index);
      if (rendered !== undefined && rendered !== null) {
        html += rendered;
      }
    }
    this.content.innerHTML = html;
  }

  scrollToIndex(index) {
    this.container.scrollTop = index * this.itemHeight;
  }

  destroy() {
    if (this._destroyed) return;
    this._destroyed = true;
    if (this._scrollHandler) {
      this.container.removeEventListener("scroll", this._scrollHandler);
      this._scrollHandler = null;
    }
    if (this.wrapper && this.wrapper.parentNode === this.container) {
      this.container.removeChild(this.wrapper);
    }
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    API_CACHE_CLEANUP_INTERVAL_MS,
    ValidationUtils,
    APICache,
    apiCache,
    setupApiCacheLifecycle,
    debounce,
    throttle,
    RequestDeduplicator,
    requestDeduplicator,
    LazyLoader,
    VirtualScroller,
  };
}
