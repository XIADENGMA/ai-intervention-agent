function __vuT(key, params) {
  try {
    if (
      typeof window !== "undefined" &&
      window.AIIA_I18N &&
      typeof window.AIIA_I18N.t === "function"
    ) {
      return window.AIIA_I18N.t(key, params);
    }
  } catch (_e) {

  }
  return key;
}

class ValidationUtils {

  static SUPPORTED_IMAGE_TYPES = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/gif",
    "image/webp",
    "image/bmp",
  ];

  static MIN_FILE_SIZE = 100;

  static MAX_FILE_SIZE = 10 * 1024 * 1024;

  static MAX_FILENAME_LENGTH = 255;

  static SUSPICIOUS_EXTENSIONS = [
    ".exe",
    ".bat",
    ".cmd",
    ".scr",
    ".com",
    ".pif",
    ".vbs",
    ".js",
    ".jar",
    ".msi",
    ".dll",
    ".ps1",
  ];

  static FORBIDDEN_FILENAME_CHARS = /[<>:"/\\|?*\x00-\x1f]/g;

  static validateImageFile(file) {
    const errors = [];

    if (!file) {
      errors.push(__vuT("validation.invalidFile"));
      return { valid: false, errors };
    }

    if (!file.type) {
      errors.push(__vuT("validation.invalidFile"));
      return { valid: false, errors };
    }

    if (!this.SUPPORTED_IMAGE_TYPES.includes(file.type)) {
      errors.push(__vuT("validation.unsupportedFormat", { type: file.type }));
    }

    if (file.size < this.MIN_FILE_SIZE) {
      errors.push(__vuT("validation.fileTooSmall", { size: file.size }));
    }

    if (file.size > this.MAX_FILE_SIZE) {
      const sizeMB = (file.size / 1024 / 1024).toFixed(2);
      const limitMB = (this.MAX_FILE_SIZE / 1024 / 1024).toFixed(0);
      errors.push(
        __vuT("validation.fileSizeExceeded", {
          actual: sizeMB,
          limit: limitMB,
        }),
      );
    }

    const filenameErrors = this.validateFilename(file.name);
    errors.push(...filenameErrors);

    const securityErrors = this.checkFileSecurity(file);
    errors.push(...securityErrors);

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  static validateFilename(filename) {
    const errors = [];

    if (!filename) {
      errors.push(__vuT("validation.filenameEmpty"));
      return errors;
    }

    if (filename.length > this.MAX_FILENAME_LENGTH) {
      errors.push(
        __vuT("validation.fileNameTooLong") +
          ` (${filename.length} > ${this.MAX_FILENAME_LENGTH})`,
      );
    }

    this.FORBIDDEN_FILENAME_CHARS.lastIndex = 0;
    if (this.FORBIDDEN_FILENAME_CHARS.test(filename)) {
      errors.push(__vuT("validation.filenameIllegalChars"));
    }

    if (
      /^\s*\.+\s*$/.test(filename) ||
      filename.includes("/") ||
      filename.includes("\\")
    ) {
      errors.push(__vuT("validation.filenamePathTraversal"));
    }

    return errors;
  }

  static checkFileSecurity(file) {
    const errors = [];
    const filename = file.name?.toLowerCase() || "";

    for (const ext of this.SUSPICIOUS_EXTENSIONS) {
      if (filename.endsWith(ext)) {
        errors.push(__vuT("validation.suspiciousExt", { ext }));
        break;
      }
    }

    const parts = filename.split(".");
    if (parts.length > 2) {
      const lastExt = "." + parts[parts.length - 1];
      if (this.SUSPICIOUS_EXTENSIONS.includes(lastExt)) {
        errors.push(__vuT("validation.maskedExecutable"));
      }
    }

    return errors;
  }

  static sanitizeFilename(filename, maxLength = 100) {
    if (!filename) return "";

    return filename
      .replace(this.FORBIDDEN_FILENAME_CHARS, "")
      .replace(/\s+/g, "_")
      .replace(/\.{2,}/g, ".")
      .trim()
      .substring(0, maxLength);
  }
}
