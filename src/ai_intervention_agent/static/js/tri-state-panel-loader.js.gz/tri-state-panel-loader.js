const READY_EVENT = 'aiia:tri-state-panel-ready'
const FAILED_EVENT = 'aiia:tri-state-panel-failed'

function publish(pkg) {
  const globalNamespace = typeof window !== 'undefined' ? window : globalThis
  globalNamespace.AIIA_TRI_STATE_PANEL = pkg
  try {
    document.dispatchEvent(new CustomEvent(READY_EVENT, { detail: pkg }))
  } catch (_e) {

  }
}

function publishError(err) {
  const globalNamespace = typeof window !== 'undefined' ? window : globalThis

  globalNamespace.AIIA_TRI_STATE_PANEL_FAILURE =
    err instanceof Error ? err : new Error(String(err && err.message ? err.message : err || 'unknown loader failure'))
  if (typeof console !== 'undefined' && console.error) {
    console.error('@aiia/tri-state-panel loader failed:', err)
  }
  try {
    document.dispatchEvent(new CustomEvent(FAILED_EVENT, { detail: { error: err } }))
  } catch (_e) {

  }
}

import('@aiia/tri-state-panel')
  .then(function (mod) {
    publish({
      TriStatePanelController: mod.TriStatePanelController,
      VERSION: mod.VERSION,
      VALID_STATES_FROZEN: mod.VALID_STATES_FROZEN,
      ERROR_MODES_FROZEN: mod.ERROR_MODES_FROZEN,
      EMPTY_MODES_FROZEN: mod.EMPTY_MODES_FROZEN
    })
  })
  .catch(publishError)
