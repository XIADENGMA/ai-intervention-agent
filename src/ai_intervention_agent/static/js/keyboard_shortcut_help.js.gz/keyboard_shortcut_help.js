(function () {
  "use strict";

  var OVERLAY_ID = "aiia-keyboard-shortcut-help-overlay";

  var _previouslyFocusedElement = null;

  var TRIGGER_KEY = "?";

  var SHORTCUTS = [
    {
      keys: ["?"],
      i18nKey: "shortcuts.showHelp",
      fallback: "Show this cheatsheet",
    },
    {
      keys: ["Esc"],
      i18nKey: "shortcuts.closeModal",
      fallback: "Close this cheatsheet",
    },
    {
      keys: ["Ctrl", "Enter"],
      i18nKey: "shortcuts.submitCtrlEnter",
      fallback: "Submit feedback (default mode)",
    },
    {
      keys: ["Enter"],
      i18nKey: "shortcuts.submitEnter",
      fallback: "Submit (when Enter mode is selected)",
    },
    {
      keys: ["Shift", "Enter"],
      i18nKey: "shortcuts.newline",
      fallback: "Insert newline (when Enter mode is selected)",
    },

    {
      keys: ["Ctrl", ","],
      i18nKey: "shortcuts.openSettings",
      fallback: "Open settings panel",
    },
    {
      keys: ["Tab"],
      i18nKey: "shortcuts.nextTask",
      fallback: "Switch to next task tab",
    },
    {
      keys: ["Shift", "Tab"],
      i18nKey: "shortcuts.prevTask",
      fallback: "Switch to previous task tab",
    },
    {
      keys: ["T"],
      i18nKey: "shortcuts.toggleTheme",
      fallback: "Toggle dark/light theme",
    },
  ];

  function _t(key, fallback) {
    try {
      var i18n = window.AIIA_I18N;
      if (i18n && typeof i18n.t === "function") {
        var v = i18n.t(key);
        if (typeof v === "string" && v.length > 0 && v !== key) {
          return v;
        }
      }
    } catch (_e) {

    }
    return fallback;
  }

  function _resolveShortcutLabel(i18nKey, fallback) {
    if (i18nKey === "shortcuts.showHelp") {
      return _t("shortcuts.showHelp", fallback);
    }
    if (i18nKey === "shortcuts.closeModal") {
      return _t("shortcuts.closeModal", fallback);
    }
    if (i18nKey === "shortcuts.submitCtrlEnter") {
      return _t("shortcuts.submitCtrlEnter", fallback);
    }
    if (i18nKey === "shortcuts.submitEnter") {
      return _t("shortcuts.submitEnter", fallback);
    }
    if (i18nKey === "shortcuts.newline") {
      return _t("shortcuts.newline", fallback);
    }

    if (i18nKey === "shortcuts.openSettings") {
      return _t("shortcuts.openSettings", fallback);
    }
    if (i18nKey === "shortcuts.nextTask") {
      return _t("shortcuts.nextTask", fallback);
    }
    if (i18nKey === "shortcuts.prevTask") {
      return _t("shortcuts.prevTask", fallback);
    }
    if (i18nKey === "shortcuts.toggleTheme") {
      return _t("shortcuts.toggleTheme", fallback);
    }
    return fallback;
  }

  function _renderShortcutRow(shortcut) {
    var row = document.createElement("div");
    row.className = "aiia-kshelp-row";

    var keysDiv = document.createElement("div");
    keysDiv.className = "aiia-kshelp-keys";
    for (var i = 0; i < shortcut.keys.length; i++) {
      if (i > 0) {
        var plus = document.createElement("span");
        plus.className = "aiia-kshelp-plus";
        plus.textContent = "+";
        keysDiv.appendChild(plus);
      }
      var kbd = document.createElement("kbd");
      kbd.className = "aiia-kshelp-key";
      kbd.textContent = shortcut.keys[i];
      keysDiv.appendChild(kbd);
    }

    var label = document.createElement("div");
    label.className = "aiia-kshelp-label";
    label.textContent = _resolveShortcutLabel(
      shortcut.i18nKey,
      shortcut.fallback,
    );

    row.appendChild(keysDiv);
    row.appendChild(label);
    return row;
  }

  function _buildOverlayDom() {
    var overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.className = "aiia-kshelp-overlay";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute(
      "aria-label",
      _t("shortcuts.helpTitle", "Keyboard shortcuts"),
    );

    var card = document.createElement("div");
    card.className = "aiia-kshelp-card";
    card.tabIndex = -1;

    var title = document.createElement("h2");
    title.className = "aiia-kshelp-title";
    title.textContent = _t("shortcuts.helpTitle", "Keyboard shortcuts");
    card.appendChild(title);

    var subtitle = document.createElement("p");
    subtitle.className = "aiia-kshelp-subtitle";
    subtitle.textContent = _t(
      "shortcuts.helpSubtitle",
      "Press ? anywhere outside an input to open this panel",
    );
    card.appendChild(subtitle);

    var rows = document.createElement("div");
    rows.className = "aiia-kshelp-rows";
    for (var i = 0; i < SHORTCUTS.length; i++) {
      rows.appendChild(_renderShortcutRow(SHORTCUTS[i]));
    }
    card.appendChild(rows);

    var hint = document.createElement("p");
    hint.className = "aiia-kshelp-hint";
    hint.textContent = _t(
      "shortcuts.helpEscHint",
      "Press Esc or click outside to close",
    );
    card.appendChild(hint);

    card.addEventListener("click", function (ev) {
      ev.stopPropagation();
    });
    overlay.appendChild(card);

    overlay.addEventListener("click", function () {
      hideOverlay();
    });

    return overlay;
  }

  function _safelySetInert(el, value) {
    if (!el) return;
    try {
      el.inert = value;
    } catch (_e) {
      if (value) {
        el.setAttribute("inert", "");
      } else {
        el.removeAttribute("inert");
      }
    }
  }

  function _setContainerSiblingsInert(value) {
    var container = document.querySelector(".container");
    if (!container) return;
    var children = container.children;
    for (var i = 0; i < children.length; i++) {
      _safelySetInert(children[i], value);
    }
  }

  function _onTabInOverlay(event) {
    if (event.key !== "Tab") return;
    var overlay = document.getElementById(OVERLAY_ID);
    if (!overlay) return;
    var card = overlay.querySelector(".aiia-kshelp-card");
    if (!card) return;

    event.preventDefault();
    if (typeof card.focus === "function") {
      try {
        card.focus({ preventScroll: true });
      } catch (_e) {
        card.focus();
      }
    }
  }

  function showOverlay() {
    var existing = document.getElementById(OVERLAY_ID);
    if (existing) {
      return;
    }

    try {
      _previouslyFocusedElement = document.activeElement;
    } catch (_e) {
      _previouslyFocusedElement = null;
    }

    var overlay = _buildOverlayDom();
    document.body.appendChild(overlay);

    _setContainerSiblingsInert(true);

    var card = overlay.querySelector(".aiia-kshelp-card");
    if (card && typeof card.focus === "function") {
      try {
        card.focus({ preventScroll: true });
      } catch (_e) {
        try {
          card.focus();
        } catch (_e2) {

        }
      }
    }

    document.addEventListener("keydown", _onTabInOverlay, true);
  }

  function hideOverlay() {
    var overlay = document.getElementById(OVERLAY_ID);
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }

    document.removeEventListener("keydown", _onTabInOverlay, true);

    _setContainerSiblingsInert(false);

    var prev = _previouslyFocusedElement;
    _previouslyFocusedElement = null;
    if (
      prev &&
      typeof prev.focus === "function" &&

      document.contains(prev)
    ) {
      try {
        prev.focus({ preventScroll: true });
      } catch (_e) {
        try {
          prev.focus();
        } catch (_e2) {

        }
      }
    }
  }

  function isOverlayOpen() {
    return Boolean(document.getElementById(OVERLAY_ID));
  }

  function _isTypingTarget(el) {
    if (!el) {
      return false;
    }
    var tag = (el.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select") {
      return true;
    }

    if (
      el.isContentEditable ||
      el.getAttribute("contenteditable") === "true" ||
      el.getAttribute("contenteditable") === ""
    ) {
      return true;
    }
    return false;
  }

  function _shouldTriggerHelp(event) {

    if (event.key !== TRIGGER_KEY) {
      return false;
    }

    if (event.ctrlKey || event.metaKey || event.altKey) {
      return false;
    }

    if (_isTypingTarget(document.activeElement)) {
      return false;
    }
    return true;
  }

  function _onKeydown(event) {

    if (isOverlayOpen()) {
      if (event.key === "Escape" || event.key === "Esc") {
        event.preventDefault();
        hideOverlay();
      }
      return;
    }
    if (_shouldTriggerHelp(event)) {
      event.preventDefault();
      showOverlay();
    }
  }

  function init() {

    document.addEventListener("keydown", _onKeydown, true);
  }

  window.AIIA_KEYBOARD_SHORTCUT_HELP = {
    showOverlay: showOverlay,
    hideOverlay: hideOverlay,
    isOverlayOpen: isOverlayOpen,
    OVERLAY_ID: OVERLAY_ID,
    TRIGGER_KEY: TRIGGER_KEY,
    SHORTCUTS: SHORTCUTS,
    _shouldTriggerHelp: _shouldTriggerHelp,
    _isTypingTarget: _isTypingTarget,

    _onTabInOverlay: _onTabInOverlay,
    _setContainerSiblingsInert: _setContainerSiblingsInert,
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
