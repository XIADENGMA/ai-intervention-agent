(function redirectZeroHostToLoopback() {
  try {
    const url = new URL(window.location.href);
    if (url.hostname === "0.0.0.0") {
      url.hostname = "127.0.0.1";
      console.warn(
        `Detected 0.0.0.0 host; auto-redirecting to ${url.origin} (avoids browser compatibility issues).`,
      );
      window.location.replace(url.toString());
    }
  } catch (e) {

  }
})();

window.addEventListener("error", function (event) {
  console.error("[global error]", event.error || event.message);
});
window.addEventListener("unhandledrejection", function (event) {
  console.error("[unhandled rejection]", event.reason);
});

function fetchWithTimeout(url, options, timeoutMs) {
  var userSignal = options && options.signal;
  var hasTimeout = typeof timeoutMs === "number" && timeoutMs > 0;

  if (!hasTimeout) {
    return fetch(url, options);
  }

  var hasAbortAny =
    typeof AbortSignal !== "undefined" && typeof AbortSignal.any === "function";
  var hasAbortTimeout =
    typeof AbortSignal !== "undefined" &&
    typeof AbortSignal.timeout === "function";

  if (hasAbortTimeout && (!userSignal || hasAbortAny)) {
    var timeoutSignal = AbortSignal.timeout(timeoutMs);
    var mergedSignal = userSignal
      ? AbortSignal.any([userSignal, timeoutSignal])
      : timeoutSignal;
    var mergedNative = Object.assign({}, options || {}, {
      signal: mergedSignal,
    });
    return fetch(url, mergedNative);
  }

  if (typeof AbortController === "undefined") {
    return fetch(url, options);
  }

  var controller = new AbortController();
  var timer = setTimeout(function () {
    controller.abort();
  }, timeoutMs);

  function onUserAbort() {
    controller.abort();
  }
  if (userSignal) {
    if (userSignal.aborted) {
      controller.abort();
    } else {
      userSignal.addEventListener("abort", onUserAbort, { once: true });
    }
  }

  var mergedFallback = Object.assign({}, options || {}, {
    signal: controller.signal,
  });
  return fetch(url, mergedFallback).finally(function () {
    clearTimeout(timer);
    if (userSignal) {
      userSignal.removeEventListener("abort", onUserAbort);
    }
  });
}

let config = null;

function t(key, params) {
  try {
    if (window.AIIA_I18N && typeof window.AIIA_I18N.t === "function") {
      return window.AIIA_I18N.t(key, params);
    }
  } catch (_e) {

  }
  return key;
}

if (typeof window.__aiiaMarkedSecurityConfigured === "undefined") {
  window.__aiiaMarkedSecurityConfigured = false;
}

function configureMarkedSecurity() {
  if (window.__aiiaMarkedSecurityConfigured) return;
  if (typeof marked === "undefined" || !marked) return;

  try {
    if (typeof marked.use === "function") {
      marked.use({
        renderer: {

          html() {
            return "";
          },
        },
      });
    }

    if (typeof marked.setOptions === "function") {

      marked.setOptions({ mangle: false, headerIds: false });
    }

    window.__aiiaMarkedSecurityConfigured = true;
  } catch (e) {
    console.warn("marked security config failed (ignored):", e);
  }
}

configureMarkedSecurity();

let hourglassAnimation = null;
let _lottieLoadPromise = null;
let _hourglassObserver = null;
let _hourglassDelayTimer = null;
let _hourglassFallbackRemovalTimer = null;
let _hourglassIdleCallbackId = null;
let _hourglassLoadHandler = null;
let _hourglassThemeTimer = null;
let _hourglassLifecycleToken = 0;
let _hourglassLifecycleDisposed = false;
let _hourglassLifecycleHandlersInstalled = false;

function _isHourglassLifecycleActive(container, token) {
  if (_hourglassLifecycleDisposed) return false;
  if (token !== _hourglassLifecycleToken) return false;
  if (typeof document !== "undefined" && document.hidden) return false;
  if (!container) return false;
  try {
    if (container.isConnected === false) return false;
  } catch (_e) {

  }
  try {
    if (
      document.body &&
      typeof document.body.contains === "function" &&
      !document.body.contains(container)
    ) {
      return false;
    }
  } catch (_e) {

  }
  return true;
}

function _disconnectHourglassObserver() {
  try {
    if (_hourglassObserver) _hourglassObserver.disconnect();
  } catch (_e) {

  }
  _hourglassObserver = null;
}

function _clearHourglassLifecycleTimers() {
  try {
    if (_hourglassDelayTimer) clearTimeout(_hourglassDelayTimer);
  } catch (_e) {

  }
  _hourglassDelayTimer = null;

  try {
    if (_hourglassFallbackRemovalTimer) {
      clearTimeout(_hourglassFallbackRemovalTimer);
    }
  } catch (_e) {

  }
  _hourglassFallbackRemovalTimer = null;

  try {
    if (
      _hourglassIdleCallbackId !== null &&
      typeof window.cancelIdleCallback === "function"
    ) {
      window.cancelIdleCallback(_hourglassIdleCallbackId);
    }
  } catch (_e) {

  }
  _hourglassIdleCallbackId = null;

  try {
    if (_hourglassLoadHandler) {
      window.removeEventListener("load", _hourglassLoadHandler);
    }
  } catch (_e) {

  }
  _hourglassLoadHandler = null;

  try {
    if (_hourglassThemeTimer) clearTimeout(_hourglassThemeTimer);
  } catch (_e) {

  }
  _hourglassThemeTimer = null;
}

function destroyHourglassAnimation() {
  try {
    if (hourglassAnimation) hourglassAnimation.destroy();
  } catch (_e) {

  }
  hourglassAnimation = null;
}

function disposeHourglassAnimationLifecycle() {
  _hourglassLifecycleDisposed = true;
  _hourglassLifecycleToken += 1;
  _disconnectHourglassObserver();
  _clearHourglassLifecycleTimers();
  destroyHourglassAnimation();
}

function installHourglassAnimationLifecycleHandlers() {
  if (_hourglassLifecycleHandlersInstalled) return;
  _hourglassLifecycleHandlersInstalled = true;

  try {
    window.addEventListener("pagehide", function () {
      disposeHourglassAnimationLifecycle();
    });
  } catch (_e) {

  }

  try {
    window.addEventListener("pageshow", function (event) {
      if (!event || !event.persisted) return;
      if (typeof document !== "undefined" && document.hidden) return;
      initHourglassAnimation();
    });
  } catch (_e) {

  }

  try {
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) {
        disposeHourglassAnimationLifecycle();
      } else {
        initHourglassAnimation();
      }
    });
  } catch (_e) {

  }
}

function renderSproutFallback(container) {
  if (!container) return;
  try {

    container.textContent = "";
    container.innerHTML = `
      <svg
        width="48"
        height="48"
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        style="display:block; width:48px; height:48px;"
      >
        <style>
          @keyframes sproutGrow {
            0%   { transform: translateY(6px) scale(0.86); opacity: 0.65; }
            50%  { transform: translateY(0px) scale(1);    opacity: 1; }
            100% { transform: translateY(6px) scale(0.86); opacity: 0.65; }
          }
          @keyframes leafWiggle {
            0%,100% { transform: rotate(-6deg); }
            50%     { transform: rotate(6deg); }
          }
          .sprout-root { transform-origin: 24px 42px; animation: sproutGrow 1.6s ease-in-out infinite; }
          .leaf-left  { transform-origin: 18px 18px; animation: leafWiggle 1.6s ease-in-out infinite; }
          .leaf-right { transform-origin: 30px 18px; animation: leafWiggle 1.6s ease-in-out infinite reverse; }
        </style>
        <g class="sprout-root">
          <path d="M24 42V20" stroke="#111" stroke-width="3" stroke-linecap="round"/>
          <path class="leaf-left" d="M24 22C19 22 15 19 14 15C18 15 22 17 24 20" stroke="#111" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
          <path class="leaf-right" d="M24 22C29 22 33 19 34 15C30 15 26 17 24 20" stroke="#111" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M18 44C20 40 28 40 30 44" stroke="#111" stroke-width="3" stroke-linecap="round"/>
        </g>
      </svg>
    `;
  } catch (e) {

    container.textContent = t("status.waiting");
  }
}

function _ensureLottieLoaded() {
  if (typeof lottie !== "undefined") return Promise.resolve(true);
  if (_lottieLoadPromise) return _lottieLoadPromise;
  _lottieLoadPromise = new Promise((resolve) => {
    const script = document.createElement("script");
    script.src = window.AIIA_LOTTIE_JS_URL || "/static/js/lottie.min.js";
    script.onload = () => resolve(typeof lottie !== "undefined");
    script.onerror = () => {
      _lottieLoadPromise = null;
      resolve(false);
    };
    document.head.appendChild(script);
  });
  return _lottieLoadPromise;
}

function _createLottieAnimation(container, token) {
  if (!_isHourglassLifecycleActive(container, token)) return null;
  try {
    destroyHourglassAnimation();
    hourglassAnimation = lottie.loadAnimation({
      container,
      renderer: "svg",
      loop: true,

      autoplay: true,
      path: "/static/lottie/sprout.json",
      rendererSettings: { preserveAspectRatio: "xMidYMid meet" },
    });
    hourglassAnimation.addEventListener("DOMLoaded", () => {
      if (!_isHourglassLifecycleActive(container, token)) return;
      updateLottieAnimationColor();
    });
    hourglassAnimation.addEventListener("error", () => {
      if (!_isHourglassLifecycleActive(container, token)) return;

      destroyHourglassAnimation();
      renderSproutFallback(container);
      container.style.opacity = "1";
    });
    console.debug("Sprout animation initialized (lazy load)");
    return hourglassAnimation;
  } catch (error) {
    console.error("Lottie animation init failed:", error);
    if (_isHourglassLifecycleActive(container, token)) {
      destroyHourglassAnimation();
      renderSproutFallback(container);
      container.style.opacity = "1";
    }
    return null;
  }
}

function initHourglassAnimation() {
  installHourglassAnimationLifecycleHandlers();

  if (typeof document !== "undefined" && document.hidden) return;

  const container = document.getElementById("hourglass-lottie");
  if (!container) return;

  _hourglassLifecycleDisposed = false;
  if (hourglassAnimation) {
    updateLottieAnimationColor();
    return;
  }

  _disconnectHourglassObserver();
  _clearHourglassLifecycleTimers();
  const token = _hourglassLifecycleToken + 1;
  _hourglassLifecycleToken = token;

  _ensureLottieLoaded().then((ok) => {
    if (!_isHourglassLifecycleActive(container, token)) return;
    if (!ok) {
      renderSproutFallback(container);
      return;
    }
    _createLottieAnimation(container, token);
    updateLottieAnimationColor();
  });
}

function updateLottieAnimationColor() {
  const container = document.getElementById("hourglass-lottie");
  if (!container) return;

  const isLightTheme =
    document.documentElement.getAttribute("data-theme") === "light";

  if (isLightTheme) {

    container.style.filter = "none";
  } else {

    container.style.filter = "invert(1)";
  }
}

window.addEventListener("theme-changed", (event) => {

  try {
    if (_hourglassThemeTimer) clearTimeout(_hourglassThemeTimer);
  } catch (_e) {

  }
  _hourglassThemeTimer = setTimeout(() => {
    _hourglassThemeTimer = null;
    if (!_hourglassLifecycleDisposed) {
      updateLottieAnimationColor();
    }
  }, 50);
});

function renderMarkdownContent(element, content, isMarkdown = false) {

  const renderedDataset = element && element.dataset ? element.dataset : null;
  if (
    renderedDataset &&
    content &&
    renderedDataset.renderedContent === content &&
    element.childNodes &&
    element.childNodes.length > 0
  ) {
    return;
  }

  _scheduleNextFrame(() => {
    if (content) {

      try {
        element.removeAttribute("data-i18n");
      } catch (_e) {

      }
      let htmlContent = content;

      if (isMarkdown && typeof marked !== "undefined") {
        try {

          const mathGuard = window.protectMathDelimiters
            ? window.protectMathDelimiters(content)
            : { text: content, segments: [] };
          htmlContent = marked.parse(mathGuard.text);
          if (window.restoreMathDelimiters) {
            htmlContent = window.restoreMathDelimiters(
              htmlContent,
              mathGuard.segments,
            );
          }
        } catch (e) {
          console.warn("marked.js parse failed:", e);
        }
      }

      const fragment = document.createDocumentFragment();
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = htmlContent;

      while (tempDiv.firstChild) {
        fragment.appendChild(tempDiv.firstChild);
      }

      element.innerHTML = "";
      element.appendChild(fragment);

      if (renderedDataset) {
        renderedDataset.renderedContent = content;
      }

      processCodeBlocks(element);

      processStrikethrough(element);

      const textContent = element.textContent || "";
      if (window.loadMathJaxIfNeeded) {
        window.loadMathJaxIfNeeded(element, textContent);
      } else if (window.MathJax && window.MathJax.typesetPromise) {

        window.MathJax.typesetPromise([element]).catch((err) => {
          console.warn("MathJax render failed:", err);
        });
      }
    } else {
      element.textContent = t("page.loading");
    }
  });
}

function processCodeBlocks(container) {
  const codeBlocks = container.querySelectorAll("pre");

  const codeBlockCount =
    codeBlocks && Number.isFinite(codeBlocks.length) ? codeBlocks.length : 0;
  for (
    let codeBlockIndex = 0;
    codeBlockIndex < codeBlockCount;
    codeBlockIndex += 1
  ) {
    const pre = codeBlocks[codeBlockIndex];
    if (!pre) continue;

    if (
      pre.parentElement &&
      pre.parentElement.classList.contains("code-block-container")
    ) {
      continue;
    }

    const codeContainer = document.createElement("div");
    codeContainer.className = "code-block-container";

    pre.parentNode.insertBefore(codeContainer, pre);
    codeContainer.appendChild(pre);

    const codeElement = pre.querySelector("code");
    let language = "text";
    if (codeElement && codeElement.className) {
      const langMatch = codeElement.className.match(/language-(\w+)/);
      if (langMatch) {
        language = langMatch[1];
      }
    }

    const toolbar = document.createElement("div");
    toolbar.className = "code-toolbar";

    if (language !== "text") {
      const langLabel = document.createElement("span");
      langLabel.className = "language-label";
      langLabel.textContent = language.toUpperCase();
      toolbar.appendChild(langLabel);
    }

    const copyButton = DOMSecurity.createCopyButton(pre.textContent || "");

    toolbar.appendChild(copyButton);

    codeContainer.appendChild(toolbar);
  }
}

const COPY_BUTTON_RESTORE_DELAY_MS = 2000;
const COPY_BUTTON_ORIGINAL_HTML_PROP = "__aiiaCopyOriginalHTML";
const COPY_BUTTON_RESTORE_TIMER_PROP = "__aiiaCopyRestoreTimer";

function _clearCopyButtonRestoreTimer(button) {
  if (!button) return;
  const timerId = button[COPY_BUTTON_RESTORE_TIMER_PROP];
  if (timerId !== undefined && timerId !== null) {
    clearTimeout(timerId);
    button[COPY_BUTTON_RESTORE_TIMER_PROP] = null;
  }
}

function _beginCopyButtonTransientFeedback(button) {
  _clearCopyButtonRestoreTimer(button);
  if (
    !Object.prototype.hasOwnProperty.call(
      button,
      COPY_BUTTON_ORIGINAL_HTML_PROP,
    )
  ) {
    button[COPY_BUTTON_ORIGINAL_HTML_PROP] = button.innerHTML;
  }
}

function _restoreCopyButtonBaseline(button) {
  button.innerHTML = button[COPY_BUTTON_ORIGINAL_HTML_PROP] || "";
  button.classList.remove("copied");
  button.classList.remove("error");
}

function _scheduleCopyButtonRestore(button, restoreCallback) {
  const timerId = setTimeout(() => {
    if (button[COPY_BUTTON_RESTORE_TIMER_PROP] !== timerId) {
      return;
    }
    try {
      restoreCallback();
    } finally {
      button[COPY_BUTTON_RESTORE_TIMER_PROP] = null;
      delete button[COPY_BUTTON_ORIGINAL_HTML_PROP];
    }
  }, COPY_BUTTON_RESTORE_DELAY_MS);
  button[COPY_BUTTON_RESTORE_TIMER_PROP] = timerId;
}

async function copyCodeToClipboard(preElement, button) {

  const checkIconSvg =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" style="width: 14px; height: 14px; margin-right: 4px; vertical-align: middle;"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.7803 4.21967C14.0732 4.51256 14.0732 4.98744 13.7803 5.28033L6.78033 12.2803C6.48744 12.5732 6.01256 12.5732 5.71967 12.2803L2.21967 8.78033C1.92678 8.48744 1.92678 8.01256 2.21967 7.71967C2.51256 7.42678 2.98744 7.42678 3.28033 7.71967L6.25 10.6893L12.7197 4.21967C13.0126 3.92678 13.4874 3.92678 13.7803 4.21967Z"/></svg>';
  const errorIconSvg =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" style="width: 14px; height: 14px; margin-right: 4px; vertical-align: middle;"><path fill-rule="evenodd" clip-rule="evenodd" d="M4.21967 4.21967C4.51256 3.92678 4.98744 3.92678 5.28033 4.21967L8 6.93934L10.7197 4.21967C11.0126 3.92678 11.4874 3.92678 11.7803 4.21967C12.0732 4.51256 12.0732 4.98744 11.7803 5.28033L9.06066 8L11.7803 10.7197C12.0732 11.0126 12.0732 11.4874 11.7803 11.7803C11.4874 12.0732 11.0126 12.0732 10.7197 11.7803L8 9.06066L5.28033 11.7803C4.98744 12.0732 4.51256 12.0732 4.21967 11.7803C3.92678 11.4874 3.92678 11.0126 4.21967 10.7197L6.93934 8L4.21967 5.28033C3.92678 4.98744 3.92678 4.51256 4.21967 4.21967Z"/></svg>';

  if (!preElement || !button) {
    console.warn("copyCodeToClipboard: preElement/button missing — abort");
    return;
  }

  try {
    const codeElement = preElement.querySelector("code");
    const textToCopy = codeElement
      ? codeElement.textContent
      : preElement.textContent;

    await navigator.clipboard.writeText(textToCopy);

    if (!button.isConnected) {
      console.debug(
        "copyCodeToClipboard: button detached after copy success — skip UI",
      );
      return;
    }
    _beginCopyButtonTransientFeedback(button);
    // AIIA-XSS-SAFE: checkIconSvg 是开发者手写 SVG 字面量；t('status.copied')

    button.innerHTML = checkIconSvg + t("status.copied");
    button.classList.remove("error");
    button.classList.add("copied");

    _scheduleCopyButtonRestore(button, () => {
      if (button.isConnected) {
        _restoreCopyButtonBaseline(button);
      }
    });
  } catch (err) {
    console.error("Copy failed:", err);

    if (!button.isConnected) {
      console.debug(
        "copyCodeToClipboard: button detached during copy failure — skip UI",
      );
      return;
    }
    _beginCopyButtonTransientFeedback(button);
    // AIIA-XSS-SAFE: errorIconSvg 是开发者手写 SVG 字面量；t('status.copyFailed')

    button.innerHTML = errorIconSvg + t("status.copyFailed");
    button.classList.remove("copied");
    button.classList.add("error");

    _scheduleCopyButtonRestore(button, () => {
      if (button.isConnected) {
        _restoreCopyButtonBaseline(button);
      }
    });
  }
}

function processStrikethrough(container) {

  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
    acceptNode: function (node) {

      const parent = node.parentElement;
      if (
        parent &&
        (parent.tagName === "CODE" ||
          parent.tagName === "PRE" ||
          parent.tagName === "SCRIPT" ||
          parent.tagName === "STYLE" ||
          parent.closest("pre, code, script, style"))
      ) {
        return NodeFilter.FILTER_REJECT;
      }
      return NodeFilter.FILTER_ACCEPT;
    },
  });

  const textNodes = [];
  let node;
  while ((node = walker.nextNode())) {
    textNodes.push(node);
  }

  for (
    let textNodeIndex = 0;
    textNodeIndex < textNodes.length;
    textNodeIndex += 1
  ) {
    const textNode = textNodes[textNodeIndex];
    const text = textNode.textContent;
    const strikethroughRegex = /~~([^~\n]+?)~~/g;

    if (!strikethroughRegex.test(text)) continue;

    const parts = text.split(/~~([^~\n]+?)~~/);
    if (parts.length <= 1) continue;

    const fragment = document.createDocumentFragment();
    for (let i = 0; i < parts.length; i++) {
      if (i % 2 === 0) {
        if (parts[i]) fragment.appendChild(document.createTextNode(parts[i]));
      } else {
        const del = document.createElement("del");
        del.textContent = parts[i];
        fragment.appendChild(del);
      }
    }

    textNode.parentNode.replaceChild(fragment, textNode);
  }
}

async function loadConfig() {
  try {
    const response = await fetchWithTimeout("/api/config", undefined, 10000);
    config = await response.json();

    if (!config.has_content) {
      showNoContentPage();

      return;
    }

    showContentPage();

    const descriptionElement = document.getElementById("description");
    if (descriptionElement) {
      renderMarkdownContent(
        descriptionElement,
        config.prompt_html || config.prompt,
      );
    } else {
      console.warn(
        "loadConfig: #description not in DOM (SSE reload + multi-task " +
          "switch concurrent?) — skipping prompt render",
      );
    }

    if (typeof updateOptionsDisplay === "function") {
      updateOptionsDisplay(
        config.predefined_options,
        config.predefined_options_defaults,
      );
    } else if (
      config.predefined_options &&
      config.predefined_options.length > 0
    ) {
      const optionsContainer = document.getElementById("options-container");
      const separator = document.getElementById("separator");

      if (!optionsContainer || !separator) {
        console.warn(
          "loadConfig: #options-container or #separator missing — " +
            "skipping options render",
        );
      } else {
        const optionDefaults = Array.isArray(config.predefined_options_defaults)
          ? config.predefined_options_defaults
          : [];
        optionsContainer.innerHTML = "";
        const predefinedOptionCount = config.predefined_options.length;
        for (let index = 0; index < predefinedOptionCount; index += 1) {
          if (!(index in config.predefined_options)) continue;
          const option = config.predefined_options[index];
          const optionDiv = document.createElement("div");
          optionDiv.className = "option-item";

          const checkbox = document.createElement("input");
          checkbox.type = "checkbox";
          checkbox.id = `option-${index}`;
          checkbox.value = option;
          checkbox.checked = optionDefaults[index] === true;

          const label = document.createElement("label");
          label.htmlFor = `option-${index}`;
          label.textContent = option;

          optionDiv.appendChild(checkbox);
          optionDiv.appendChild(label);
          if (checkbox.checked) {
            optionDiv.classList.add("selected");
          }
          optionsContainer.appendChild(optionDiv);
        }

        optionsContainer.classList.remove("hidden");
        optionsContainer.classList.add("visible");
        separator.classList.remove("hidden");
        separator.classList.add("visible");
      }
    }
  } catch (error) {
    console.error("Config load failed:", error);
    showStatus(t("status.loadFailed"), "error");
    throw error;
  }
}

function setElementDisplayById(id, display) {
  const element = document.getElementById(id);
  if (!element) {
    console.warn(`Page state update skipped: #${id} not in DOM`);
    return false;
  }
  element.style.display = display;
  return true;
}

function showNoContentPage() {
  setElementDisplayById("content-container", "none");
  setElementDisplayById("no-content-container", "flex");

  document.body.classList.add("no-content-mode");

  const taskTabsContainer = document.getElementById("task-tabs-container");
  if (taskTabsContainer) {
    taskTabsContainer.classList.add("hidden");
  }

  if (config) {
    setElementDisplayById("no-content-buttons", "block");
  }
}

function showContentPage() {
  setElementDisplayById("content-container", "block");
  setElementDisplayById("no-content-container", "none");

  document.body.classList.remove("no-content-mode");

  enableSubmitButton();
}

function disableSubmitButton() {
  const submitBtn = document.getElementById("submit-btn");
  const insertBtn = document.getElementById("insert-code-btn");
  const feedbackText = document.getElementById("feedback-text");

  if (submitBtn) submitBtn.disabled = true;
  if (insertBtn) insertBtn.disabled = true;
  if (feedbackText) feedbackText.disabled = true;
}

function enableSubmitButton() {
  const submitBtn = document.getElementById("submit-btn");
  const insertBtn = document.getElementById("insert-code-btn");
  const feedbackText = document.getElementById("feedback-text");

  if (submitBtn) submitBtn.disabled = false;
  if (insertBtn) insertBtn.disabled = false;
  if (feedbackText) feedbackText.disabled = false;
}

const _statusDismissTimers = Object.create(null);
const _statusDismissGenerations = Object.create(null);

function _clearStatusDismissTimer(statusElementId) {
  const timerId = _statusDismissTimers[statusElementId];
  if (timerId !== undefined && timerId !== null) {
    clearTimeout(timerId);
    _statusDismissTimers[statusElementId] = null;
  }
}

function showStatus(message, type) {
  const noContentContainer = document.getElementById("no-content-container");
  const isNoContentPage =
    noContentContainer && noContentContainer.style.display === "flex";

  if (!isNoContentPage && type !== "error") {

    if (type === "success" || type === "warning") {
      _showToast(message);
    }
    return;
  }

  const statusElementId = isNoContentPage
    ? "no-content-status-message"
    : "status-message";
  const statusElement = document.getElementById(statusElementId);

  if (!statusElement) return;

  _clearStatusDismissTimer(statusElementId);
  const statusGeneration =
    (_statusDismissGenerations[statusElementId] || 0) + 1;
  _statusDismissGenerations[statusElementId] = statusGeneration;

  statusElement.textContent = message;
  statusElement.className = `status-message status-${type}`;
  statusElement.style.display = "block";

  const autoDismissMs =
    type === "success"
      ? 3000
      : type === "warning"
        ? 5000
        : type === "error"
          ? 10000
          : 0;
  if (autoDismissMs > 0) {
    const dismissTimerId = setTimeout(() => {
      if (
        _statusDismissGenerations[statusElementId] !== statusGeneration ||
        _statusDismissTimers[statusElementId] !== dismissTimerId
      ) {
        return;
      }
      statusElement.style.display = "none";
      _statusDismissTimers[statusElementId] = null;
      _statusDismissGenerations[statusElementId] = statusGeneration + 1;
    }, autoDismissMs);
    _statusDismissTimers[statusElementId] = dismissTimerId;
  }
}

function _scheduleNextFrame(callback) {
  if (typeof window.requestAnimationFrame === "function") {
    window.requestAnimationFrame(callback);
    return;
  }
  setTimeout(callback, 16);
}

function _removeElement(element) {
  if (!element) return;
  if (typeof element.remove === "function") {
    element.remove();
    return;
  }
  if (element.parentNode) {
    element.parentNode.removeChild(element);
  }
}

let _toastHideTimerId = null;
let _toastGeneration = 0;

function _showToast(message) {
  let toast = document.getElementById("_aiia-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "_aiia-toast";
    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");
    Object.assign(toast.style, {
      position: "fixed",
      top: "1rem",
      left: "50%",
      transform: "translateX(-50%) translateY(-120%)",
      padding: "0.6rem 1.2rem",
      borderRadius: "10px",
      fontSize: "0.9rem",
      fontWeight: "500",
      color: "var(--text-primary)",
      background: "var(--bg-tertiary)",
      boxShadow: "0 4px 16px var(--shadow-color)",
      border: "1px solid var(--border-color)",
      zIndex: "9999",
      transition: "transform 0.3s ease, opacity 0.3s ease",
      opacity: "0",
      pointerEvents: "none",
      whiteSpace: "nowrap",
    });
    document.body.appendChild(toast);
  }
  if (_toastHideTimerId !== null) {
    clearTimeout(_toastHideTimerId);
    _toastHideTimerId = null;
  }

  const toastGeneration = (_toastGeneration += 1);
  let hideTimerId = null;
  toast.textContent = message;
  _scheduleNextFrame(() => {
    if (
      toastGeneration !== _toastGeneration ||
      _toastHideTimerId !== hideTimerId
    ) {
      return;
    }
    toast.style.transform = "translateX(-50%) translateY(0)";
    toast.style.opacity = "1";
  });
  hideTimerId = setTimeout(() => {
    if (
      toastGeneration !== _toastGeneration ||
      _toastHideTimerId !== hideTimerId
    ) {
      return;
    }
    toast.style.transform = "translateX(-50%) translateY(-120%)";
    toast.style.opacity = "0";
    _toastHideTimerId = null;
    _toastGeneration += 1;
  }, 1800);
  _toastHideTimerId = hideTimerId;
}

async function insertCodeFromClipboard() {

  let finished = false;
  let fallbackTimer = null;

  const finish = () => {
    finished = true;
    if (fallbackTimer) {
      clearTimeout(fallbackTimer);
      fallbackTimer = null;
    }
  };

  fallbackTimer = setTimeout(() => {
    if (finished) return;
    finish();
    openCodePasteModal(new Error("ClipboardReadTimeout"));
  }, 1500);

  try {
    if (
      !navigator.clipboard ||
      typeof navigator.clipboard.readText !== "function"
    ) {
      finish();
      openCodePasteModal();
      return;
    }

    const text = await navigator.clipboard.readText();
    if (finished) return;
    finish();

    if (!text || !text.trim()) {
      openCodePasteModal(new Error("ClipboardEmpty"));
      return;
    }

    insertCodeBlockIntoFeedbackTextarea(text);
    showStatus(t("status.codeInserted"), "success");
  } catch (error) {
    if (finished) return;
    finish();
    console.error("Clipboard read failed:", error);
    openCodePasteModal(error);
  }
}

function buildMarkdownCodeFence(text, lang = "") {
  const normalizedText = String(text || "").replace(/\r\n?/g, "\n");
  if (!normalizedText.trim()) return null;

  const backtickRuns = normalizedText.match(/`+/g) || [];
  let longestRun = 0;
  const backtickRunCount = backtickRuns.length;
  for (let index = 0; index < backtickRunCount; index += 1) {
    if (!(index in backtickRuns)) continue;
    const runLength = backtickRuns[index].length;
    if (runLength > longestRun) longestRun = runLength;
  }
  const fence = "`".repeat(Math.max(3, longestRun + 1));
  const fenceHead = lang ? `${fence}${lang}` : fence;
  const codeBody = normalizedText.endsWith("\n")
    ? normalizedText
    : `${normalizedText}\n`;

  return `${fenceHead}\n${codeBody}${fence}\n`;
}

function insertCodeBlockIntoFeedbackTextarea(text) {
  const textarea = document.getElementById("feedback-text");
  if (!textarea) return;

  const codeBlockBody = buildMarkdownCodeFence(text);
  if (!codeBlockBody) return;

  const cursorPos = textarea.selectionStart || 0;
  const currentText = textarea.value || "";
  const textBefore = currentText.substring(0, cursorPos);
  const textAfter = currentText.substring(cursorPos);
  const needsLeadingNewline = cursorPos > 0 && !textBefore.endsWith("\n");
  const needsTrailingNewline =
    textAfter.length > 0 && !textAfter.startsWith("\n");
  const codeBlock = `${needsLeadingNewline ? "\n" : ""}${codeBlockBody}${needsTrailingNewline ? "\n" : ""}`;

  textarea.value = textBefore + codeBlock + textAfter;

  const newCursorPos = textBefore.length + codeBlock.length;
  textarea.setSelectionRange(newCursorPos, newCursorPos);
  textarea.focus();
}

function getClipboardFailureHint(error) {

  try {
    if (!window.isSecureContext) {
      return { key: "status.clipboardHttp", text: t("status.clipboardHttp") };
    }

    const name = error && error.name ? String(error.name) : "";
    if (name === "NotAllowedError") {
      return {
        key: "status.clipboardDenied",
        text: t("status.clipboardDenied"),
      };
    }
    if (name === "NotFoundError") {
      return { key: "status.clipboardEmpty", text: t("status.clipboardEmpty") };
    }
    if (name === "Error" && error && error.message === "ClipboardReadTimeout") {
      return {
        key: "status.clipboardTimeout",
        text: t("status.clipboardTimeout"),
      };
    }
    if (name === "Error" && error && error.message === "ClipboardEmpty") {
      return {
        key: "status.clipboardNoText",
        text: t("status.clipboardNoText"),
      };
    }
  } catch (e) {

  }
  return { key: "status.clipboardDefault", text: t("status.clipboardDefault") };
}

let _codePasteModalPreviouslyFocusedElement = null;
let _codePasteModalKeydownWired = false;
let _codePasteModalFocusTimerId = null;
let _codePasteModalFocusGeneration = 0;

function _isCodePasteModalOpen(panel) {
  return !!(
    panel &&
    panel.classList &&
    typeof panel.classList.contains === "function" &&
    panel.classList.contains("show")
  );
}

function installCodePasteModalKeydownHandler() {
  if (_codePasteModalKeydownWired) return;
  document.addEventListener("keydown", handleCodePasteModalKeydown);
  _codePasteModalKeydownWired = true;
}

function removeCodePasteModalKeydownHandler() {
  if (!_codePasteModalKeydownWired) return;
  document.removeEventListener("keydown", handleCodePasteModalKeydown);
  _codePasteModalKeydownWired = false;
}

function clearCodePasteModalFocusTimer() {
  _codePasteModalFocusGeneration += 1;
  if (_codePasteModalFocusTimerId === null) return;
  try {
    clearTimeout(_codePasteModalFocusTimerId);
  } catch (_e) {

  }
  _codePasteModalFocusTimerId = null;
}

function focusCodePasteModalTextarea(textarea, panel) {
  if (!textarea || typeof textarea.focus !== "function") return false;
  if (!_isCodePasteModalOpen(panel)) return false;

  try {
    if (
      typeof document.contains === "function" &&
      (!document.contains(panel) || !document.contains(textarea))
    ) {
      return false;
    }
    if (typeof panel.contains === "function" && !panel.contains(textarea)) {
      return false;
    }
  } catch (_e) {
    return false;
  }

  try {
    textarea.focus({ preventScroll: true });
    return true;
  } catch (_e) {
    try {
      textarea.focus();
      return true;
    } catch (_e2) {
      return false;
    }
  }
}

function focusCodePasteModalRestoreTarget(element) {
  if (!element || typeof element.focus !== "function") return false;
  try {
    element.focus({ preventScroll: true });
    return true;
  } catch (_e) {
    try {
      element.focus();
      return true;
    } catch (_e2) {
      return false;
    }
  }
}

function scheduleCodePasteModalTextareaFocus(textarea, panel) {
  clearCodePasteModalFocusTimer();
  const focusGeneration = _codePasteModalFocusGeneration + 1;
  _codePasteModalFocusGeneration = focusGeneration;
  let focusTimerId = null;
  focusTimerId = setTimeout(() => {
    if (
      focusGeneration !== _codePasteModalFocusGeneration ||
      focusTimerId !== _codePasteModalFocusTimerId
    ) {
      return;
    }
    _codePasteModalFocusTimerId = null;
    focusCodePasteModalTextarea(textarea, panel);
  }, 0);
  _codePasteModalFocusTimerId = focusTimerId;
}

function openCodePasteModal(error) {
  const panel = document.getElementById("code-paste-panel");
  const textarea = document.getElementById("code-paste-textarea");
  const hint = document.getElementById("code-paste-hint");

  if (!panel || !textarea) {
    showStatus(t("status.clipboardFailed"), "error");
    return;
  }

  const wasAlreadyOpen = _isCodePasteModalOpen(panel);
  if (!wasAlreadyOpen) {
    _codePasteModalPreviouslyFocusedElement = document.activeElement;
  }

  if (hint) {

    const hintInfo = getClipboardFailureHint(error);
    try {
      hint.setAttribute("data-i18n", hintInfo.key);
    } catch (_e) {

    }
    hint.textContent = hintInfo.text;
  }

  textarea.value = "";
  panel.classList.remove("hidden");
  panel.classList.add("show");

  _setContainerSiblingsInert(panel, true);

  scheduleCodePasteModalTextareaFocus(textarea, panel);

  installCodePasteModalKeydownHandler();
}

function closeCodePasteModal() {
  const panel = document.getElementById("code-paste-panel");
  const textarea = document.getElementById("code-paste-textarea");
  clearCodePasteModalFocusTimer();
  if (!panel) {
    removeCodePasteModalKeydownHandler();
    _codePasteModalPreviouslyFocusedElement = null;
    return;
  }

  panel.classList.remove("show");
  panel.classList.add("hidden");

  _setContainerSiblingsInert(panel, false);

  if (textarea) {
    textarea.value = "";
  }

  removeCodePasteModalKeydownHandler();

  const prev = _codePasteModalPreviouslyFocusedElement;
  _codePasteModalPreviouslyFocusedElement = null;
  if (
    prev &&
    document.contains(prev) &&
    focusCodePasteModalRestoreTarget(prev)
  ) {
    return;
  }
  const feedbackTextarea = document.getElementById("feedback-text");
  focusCodePasteModalRestoreTarget(feedbackTextarea);
}

function _setContainerSiblingsInert(openModalEl, value) {
  const container = document.querySelector(".container");
  if (!container) return;
  for (const child of container.children) {
    if (child === openModalEl) continue;
    _safelySetInert(child, value);
  }
}

function _safelySetInert(el, value) {
  if (!el) return;
  try {
    el.inert = value;
  } catch (_e) {
    if (value) {
      el.setAttribute("inert", "");
    } else {
      el.removeAttribute("inert");
    }
  }
}

function _modalFocusTrap(panel, event) {
  if (event.key !== "Tab" || !panel) return;
  const focusables = panel.querySelectorAll(
    'button:not([disabled]),[href],input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',
  );
  let first = null;
  let last = null;
  const focusableCount =
    focusables && Number.isFinite(focusables.length) ? focusables.length : 0;
  for (let i = 0; i < focusableCount; i += 1) {
    const el = focusables[i];
    if (!el || el.offsetParent === null || el.hasAttribute("aria-hidden")) {
      continue;
    }
    if (!first) first = el;
    last = el;
  }
  if (!first || !last) return;
  const active = document.activeElement;
  if (event.shiftKey && active === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && active === last) {
    event.preventDefault();
    first.focus();
  }
}

function handleCodePasteModalKeydown(event) {
  if (event.key === "Escape") {
    closeCodePasteModal();
    return;
  }
  const panel = document.getElementById("code-paste-panel");
  _modalFocusTrap(panel, event);
}

let SUBMIT_BTN_ORIGINAL_HTML = null;

function captureSubmitBtnOriginalHTML() {
  if (SUBMIT_BTN_ORIGINAL_HTML !== null) return;
  const btn = document.getElementById("submit-btn");
  if (btn) SUBMIT_BTN_ORIGINAL_HTML = btn.innerHTML;
}

function isSubmitTargetStillCurrent(taskId) {
  if (!taskId) return !window.activeTaskId;
  return window.activeTaskId === taskId;
}

function clearSubmittedTaskLocalState(taskId) {
  if (!taskId) return;
  if (typeof taskTextareaContents !== "undefined") {
    delete taskTextareaContents[taskId];
  }
  if (typeof taskOptionsStates !== "undefined") {
    delete taskOptionsStates[taskId];
  }
  if (typeof taskImages !== "undefined") {
    delete taskImages[taskId];
  }

  if (typeof window.clearYesnoSelection === "function") {
    window.clearYesnoSelection(taskId);
  }
}

function _classifyFetchError(error) {
  if (!error) return "status.networkError";
  const name = error.name || "";
  const msg = String(error.message || "").toLowerCase();
  if (name === "AbortError") {
    return "status.requestTimeout";
  }
  if (
    name === "TypeError" &&
    (msg.includes("failed to fetch") ||
      msg.includes("networkerror") ||
      msg.includes("load failed"))
  ) {
    return "status.networkOffline";
  }
  if (name === "SyntaxError") {
    return "status.serverResponseInvalid";
  }
  if (name === "TypeError") {
    return "status.uiRenderingError";
  }
  return "status.networkError";
}
window._classifyFetchError = _classifyFetchError;

function _classifyHttpResponse(response) {
  if (!response || typeof response.status !== "number") return null;
  const status = response.status;
  if (status === 401 || status === 403) {
    return "status.unauthorized";
  }

  if (status === 502) {
    return "status.badGateway";
  }
  if (status === 503) {
    return "status.serviceOverloaded";
  }
  if (status === 504) {
    return "status.gatewayTimeout";
  }
  if (status >= 500 && status < 600) {
    return "status.serviceUnavailable";
  }
  return null;
}
window._classifyHttpResponse = _classifyHttpResponse;

async function submitFeedback() {
  captureSubmitBtnOriginalHTML();
  let submitTargetTaskId = null;

  const feedbackTextEl = document.getElementById("feedback-text");
  if (!feedbackTextEl) {
    console.warn(
      "submitFeedback: feedback-text not in DOM (likely keyboard shortcut " +
        "triggered during task switch / SSE replace) — silently aborting",
    );
    return;
  }

  const yesnoSelection =
    typeof window.getActiveYesnoSelection === "function"
      ? window.getActiveYesnoSelection()
      : null;
  let feedbackText = feedbackTextEl.value.trim();
  if (yesnoSelection) {
    feedbackText = feedbackText
      ? `${yesnoSelection}\n\n${feedbackText}`
      : yesnoSelection;
  }
  const selectedOptions = [];

  const optionsContainer = document.getElementById("options-container");
  if (optionsContainer) {
    const checkboxes = optionsContainer.querySelectorAll(
      'input[type="checkbox"]:checked',
    );
    const checkboxCount =
      checkboxes && Number.isFinite(checkboxes.length) ? checkboxes.length : 0;
    for (
      let checkboxIndex = 0;
      checkboxIndex < checkboxCount;
      checkboxIndex += 1
    ) {
      const checkbox = checkboxes[checkboxIndex];
      if (!checkbox) continue;

      if (checkbox.value) {
        selectedOptions.push(checkbox.value);
      }
    }
  }

  if (
    !feedbackText &&
    selectedOptions.length === 0 &&
    selectedImages.length === 0
  ) {

    showStatus(t("status.submitEmpty"), "error");
    return;
  }

  try {

    const submitBtn = document.getElementById("submit-btn");
    if (submitBtn) {
      submitBtn.disabled = true;
      // AIIA-XSS-SAFE: t('status.submitting') 是静态 key 且无参数，不携带用户可控数据。
      submitBtn.innerHTML = t("status.submitting");
    }

    const formData = new FormData();
    formData.append("feedback_text", feedbackText);
    formData.append("selected_options", JSON.stringify(selectedOptions));

    const selectedImageCount =
      selectedImages && Number.isFinite(selectedImages.length)
        ? selectedImages.length
        : 0;
    for (let imageIndex = 0; imageIndex < selectedImageCount; imageIndex += 1) {
      if (!(imageIndex in selectedImages)) continue;
      const img = selectedImages[imageIndex];
      if (img.file) {
        formData.append(`image_${imageIndex}`, img.file);
      }
    }

    submitTargetTaskId = window.activeTaskId;

    const submitUrl = submitTargetTaskId
      ? `/api/tasks/${submitTargetTaskId}/submit`
      : "/api/submit";
    console.debug(`Using submit endpoint: ${submitUrl}`);

    const response = await fetchWithTimeout(
      submitUrl,
      {
        method: "POST",
        body: formData,
      },
      30000,
    );

    const result = await response.json();

    if (response.ok) {
      showStatus(result.message, "success");

      if (isSubmitTargetStillCurrent(submitTargetTaskId)) {

        const fbTextEl = document.getElementById("feedback-text");
        if (fbTextEl) {
          fbTextEl.value = "";
        }
        const allCheckboxes = document.querySelectorAll(
          'input[type="checkbox"]',
        );
        const allCheckboxCount =
          allCheckboxes && Number.isFinite(allCheckboxes.length)
            ? allCheckboxes.length
            : 0;
        for (
          let checkboxIndex = 0;
          checkboxIndex < allCheckboxCount;
          checkboxIndex += 1
        ) {
          const checkbox = allCheckboxes[checkboxIndex];
          if (checkbox) {
            checkbox.checked = false;
          }
        }
        clearAllImages();
      } else {
        console.debug(
          "submitFeedback: submitted task changed before success cleanup; " +
            "preserving current form state",
        );
      }

      clearSubmittedTaskLocalState(submitTargetTaskId);

      if (typeof refreshTasksList === "function") {
        console.debug("Invoking refreshTasksList to refresh task list...");
        await refreshTasksList();
      } else {

        if (config) {
          config.has_content = false;
          console.debug("Feedback submitted; local state updated to empty");
        }
        showNoContentPage();
      }
    } else {

      const httpKey = _classifyHttpResponse(response);
      if (httpKey) {
        showStatus(t(httpKey), "error");
      } else {
        showStatus(result.message || t("status.submitFailed"), "error");
      }
    }
  } catch (error) {
    console.error("Submit failed:", error);

    showStatus(t(_classifyFetchError(error)), "error");
  } finally {

    const submitBtn = document.getElementById("submit-btn");
    if (submitBtn) {

      submitBtn.disabled = false;

      if (SUBMIT_BTN_ORIGINAL_HTML !== null) {
        submitBtn.innerHTML = SUBMIT_BTN_ORIGINAL_HTML;
        if (
          window.AIIA_I18N &&
          typeof window.AIIA_I18N.translateDOM === "function"
        ) {
          window.AIIA_I18N.translateDOM(submitBtn);
        }
      }
    }
  }
}

async function closeInterface() {
  try {
    showStatus(t("status.closingWebUI"), "info");

    stopContentPolling();

    const response = await fetchWithTimeout(
      "/api/close",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      },
      10000,
    );

    await response.json();
    if (response.ok) {

      renderClosedTerminalState();
      return;
    }
    showStatus(t("status.closeFailed"), "error");
  } catch (error) {
    console.error("Close UI failed:", error);
    showStatus(t("status.closeUIFailed"), "error");
  }

  setTimeout(() => {
    refreshPageSafely();
  }, 2000);
}

function renderClosedTerminalState() {
  try {
    if (typeof _disconnectSSE === "function") _disconnectSSE();
  } catch (_e) {

  }
  try {
    disposeHourglassAnimationLifecycle();
  } catch (_e) {

  }

  showNoContentPage();

  const icon = document.getElementById("hourglass-lottie");
  if (icon) {
    icon.style.filter = "none";
    icon.innerHTML = `
      <svg width="72" height="72" viewBox="0 0 48 48" fill="none" aria-hidden="true">
        <circle cx="24" cy="24" r="21" stroke="var(--success-500, #22c55e)" stroke-width="3" opacity="0.35"/>
        <path d="M15 24.5L21 30.5L33 18.5" stroke="var(--success-500, #22c55e)" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  }

  const title = document.querySelector("#no-content-container .no-content-title");
  if (title) {
    try {
      title.removeAttribute("data-i18n");
    } catch (_e) {

    }
    title.textContent = t("status.closedTitle");
  }
  const desc = document.querySelector(
    "#no-content-container .no-content-description",
  );
  if (desc) {
    try {
      desc.removeAttribute("data-i18n");
    } catch (_e) {

    }
    desc.textContent = t("status.closedHint");
  }

  const progress = document.querySelector(
    "#no-content-container .no-content-progress",
  );
  if (progress) progress.style.display = "none";
  setElementDisplayById("no-content-buttons", "none");
  const sseBadge = document.getElementById("sse-status-indicator");
  if (sseBadge) sseBadge.style.display = "none";

  for (const id of ["no-content-status-message", "status-message"]) {
    const statusElement = document.getElementById(id);
    if (statusElement) statusElement.style.display = "none";
  }
}

function refreshPageSafely() {
  console.debug("Reloading page…");
  try {
    window.location.reload();
  } catch (reloadError) {
    console.error("Page reload failed:", reloadError);

    try {
      window.location.href = window.location.origin;
    } catch (redirectError) {
      console.error("Page redirect failed:", redirectError);

      try {
        window.location.href = "about:blank";
      } catch (blankError) {
        console.error("All page navigation failed:", blankError);
      }
    }
  }
}

function stopContentPolling() {
  console.debug("[app.js] stopContentPolling called, but polling is disabled");
}

function isMobileDevice() {
  return (
    /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent,
    ) ||
    (navigator.maxTouchPoints &&
      navigator.maxTouchPoints > 2 &&
      /MacIntel/.test(navigator.platform))
  );
}

function detectPlatform() {
  const platform = navigator.platform.toLowerCase();
  const userAgent = navigator.userAgent.toLowerCase();

  if (platform.includes("mac") || userAgent.includes("mac")) {
    return "mac";
  } else if (platform.includes("win") || userAgent.includes("win")) {
    return "windows";
  } else if (platform.includes("linux") || userAgent.includes("linux")) {
    return "linux";
  }
  return "windows";
}

function getShortcutText(platform) {

  const strip = (s) => String(s).replace(/[:：]\s*$/, "");
  const submit = strip(t("settings.shortcutSubmit"));
  const insertCode = strip(t("settings.shortcutInsertCode"));
  const pasteImage = strip(t("settings.shortcutPasteImage"));
  const uploadImage = strip(t("settings.shortcutUploadImage"));
  const clearImage = strip(t("settings.shortcutClearImage"));

  const lines =
    platform === "mac"
      ? [
          `⌘+Enter  ${submit}`,
          `⌥+C      ${insertCode}`,
          `⌘+V      ${pasteImage}`,
          `⌘+U      ${uploadImage}`,
          `Delete   ${clearImage}`,
        ]
      : [
          `Ctrl+Enter ${submit}`,
          `Alt+C      ${insertCode}`,
          `Ctrl+V     ${pasteImage}`,
          `Ctrl+U     ${uploadImage}`,
          `Delete     ${clearImage}`,
        ];
  return lines.join("\n");
}

function initializeShortcutTooltip() {

  if (!isMobileDevice()) {
    const platform = detectPlatform();
    updateShortcutDisplay(platform);
    console.debug(
      `Desktop platform detected: ${platform}, shortcut hints applied`,
    );
  } else {
    console.debug("Mobile device detected, shortcut hints hidden");
  }
}

function setShortcutText(id, shortcut) {
  const element = document.getElementById(id);
  if (element) {
    element.textContent = shortcut;
  }
}

function updateShortcutDisplay(platform) {
  const isMac = platform === "mac";
  const ctrlOrCmd = isMac ? "Cmd" : "Ctrl";
  const altOrOption = isMac ? "Option" : "Alt";

  setShortcutText("shortcut-submit", `${ctrlOrCmd}+Enter`);
  setShortcutText("shortcut-code", `${altOrOption}+C`);
  setShortcutText("shortcut-paste", `${ctrlOrCmd}+V`);
  setShortcutText("shortcut-upload", `${ctrlOrCmd}+U`);
  setShortcutText("shortcut-delete", "Delete");
}

function _isElementEventWired(element, wireFlag) {
  if (!element || !wireFlag) return false;
  if (element.dataset) {
    return element.dataset[wireFlag] === "true";
  }
  return element[`__${wireFlag}`] === true;
}

function _markElementEventWired(element, wireFlag) {
  if (!element || !wireFlag) return;
  if (element.dataset) {
    element.dataset[wireFlag] = "true";
    return;
  }
  element[`__${wireFlag}`] = true;
}

function bindOptionalClick(id, handler, options) {
  const opts = options || {};
  const wireFlag = opts.wireFlag || "aiiaAppClickWired";
  const logMissing = opts.logMissing !== false;
  const element = document.getElementById(id);
  if (!element || typeof element.addEventListener !== "function") {
    if (logMissing) {
      console.debug(`App button binding skipped: #${id} unavailable`);
    }
    return false;
  }
  if (_isElementEventWired(element, wireFlag)) {
    return true;
  }

  element.addEventListener("click", handler);
  _markElementEventWired(element, wireFlag);
  return true;
}

function handleCodePasteInsertClick() {
  const textarea = document.getElementById("code-paste-textarea");
  const text = textarea ? textarea.value || "" : "";
  if (!text.trim()) {
    showStatus(t("status.enterCode"), "error");
    return false;
  }
  insertCodeBlockIntoFeedbackTextarea(text);
  closeCodePasteModal();
  return true;
}

function handleCodePasteBackdropClick(e) {
  const codePastePanel = document.getElementById("code-paste-panel");
  if (e.target === codePastePanel) {
    closeCodePasteModal();
  }
}

function bindCodePasteModalControls() {
  bindOptionalClick("code-paste-close-btn", closeCodePasteModal, {
    wireFlag: "aiiaCodePasteCloseClickWired",
    logMissing: false,
  });
  bindOptionalClick("code-paste-cancel-btn", closeCodePasteModal, {
    wireFlag: "aiiaCodePasteCancelClickWired",
    logMissing: false,
  });
  bindOptionalClick("code-paste-insert-btn", handleCodePasteInsertClick, {
    wireFlag: "aiiaCodePasteInsertClickWired",
    logMissing: false,
  });
  bindOptionalClick("code-paste-panel", handleCodePasteBackdropClick, {
    wireFlag: "aiiaCodePasteBackdropClickWired",
    logMissing: false,
  });
}

async function testNotification() {
  try {
    await notificationManager.sendNotification(
      t("status.testNotifyTitle"),
      t("status.testNotifyBody"),
      {
        tag: "test-notification",
        requireInteraction: false,
      },
    );
    showStatus(t("status.testNotifySent"), "success");
  } catch (error) {
    console.error("Test notification failed:", error);
    showStatus(t("status.testNotifyFailed"), "error");
  }
}

function handleGlobalKeydown(event) {
  const isMac = detectPlatform() === "mac";
  const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;
  const altOrOption = isMac ? event.altKey : event.altKey;

  if (ctrlOrCmd && event.key === "Enter") {
    event.preventDefault();
    submitFeedback();
  } else if (altOrOption && event.key === "c") {
    event.preventDefault();
    insertCodeFromClipboard();
  } else if (ctrlOrCmd && event.key === "v") {

    console.debug(`Shortcut: ${isMac ? "Cmd" : "Ctrl"}+V paste`);
  } else if (ctrlOrCmd && event.key === "u") {
    event.preventDefault();
    const uploadBtn = document.getElementById("upload-image-btn");
    if (uploadBtn && typeof uploadBtn.click === "function") {
      uploadBtn.click();
      console.debug(`Shortcut: ${isMac ? "Cmd" : "Ctrl"}+U upload image`);
    } else {
      console.debug("Shortcut upload skipped: upload button unavailable");
    }
  } else if (event.key === "Delete" && selectedImages.length > 0) {
    event.preventDefault();
    clearAllImages();
    console.debug("Shortcut: Delete clear all images");
  } else if (ctrlOrCmd && event.shiftKey && event.key === "N") {

    event.preventDefault();
    testNotification();
    console.debug(
      `Shortcut: ${isMac ? "Cmd" : "Ctrl"}+Shift+N test notification`,
    );
  }
}

let _globalKeydownHandlerWired = false;

function installGlobalKeydownHandler() {
  if (_globalKeydownHandlerWired) return;
  document.addEventListener("keydown", handleGlobalKeydown);
  _globalKeydownHandlerWired = true;
}

var AUDIO_UNLOCK_EVENTS = ["click", "keydown", "touchstart"];
let _audioUnlockListenersWired = false;

function removeAudioUnlockListeners() {
  if (!_audioUnlockListenersWired) return;
  for (var i = 0; i < AUDIO_UNLOCK_EVENTS.length; i++) {
    document.removeEventListener(
      AUDIO_UNLOCK_EVENTS[i],
      enableAudioOnFirstInteraction,
    );
  }
  _audioUnlockListenersWired = false;
}

function enableAudioOnFirstInteraction() {
  removeAudioUnlockListeners();
  if (
    notificationManager.audioContext &&
    notificationManager.audioContext.state === "suspended"
  ) {
    notificationManager.audioContext
      .resume()
      .then(() => {
        console.debug("Audio context enabled");
      })
      .catch((error) => {
        console.warn("Enable audio context failed:", error);
      });
  }
}

function installAudioUnlockListeners() {
  if (_audioUnlockListenersWired) return;
  for (var i = 0; i < AUDIO_UNLOCK_EVENTS.length; i++) {
    document.addEventListener(
      AUDIO_UNLOCK_EVENTS[i],
      enableAudioOnFirstInteraction,
    );
  }
  _audioUnlockListenersWired = true;
}

function initializeApp() {

  initHourglassAnimation();

  loadConfig()
    .then(() => {

      console.debug("Config loaded");
      console.debug("Current config:", {
        has_content: config.has_content,
        persistent: config.persistent,
        prompt_length: config.prompt ? config.prompt.length : 0,
      });

      if (typeof initMultiTaskSupport === "function") {
        initMultiTaskSupport();
      }
    })
    .catch((error) => {
      console.error("Config load failed:", error);
      setTimeout(() => {
        console.debug("Config load failed, delayed multi-task init…");
        if (typeof initMultiTaskSupport === "function") {
          initMultiTaskSupport();
        }
      }, 3000);
    });

  initializeImageFeatures();

  startPeriodicCleanup();

  initializeShortcutTooltip();

  settingsManager
    .init()
    .then(() => {
      settingsManager.applySettings({ syncBackend: false });
      return notificationManager.init();
    })
    .then(() => {
      console.debug("Notification manager initialized");
    })
    .catch((error) => {
      console.warn("Settings or notification manager init failed:", error);
    });

  bindOptionalClick("insert-code-btn", insertCodeFromClipboard, {
    wireFlag: "aiiaInsertCodeClickWired",
  });
  bindOptionalClick("submit-btn", submitFeedback, {
    wireFlag: "aiiaSubmitClickWired",
  });
  bindOptionalClick("close-btn", closeInterface, {
    wireFlag: "aiiaCloseClickWired",
  });

  bindCodePasteModalControls();

  installGlobalKeydownHandler();

  installAudioUnlockListeners();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {

  initializeApp();
}
