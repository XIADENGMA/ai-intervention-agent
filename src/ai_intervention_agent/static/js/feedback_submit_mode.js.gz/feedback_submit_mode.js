(function () {
  "use strict";

  const STORAGE_KEY = "aiia.submitMode.v1";
  const SCHEMA_VERSION = 1;
  const DEFAULT_MODE = "ctrl_enter";
  const VALID_MODES = ["ctrl_enter", "enter"];
  const TARGET_ID = "feedback-text";
  const SUBMIT_BTN_ID = "submit-btn";
  let activeKeydownInterceptor = null;
  let activeSelectBinding = null;

  function _isStorageAvailable() {
    try {
      const probe = "__aiia_submit_mode_probe__";
      localStorage.setItem(probe, "1");
      localStorage.removeItem(probe);
      return true;
    } catch (_e) {
      return false;
    }
  }

  function getMode() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return DEFAULT_MODE;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return DEFAULT_MODE;
      if (parsed.schema_version !== SCHEMA_VERSION) return DEFAULT_MODE;
      const mode = parsed.mode;
      if (VALID_MODES.indexOf(mode) === -1) return DEFAULT_MODE;
      return mode;
    } catch (_e) {
      return DEFAULT_MODE;
    }
  }

  function setMode(mode) {
    if (VALID_MODES.indexOf(mode) === -1) return false;
    if (!_isStorageAvailable()) return false;
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          schema_version: SCHEMA_VERSION,
          mode: mode,
          saved_at: Date.now(),
        }),
      );
      return true;
    } catch (_e) {
      return false;
    }
  }

  function _shouldSubmitOnEnter(event) {
    if (!event) return false;
    if (event.key !== "Enter") return false;
    if (event.shiftKey) return false;
    if (event.altKey) return false;
    if (event.ctrlKey || event.metaKey) return false;
    if (event.isComposing) return false;

    if (event.keyCode === 229) return false;
    return true;
  }

  function _triggerSubmit() {
    const btn = document.getElementById(SUBMIT_BTN_ID);
    if (!btn) return false;
    if (btn.disabled) return false;
    btn.click();
    return true;
  }

  function handleTextareaKeydown(event) {
    if (getMode() !== "enter") return;
    if (!_shouldSubmitOnEnter(event)) return;
    event.preventDefault();
    _triggerSubmit();
  }

  function setupKeydownInterceptor(textarea) {
    if (activeKeydownInterceptor !== null) {
      if (activeKeydownInterceptor.textarea === textarea) {
        return activeKeydownInterceptor;
      }
      if (activeKeydownInterceptor.textarea.removeEventListener) {
        activeKeydownInterceptor.textarea.removeEventListener(
          "keydown",
          activeKeydownInterceptor.handler,
          true,
        );
      }
      activeKeydownInterceptor = null;
    }
    if (!textarea) return null;
    const handler = handleTextareaKeydown;

    textarea.addEventListener("keydown", handler, true);
    activeKeydownInterceptor = { textarea: textarea, handler: handler };
    return activeKeydownInterceptor;
  }

  function handleSubmitModeSelectChange(event) {
    const select =
      event && event.currentTarget
        ? event.currentTarget
        : activeSelectBinding && activeSelectBinding.select;
    if (!select) return;
    const next = select.value;
    if (VALID_MODES.indexOf(next) === -1) return;
    setMode(next);
  }

  function setupSelectListener() {
    const select = document.getElementById("feedback-submit-mode-select");
    if (activeSelectBinding !== null) {
      if (activeSelectBinding.select === select) {
        if (select) select.value = getMode();
        return select;
      }
      if (activeSelectBinding.select.removeEventListener) {
        activeSelectBinding.select.removeEventListener(
          "change",
          activeSelectBinding.handler,
        );
      }
      activeSelectBinding = null;
    }
    if (!select) return null;
    select.value = getMode();
    select.addEventListener("change", handleSubmitModeSelectChange);
    activeSelectBinding = {
      select: select,
      handler: handleSubmitModeSelectChange,
    };
    return select;
  }

  function init() {
    const textarea = document.getElementById(TARGET_ID);
    const interceptor = setupKeydownInterceptor(textarea);
    const select = setupSelectListener();
    return { interceptor: interceptor, select: select };
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.AIIA_FEEDBACK_SUBMIT_MODE = {
    STORAGE_KEY: STORAGE_KEY,
    SCHEMA_VERSION: SCHEMA_VERSION,
    DEFAULT_MODE: DEFAULT_MODE,
    VALID_MODES: VALID_MODES,
    TARGET_ID: TARGET_ID,
    SUBMIT_BTN_ID: SUBMIT_BTN_ID,
    getMode: getMode,
    setMode: setMode,
    _shouldSubmitOnEnter: _shouldSubmitOnEnter,
    _triggerSubmit: _triggerSubmit,
    _isStorageAvailable: _isStorageAvailable,
    setupKeydownInterceptor: setupKeydownInterceptor,
    setupSelectListener: setupSelectListener,
    init: init,
  };
})();
